package com.animetv.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 统一偏好设置 (v7)
 * <p>
 * 全部配置集中在一处, 避免各页面各写一套 key 导致"设置不生效"。
 * 沿用旧文件名 player_pref, 老用户升级后画质/倍速记忆不丢。
 */
public class Prefs {

    private static final String FILE = "player_pref";

    /** 默认画质下标 (QUALITY 数组) */
    public static final String K_QUALITY = "qualityIdx";
    /** 默认倍速下标 (SPEEDS 数组) */
    public static final String K_SPEED = "speedIdx";
    /** 自动连播 */
    public static final String K_AUTO_NEXT = "autoNext";
    /** 单击快进/快退秒数 */
    public static final String K_SEEK_STEP = "seekStep";
    /** 长按拖动速度 1=慢 2=中 3=快 */
    public static final String K_SCRUB_SPEED = "scrubSpeed";
    /** 起播缓冲 0=极速 1=均衡 2=稳定 */
    public static final String K_BUFFER = "bufferStyle";
    /** 首页列数 0=自动 */
    public static final String K_COLUMNS = "gridCols";
    /** 画面比例 0=适应 1=拉伸 2=裁剪 */
    public static final String K_RATIO = "ratioMode";
    /** 控制条自动隐藏秒数 */
    public static final String K_HIDE_CONTROLS = "hideControls";

    public static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static int getInt(Context c, String key, int def) {
        try {
            return sp(c).getInt(key, def);
        } catch (Exception e) {
            return def;
        }
    }

    public static void setInt(Context c, String key, int value) {
        try {
            sp(c).edit().putInt(key, value).apply();
        } catch (Exception ignored) {}
    }

    public static boolean getBool(Context c, String key, boolean def) {
        try {
            return sp(c).getBoolean(key, def);
        } catch (Exception e) {
            return def;
        }
    }

    public static void setBool(Context c, String key, boolean value) {
        try {
            sp(c).edit().putBoolean(key, value).apply();
        } catch (Exception ignored) {}
    }

    /** 单击快进秒数 (3/5/10/15/30) */
    public static int seekStep(Context c) {
        int v = getInt(c, K_SEEK_STEP, 5);
        return v <= 0 ? 5 : v;
    }

    /** 长按拖动的基础倍率 (秒/次事件) */
    public static float scrubFactor(Context c) {
        int v = getInt(c, K_SCRUB_SPEED, 2);
        if (v == 1) return 0.6f;
        if (v == 3) return 1.8f;
        return 1.0f;
    }

    /** ExoPlayer 起播缓冲 (毫秒) */
    public static int bufferForPlayback(Context c) {
        int v = getInt(c, K_BUFFER, 1);
        if (v == 0) return 500;
        if (v == 2) return 2000;
        return 900;
    }
}
