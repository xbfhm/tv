package com.animetv.util;

import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * 轻量补间动画工具 (v7)
 * <p>
 * 只用 ViewPropertyAnimator (硬件加速图层), 老电视 Mali-450 也能 60fps:
 * 不创建 Animation 对象、不做位图模糊、不用 RenderScript。
 */
public class Motion {

    private static final DecelerateInterpolator DEC = new DecelerateInterpolator(1.6f);
    private static final OvershootInterpolator OVER = new OvershootInterpolator(1.1f);

    /** 淡入 (+ 可选延迟) */
    public static void fadeIn(final View v, long delay) {
        if (v == null) return;
        v.animate().cancel();
        v.setAlpha(0f);
        v.setVisibility(View.VISIBLE);
        v.animate().alpha(1f).setStartDelay(delay).setDuration(200).setInterpolator(DEC).start();
    }

    /** 淡出并隐藏 */
    public static void fadeOut(final View v, long delay) {
        if (v == null) return;
        v.animate().cancel();
        v.animate().alpha(0f).setStartDelay(delay).setDuration(160).setInterpolator(DEC)
                .withEndAction(() -> v.setVisibility(View.GONE)).start();
    }

    /** 从下方滑入 (详情面板) */
    public static void slideUpIn(View v, int distancePx, long delay) {
        if (v == null) return;
        v.animate().cancel();
        v.setVisibility(View.VISIBLE);
        v.setTranslationY(distancePx);
        v.setAlpha(0f);
        v.animate().translationY(0f).alpha(1f)
                .setStartDelay(delay).setDuration(260).setInterpolator(DEC).start();
    }

    /** 向下滑出并隐藏 */
    public static void slideDownOut(final View v, int distancePx) {
        if (v == null) return;
        v.animate().cancel();
        v.animate().translationY(distancePx).alpha(0f).setDuration(200).setInterpolator(DEC)
                .withEndAction(() -> {
                    v.setVisibility(View.GONE);
                    v.setTranslationY(0f);
                    v.setAlpha(1f);
                }).start();
    }

    /** 从右侧滑入 (更多功能面板) */
    public static void slideInRight(View v, int distancePx) {
        if (v == null) return;
        v.animate().cancel();
        v.setVisibility(View.VISIBLE);
        v.setTranslationX(distancePx);
        v.setAlpha(0f);
        v.animate().translationX(0f).alpha(1f).setDuration(230).setInterpolator(DEC).start();
    }

    public static void slideOutRight(final View v, int distancePx) {
        if (v == null) return;
        v.animate().cancel();
        v.animate().translationX(distancePx).alpha(0f).setDuration(190).setInterpolator(DEC)
                .withEndAction(() -> {
                    v.setVisibility(View.GONE);
                    v.setTranslationX(0f);
                    v.setAlpha(1f);
                }).start();
    }

    /** 面板渐显 + 轻微上浮 */
    public static void popIn(View v) {
        if (v == null) return;
        v.animate().cancel();
        v.setVisibility(View.VISIBLE);
        v.setAlpha(0f);
        v.setScaleX(0.96f);
        v.setScaleY(0.96f);
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(DEC).start();
    }

    /** 强调一下 (数值变化时) */
    public static void bump(View v) {
        if (v == null) return;
        v.animate().cancel();
        v.setScaleX(0.9f);
        v.setScaleY(0.9f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OVER).start();
    }
}
