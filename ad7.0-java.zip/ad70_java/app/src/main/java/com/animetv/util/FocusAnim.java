package com.animetv.util;

import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * 电视焦点动画 (v7 升级)
 * <p>
 * 聚焦: 放大 1.07 + 上浮阴影, 160ms 缓出 —— 遥控器"选中感"明显, 且只跑属性动画,
 * 老电视 (Mali-450 / 2GB) 也不会掉帧。
 */
public class FocusAnim {

    private static final float SCALE = 1.07f;
    private static final int DURATION = 160;
    private static final DecelerateInterpolator DEC = new DecelerateInterpolator(1.8f);
    private static float ELEV = -1f;

    /** 静态缩放方法: 可在已有焦点监听里调用, 不覆盖原监听 */
    public static void scale(View v, boolean has) {
        scale(v, has, SCALE);
    }

    public static void scale(View v, boolean has, float focusedScale) {
        if (v == null) return;
        if (ELEV < 0) ELEV = 8f * v.getResources().getDisplayMetrics().density;
        v.animate().cancel();
        float s = has ? focusedScale : 1f;
        v.animate().scaleX(s).scaleY(s).setDuration(DURATION).setInterpolator(DEC).start();
        try {
            v.setElevation(has ? ELEV : 0f);
        } catch (Exception ignored) {}
    }

    /** 直接绑定一个 View: 自动设置焦点缩放监听 (仅当该 View 无其他焦点监听时用) */
    public static void bind(final View v) {
        if (v == null) return;
        v.setOnFocusChangeListener((view, has) -> scale(view, has));
    }

    /** 绑定并回调 (自己还要处理文字颜色等) */
    public interface OnFocus {
        void onFocus(View v, boolean has);
    }

    public static void bind(final View v, final OnFocus extra) {
        if (v == null) return;
        v.setOnFocusChangeListener((view, has) -> {
            scale(view, has);
            if (extra != null) extra.onFocus(view, has);
        });
    }
}
