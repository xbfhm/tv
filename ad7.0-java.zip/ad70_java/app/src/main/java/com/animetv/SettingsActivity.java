package com.animetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.animetv.api.AgeApi;
import com.animetv.rule.RuleRepo;
import com.animetv.util.FocusAnim;
import com.animetv.util.HistoryStore;
import com.animetv.util.KeyMap;
import com.animetv.util.Prefs;
import com.animetv.util.UIMode;
import com.animetv.util.UrlCache;

/**
 * 设置页 v7
 * <p>
 * 全部用系统控件 + 代码构建, 遥控器可完整操作:
 * ↑↓ 选行, OK 打开选项, ←→ 直接在行上循环切换数值。
 */
public class SettingsActivity extends Activity {

    private static final String[] QUALITY_NAMES = {"自适应", "1080p", "720p", "480p", "360p"};
    private static final float[] SPEEDS = {1.0f, 1.25f, 1.5f, 2.0f, 0.75f, 0.5f, 1.75f};
    private static final String[] STEP_NAMES = {"3 秒", "5 秒", "10 秒", "15 秒", "30 秒"};
    private static final int[] STEP_VALUES = {3, 5, 10, 15, 30};
    private static final String[] SCRUB_NAMES = {"慢", "中", "快"};
    private static final String[] BUFFER_NAMES = {"极速（0.5s 起播）", "均衡（0.9s 起播）", "稳定（2s 起播）"};
    private static final String[] COL_NAMES = {"自动", "3 列", "4 列", "5 列", "6 列"};
    private static final String[] HIDE_NAMES = {"2 秒", "4 秒", "8 秒", "不自动隐藏"};
    private static final int[] HIDE_VALUES = {2, 4, 8, 0};

    private LinearLayout content;
    private View firstRow;
    private boolean rebuilt = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(getResources().getColor(R.color.bg_dark));
        scroll.setFillViewport(true);
        scroll.setFocusable(false);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(40), dp(34), dp(40), dp(40));
        scroll.addView(content, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        build();
    }

    // ==================== 构建 ====================

    private void build() {
        content.removeAllViews();
        firstRow = null;

        TextView title = new TextView(this);
        title.setText("设置");
        title.setTextColor(getResources().getColor(R.color.text_focus));
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        content.addView(title);

        TextView sub = new TextView(this);
        sub.setText("遥控器 ↑↓ 选择 · OK 打开选项 · ←→ 快速调节 · 返回 退出");
        sub.setTextColor(getResources().getColor(R.color.text_dim));
        sub.setTextSize(13);
        sub.setPadding(0, dp(6), 0, dp(16));
        content.addView(sub);

        // ---------------- 播放 ----------------
        section("播放");

        final int q = idx(Prefs.getInt(this, Prefs.K_QUALITY, 2), QUALITY_NAMES.length);
        row("默认画质", QUALITY_NAMES[q],
                v -> showChoice("默认画质", QUALITY_NAMES, idx(Prefs.getInt(this, Prefs.K_QUALITY, 2), QUALITY_NAMES.length),
                        which -> {
                            Prefs.setInt(this, Prefs.K_QUALITY, which);
                            rebuild();
                        }),
                () -> shiftQuality(1), () -> shiftQuality(-1));

        final int sp = idx(Prefs.getInt(this, Prefs.K_SPEED, 0), SPEEDS.length);
        row("默认倍速", speedName(sp),
                v -> showChoice("默认倍速", speedItems(), idx(Prefs.getInt(this, Prefs.K_SPEED, 0), SPEEDS.length),
                        which -> {
                            Prefs.setInt(this, Prefs.K_SPEED, which);
                            rebuild();
                        }),
                () -> shiftSpeed(1), () -> shiftSpeed(-1));

        row("自动连播", Prefs.getBool(this, Prefs.K_AUTO_NEXT, true) ? "开" : "关",
                v -> {
                    boolean nv = !Prefs.getBool(this, Prefs.K_AUTO_NEXT, true);
                    Prefs.setBool(this, Prefs.K_AUTO_NEXT, nv);
                    toast("自动连播: " + (nv ? "开" : "关"));
                    rebuild();
                }, null, null);

        row("快进步长", stepName(Prefs.seekStep(this)),
                v -> showChoice("单击 ←/→ 的快进步长", STEP_NAMES, stepIndex(Prefs.seekStep(this)),
                        which -> {
                            Prefs.setInt(this, Prefs.K_SEEK_STEP, STEP_VALUES[which]);
                            rebuild();
                        }),
                () -> shiftStep(1), () -> shiftStep(-1));

        final int scrub = idx(Prefs.getInt(this, Prefs.K_SCRUB_SPEED, 2) - 1, 3);
        row("长按拖动速度", SCRUB_NAMES[scrub],
                v -> showChoice("长按拖动速度（按住 ←→ 连续拖动时的每步时长）", SCRUB_NAMES,
                        idx(Prefs.getInt(this, Prefs.K_SCRUB_SPEED, 2) - 1, 3),
                        which -> {
                            Prefs.setInt(this, Prefs.K_SCRUB_SPEED, which + 1);
                            rebuild();
                        }),
                () -> shiftScrub(1), () -> shiftScrub(-1));

        final int buf = idx(Prefs.getInt(this, Prefs.K_BUFFER, 1), 3);
        row("起播缓冲", BUFFER_NAMES[buf],
                v -> showChoice("起播缓冲（越大越稳，越小越快）", BUFFER_NAMES,
                        idx(Prefs.getInt(this, Prefs.K_BUFFER, 1), 3),
                        which -> {
                            Prefs.setInt(this, Prefs.K_BUFFER, which);
                            rebuild();
                        }), null, null);

        // ---------------- 键位 ----------------
        section("键位设置");
        hint("按下 OK 后直接按遥控器上想绑定的那个键；绑定后播放页立即生效，按返回键可取消。");

        for (final String action : KeyMap.ACTIONS) {
            final int code = KeyMap.get(this, action);
            row(KeyMap.actionLabel(action), KeyMap.nameOf(code),
                    v -> captureKey(action), null, null);
        }
        row("恢复默认键位", "点击恢复",
                v -> {
                    KeyMap.reset(this);
                    toast("已恢复默认键位");
                    rebuild();
                }, null, null);

        // ---------------- 界面 ----------------
        section("界面");

        row("界面模式", UIMode.isTV(this) ? "电视端（遥控器）" : "手机端（触屏）",
                v -> showChoice("界面模式", new String[]{"电视端（遥控器）", "手机端（触屏）"},
                        UIMode.isTV(this) ? 0 : 1,
                        which -> {
                            UIMode.set(this, which == 0 ? UIMode.TV : UIMode.PHONE);
                            toast("界面模式已切换");
                            Intent i = new Intent(SettingsActivity.this, MainActivity.class);
                            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(i);
                            finish();
                        }), null, null);

        row("首页列数", COL_NAMES[idx(Prefs.getInt(this, Prefs.K_COLUMNS, 0), COL_NAMES.length)],
                v -> showChoice("首页海报列数（自动 = 按屏幕宽度计算）", COL_NAMES,
                        idx(Prefs.getInt(this, Prefs.K_COLUMNS, 0), COL_NAMES.length),
                        which -> {
                            Prefs.setInt(this, Prefs.K_COLUMNS, which);
                            rebuild();
                        }), null, null);

        row("控制条自动隐藏", HIDE_NAMES[hideIndex(Prefs.getInt(this, Prefs.K_HIDE_CONTROLS, 4))],
                v -> showChoice("控制条自动隐藏时间", HIDE_NAMES,
                        hideIndex(Prefs.getInt(this, Prefs.K_HIDE_CONTROLS, 4)),
                        which -> {
                            Prefs.setInt(this, Prefs.K_HIDE_CONTROLS, HIDE_VALUES[which]);
                            rebuild();
                        }), null, null);

        // ---------------- 缓存 ----------------
        section("缓存");
        final long size = cacheSize();
        row("接口缓存", formatSize(size),
                v -> {
                    AgeApi.clearCache();
                    UrlCache.clear();
                    toast("缓存已清理");
                    rebuild();
                }, null, null);
        hint("点击「接口缓存」即可清理；清理后首次打开会重新联网获取，属正常现象。");

        // ---------------- 关于 ----------------
        section("关于");
        row("版本", "v" + BuildConfig.VERSION_NAME + "（" + BuildConfig.VERSION_CODE + "）",
                v -> showInfo("版本信息",
                        "AnimeTV v" + BuildConfig.VERSION_NAME + "\n"
                                + "构建号 " + BuildConfig.VERSION_CODE + "\n\n"
                                + "最低支持 Android 5.0（API 21），\n"
                                + "针对海信 VIDAA 等老电视优化。"), null, null);
        row("内置规则源", RuleRepo.getRules().size() + " 条", v -> showInfo("规则源",
                "内置 " + RuleRepo.getRules().size() + " 条解析规则，\n"
                        + "来自 Predidit/KazumiRules（GPL-3.0）。\n\n"
                        + "在首页顶栏「源」按钮里可以切换搜索来源。"), null, null);
        row("开源仓库", "github.com/xbfhm/tv",
                v -> showInfo("开源仓库",
                        "源码与构建脚本：\nhttps://github.com/xbfhm/tv\n\n"
                                + "使用 GitHub Actions 云端编译，\n不需要本地安装 Android Studio。"), null, null);
        row("开源许可", "GPL-3.0", v -> showInfo("开源许可", LICENSE_TEXT), null, null);
        row("第三方组件", "查看", v -> showInfo("第三方组件与许可", THIRD_PARTY_TEXT), null, null);
        row("片源声明", "查看", v -> showInfo("片源声明", SOURCE_TEXT), null, null);
        row("清除播放历史", new HistoryStore(this).load().size() + " 条记录",
                v -> new AlertDialog.Builder(this)
                        .setTitle("清除播放历史")
                        .setMessage("确定清空全部播放记录？")
                        .setPositiveButton("清空", (d, w) -> {
                            new HistoryStore(this).clear();
                            toast("已清空");
                            rebuild();
                        })
                        .setNegativeButton("取消", null)
                        .show(), null, null);

        content.addView(space(18));
        TextView foot = new TextView(this);
        foot.setText("AnimeTV · 仅供学习交流，请支持正版");
        foot.setTextColor(getResources().getColor(R.color.text_dim));
        foot.setTextSize(12);
        foot.setGravity(Gravity.CENTER);
        content.addView(foot);

        if (!rebuilt) {
            rebuilt = true;
            if (firstRow != null) firstRow.post(firstRow::requestFocus);
        } else if (firstRow != null) {
            firstRow.post(firstRow::requestFocus);
        }
    }

    private void rebuild() {
        build();
    }

    // ---- 数值循环 ----

    private void shiftQuality(int d) {
        int n = Prefs.getInt(this, Prefs.K_QUALITY, 2);
        Prefs.setInt(this, Prefs.K_QUALITY, (n + d + QUALITY_NAMES.length) % QUALITY_NAMES.length);
        rebuild();
    }

    private void shiftSpeed(int d) {
        int n = Prefs.getInt(this, Prefs.K_SPEED, 0);
        Prefs.setInt(this, Prefs.K_SPEED, (n + d + SPEEDS.length) % SPEEDS.length);
        rebuild();
    }

    private void shiftStep(int d) {
        int n = stepIndex(Prefs.seekStep(this));
        int next = (n + d + STEP_VALUES.length) % STEP_VALUES.length;
        Prefs.setInt(this, Prefs.K_SEEK_STEP, STEP_VALUES[next]);
        rebuild();
    }

    private void shiftScrub(int d) {
        int n = Prefs.getInt(this, Prefs.K_SCRUB_SPEED, 2) - 1;
        int next = (n + d + 3) % 3;
        Prefs.setInt(this, Prefs.K_SCRUB_SPEED, next + 1);
        rebuild();
    }

    private long cacheSize() {
        try {
            return AgeApi.cacheSize();
        } catch (Exception e) {
            return 0;
        }
    }

    // ==================== 组件 ====================

    private void section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(getResources().getColor(R.color.accent));
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(4), dp(16), 0, dp(8));
        content.addView(t);
    }

    private void hint(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(getResources().getColor(R.color.text_dim));
        t.setTextSize(12);
        t.setPadding(dp(4), 0, dp(4), dp(10));
        content.addView(t);
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    interface Action {
        void run(View v);
    }

    /**
     * 一行设置: 左标题 + 右当前值。
     * onLeft/onRight 非空时支持遥控器 ←→ 直接改值。
     */
    private void row(String label, String value, final Action onClick,
                     final Runnable onLeft, final Runnable onRight) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setBackgroundResource(R.drawable.card_focus);
        wrap.setFocusable(true);
        wrap.setClickable(true);
        wrap.setPadding(dp(18), dp(13), dp(18), dp(13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        wrap.setLayoutParams(lp);

        final TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextColor(getResources().getColor(R.color.text_primary));
        tvLabel.setTextSize(16);
        wrap.addView(tvLabel);

        final TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextColor(getResources().getColor(R.color.text_secondary));
        tvValue.setTextSize(15);
        tvValue.setGravity(Gravity.END);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tvValue.setLayoutParams(vlp);
        wrap.addView(tvValue);

        final TextView chevron = new TextView(this);
        chevron.setText("  ›");
        chevron.setTextColor(getResources().getColor(R.color.text_dim));
        chevron.setTextSize(18);
        wrap.addView(chevron);

        wrap.setOnClickListener(v -> {
            if (onClick != null) onClick.run(v);
        });

        if (onLeft != null || onRight != null) {
            wrap.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() != KeyEvent.ACTION_DOWN) return false;
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && onLeft != null) {
                    onLeft.run();
                    return true;
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && onRight != null) {
                    onRight.run();
                    return true;
                }
                return false;
            });
        }

        wrap.setOnFocusChangeListener((v, has) -> {
            FocusAnim.scale(v, has, 1.02f);
            tvLabel.setTextColor(getResources().getColor(has ? R.color.text_focus : R.color.text_primary));
            tvValue.setTextColor(getResources().getColor(has ? R.color.text_focus : R.color.text_secondary));
            chevron.setTextColor(getResources().getColor(has ? R.color.text_focus : R.color.text_dim));
        });

        content.addView(wrap);
        if (firstRow == null) firstRow = wrap;
    }

    // ==================== 弹窗 ====================

    interface OnChoice {
        void onPick(int which);
    }

    private void showChoice(String title, String[] items, int checked, final OnChoice cb) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(items, checked, (dialog, which) -> {
                    dialog.dismiss();
                    cb.onPick(which);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("好", null)
                .show();
    }

    /** 捕获按键: 弹窗里按哪个键就绑定哪个键 */
    private void captureKey(final String action) {
        final TextView tv = new TextView(this);
        tv.setText("按下遥控器上要绑定的按键…\n\n按「返回」取消\n当前: " + KeyMap.nameOf(KeyMap.get(this, action)));
        tv.setTextColor(getResources().getColor(R.color.text_primary));
        tv.setTextSize(17);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(30), dp(40), dp(30), dp(40));

        final Dialog d = new Dialog(this) {
            @Override
            public boolean dispatchKeyEvent(KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    int code = event.getKeyCode();
                    if (code == KeyEvent.KEYCODE_BACK) {
                        dismiss();
                        return true;
                    }
                    String conflict = KeyMap.conflictOf(SettingsActivity.this, action, code);
                    KeyMap.set(SettingsActivity.this, action, code);
                    dismiss();
                    toast("「" + KeyMap.actionLabel(action) + "」→ " + KeyMap.nameOf(code)
                            + (conflict == null ? "" : "（与「" + conflict + "」冲突）"));
                    rebuild();
                    return true;
                }
                return true;
            }
        };
        d.setContentView(tv);
        d.setCancelable(true);
        d.show();
        try {
            d.getWindow().setBackgroundDrawableResource(R.drawable.card_bg);
        } catch (Exception ignored) {}
    }

    // ==================== 工具 ====================

    private static int idx(int v, int len) {
        return Math.max(0, Math.min(len - 1, v));
    }

    private static String speedName(int i) {
        float s = SPEEDS[idx(i, SPEEDS.length)];
        if (s == Math.floor(s)) return ((int) s) + ".0x";
        return s + "x";
    }

    private static String[] speedItems() {
        String[] out = new String[SPEEDS.length];
        for (int i = 0; i < SPEEDS.length; i++) out[i] = speedName(i);
        return out;
    }

    private static String stepName(int sec) {
        for (int i = 0; i < STEP_VALUES.length; i++) if (STEP_VALUES[i] == sec) return STEP_NAMES[i];
        return sec + " 秒";
    }

    private static int stepIndex(int sec) {
        for (int i = 0; i < STEP_VALUES.length; i++) if (STEP_VALUES[i] == sec) return i;
        return 1;
    }

    private static int hideIndex(int sec) {
        if (sec == 2) return 0;
        if (sec == 8) return 2;
        if (sec <= 0) return 3;
        return 1;
    }

    private static String formatSize(long bytes) {
        if (bytes <= 0) return "0 KB";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format("%.1f MB", bytes / 1024.0 / 1024.0);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    // ==================== 文案 ====================

    private static final String LICENSE_TEXT =
            "AnimeTV 以 GNU General Public License v3.0 发布。\n\n"
                    + "你可以自由使用、修改、分发本软件，但分发衍生作品时必须：\n"
                    + "· 同样以 GPL-3.0 开源；\n"
                    + "· 保留原作者版权声明；\n"
                    + "· 提供完整对应源代码。\n\n"
                    + "本软件不提供任何担保。完整协议见仓库根目录 LICENSE 文件。";

    private static final String THIRD_PARTY_TEXT =
            "本软件使用了以下开源组件，谨向作者致谢：\n\n"
                    + "· AndroidX / AppCompat / RecyclerView / CardView — Apache-2.0\n"
                    + "· AndroidX Media3 (ExoPlayer) — Apache-2.0\n"
                    + "· OkHttp — Apache-2.0\n"
                    + "· Glide — BSD-2-Clause / MIT / Apache-2.0\n"
                    + "· jsoup — MIT\n"
                    + "· JsoupXpath — Apache-2.0\n"
                    + "· Apache Commons Lang — Apache-2.0\n"
                    + "· ANTLR 4 Runtime — BSD-3-Clause\n"
                    + "· SLF4J — MIT\n\n"
                    + "剧集解析规则来自 Predidit/KazumiRules（GPL-3.0）。\n"
                    + "详细许可见仓库 THIRD-PARTY-NOTICES.md。";

    private static final String SOURCE_TEXT =
            "AnimeTV 本身不存储、不制作、不上传任何视频文件。\n\n"
                    + "· 所有片源均来自第三方公开接口，版权归原权利方所有；\n"
                    + "· 本软件仅提供播放器与索引聚合；\n"
                    + "· 请勿将本软件用于任何商业用途；\n"
                    + "· 喜欢作品请支持正版平台与官方周边。\n\n"
                    + "如有侵权，请联系仓库作者删除相关代码。";
}
