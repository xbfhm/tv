package com.animetv.util;

import android.util.LruCache;

/**
 * 播放直链内存缓存 (v7 秒开)
 * <p>
 * 打开详情页时后台先把当前集解析好丢进这里;
 * 用户按"播放"时直接命中, 不再等 3~8 秒的解析链路。
 */
public class UrlCache {

    private static final int MAX = 48;
    private static final LruCache<String, String> CACHE = new LruCache<String, String>(MAX) {
        @Override
        protected int sizeOf(String key, String value) {
            return 1;
        }
    };

    public static void put(String key, String url) {
        if (key == null || url == null || url.isEmpty()) return;
        try {
            CACHE.put(key, url);
        } catch (Exception ignored) {}
    }

    public static String get(String key) {
        if (key == null) return null;
        try {
            return CACHE.get(key);
        } catch (Exception e) {
            return null;
        }
    }

    public static void clear() {
        try {
            CACHE.evictAll();
        } catch (Exception ignored) {}
    }
}
