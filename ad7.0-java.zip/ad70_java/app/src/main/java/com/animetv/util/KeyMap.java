package com.animetv.util;

import android.content.Context;
import android.view.KeyEvent;

/**
 * 遥控器键位映射 (v7)
 * <p>
 * 每个"动作"对应一个 keyCode, 设置页里可以按一下遥控器按键重新绑定。
 * 默认值遵循电视端通行习惯: OK=播放/暂停, MENU=更多功能, 左右=快进快退, 上下=音量。
 */
public class KeyMap {

    // ---- 动作 ----
    public static final String A_PLAY = "key_play";            // 播放 / 暂停
    public static final String A_MENU = "key_menu";            // 更多功能面板
    public static final String A_FORWARD = "key_forward";      // 快进 (单击 +N 秒 / 长按拖动)
    public static final String A_REWIND = "key_rewind";        // 快退
    public static final String A_VOL_UP = "key_vol_up";        // 音量 +
    public static final String A_VOL_DOWN = "key_vol_down";    // 音量 -
    public static final String A_NEXT_EP = "key_next_ep";      // 下一集
    public static final String A_PREV_EP = "key_prev_ep";      // 上一集

    public static final String[] ACTIONS = {
            A_PLAY, A_MENU, A_FORWARD, A_REWIND, A_VOL_UP, A_VOL_DOWN, A_NEXT_EP, A_PREV_EP
    };

    public static final String[] LABELS = {
            "播放 / 暂停",
            "更多功能菜单",
            "快进 / 长按拖动",
            "快退 / 长按拖动",
            "音量 +",
            "音量 -",
            "下一集",
            "上一集"
    };

    private static final int[] DEFAULTS = {
            KeyEvent.KEYCODE_DPAD_CENTER,   // 23
            KeyEvent.KEYCODE_MENU,          // 82
            KeyEvent.KEYCODE_DPAD_RIGHT,    // 22
            KeyEvent.KEYCODE_DPAD_LEFT,     // 21
            KeyEvent.KEYCODE_DPAD_UP,       // 19
            KeyEvent.KEYCODE_DPAD_DOWN,     // 20
            KeyEvent.KEYCODE_MEDIA_NEXT,    // 87
            KeyEvent.KEYCODE_MEDIA_PREVIOUS // 88
    };

    public static int def(String action) {
        for (int i = 0; i < ACTIONS.length; i++) {
            if (ACTIONS[i].equals(action)) return DEFAULTS[i];
        }
        return KeyEvent.KEYCODE_UNKNOWN;
    }

    public static int get(Context c, String action) {
        int v = Prefs.getInt(c, action, def(action));
        return v <= 0 ? def(action) : v;
    }

    public static void set(Context c, String action, int keyCode) {
        Prefs.setInt(c, action, keyCode);
    }

    public static void reset(Context c) {
        for (String a : ACTIONS) Prefs.sp(c).edit().remove(a).apply();
    }

    /** 键码 -> 中文名 (设置页显示) */
    public static String nameOf(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP: return "上";
            case KeyEvent.KEYCODE_DPAD_DOWN: return "下";
            case KeyEvent.KEYCODE_DPAD_LEFT: return "左";
            case KeyEvent.KEYCODE_DPAD_RIGHT: return "右";
            case KeyEvent.KEYCODE_DPAD_CENTER: return "OK / 确定";
            case KeyEvent.KEYCODE_ENTER: return "回车";
            case KeyEvent.KEYCODE_MENU: return "菜单键";
            case KeyEvent.KEYCODE_BACK: return "返回键";
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: return "媒体播放/暂停";
            case KeyEvent.KEYCODE_MEDIA_PLAY: return "媒体播放";
            case KeyEvent.KEYCODE_MEDIA_PAUSE: return "媒体暂停";
            case KeyEvent.KEYCODE_MEDIA_NEXT: return "媒体下一曲";
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS: return "媒体上一曲";
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: return "媒体快进";
            case KeyEvent.KEYCODE_MEDIA_REWIND: return "媒体快退";
            case KeyEvent.KEYCODE_MEDIA_STOP: return "媒体停止";
            case KeyEvent.KEYCODE_VOLUME_UP: return "音量 +";
            case KeyEvent.KEYCODE_VOLUME_DOWN: return "音量 -";
            case KeyEvent.KEYCODE_INFO: return "信息键";
            case KeyEvent.KEYCODE_TV: return "TV 键";
            case KeyEvent.KEYCODE_GUIDE: return "指南键";
            case KeyEvent.KEYCODE_BUTTON_A: return "手柄 A";
            case KeyEvent.KEYCODE_BUTTON_B: return "手柄 B";
            default:
                if (code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9) {
                    return "数字 " + (code - KeyEvent.KEYCODE_0);
                }
                if (code >= KeyEvent.KEYCODE_F1 && code <= KeyEvent.KEYCODE_F12) {
                    return "F" + (code - KeyEvent.KEYCODE_F1 + 1);
                }
                return "键码 " + code;
        }
    }

    /** 该键是否已被别的动作占用 (键位冲突提示) */
    public static String conflictOf(Context c, String action, int code) {
        for (String a : ACTIONS) {
            if (a.equals(action)) continue;
            if (get(c, a) == code) return actionLabel(a);
        }
        return null;
    }

    public static String actionLabel(String action) {
        for (int i = 0; i < ACTIONS.length; i++) {
            if (ACTIONS[i].equals(action)) return LABELS[i];
        }
        return action;
    }
}
