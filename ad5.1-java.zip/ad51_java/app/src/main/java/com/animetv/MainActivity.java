package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.animetv.api.AgeApi;
import com.animetv.model.Anime;
import com.animetv.model.AnimeDetail;
import com.animetv.model.Episode;
import com.animetv.util.HistoryStore;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextView tvInfo, tvListTitle;
    private EditText etSearch;
    private ImageView ivDetailCover;
    private RecyclerView rvList, rvEpisodes;
    private Button btnLine, btnPlay, btnPrev, btnNext;

    private final ExecutorService pool = Executors.newFixedThreadPool(1);
    private final List<Anime> animeList = new ArrayList<>();
    private final List<Episode> epList = new ArrayList<>();
    private final ListAdapter listAdapter = new ListAdapter();
    private final EpAdapter epAdapter = new EpAdapter();

    private AnimeDetail detail;
    private int epIndex = 0;
    private boolean busy = false;
    private String listMode = "home";

    private HistoryStore history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AnimeTVApp.log("Main onCreate: 布局完成");
        history = new HistoryStore(this);
        bindViews();
        AnimeTVApp.log("Main onCreate: 控件绑定完成");
        setupList();
        AnimeTVApp.log("Main onCreate: 列表初始化完成");
        showHome();
        AnimeTVApp.log("Main onCreate: 首页请求已发起");
    }

    private void bindViews() {
        tvInfo = findViewById(R.id.tvInfo);
        tvListTitle = findViewById(R.id.tvListTitle);
        etSearch = findViewById(R.id.etSearch);
        ivDetailCover = findViewById(R.id.ivDetailCover);
        rvList = findViewById(R.id.rvList);
        rvEpisodes = findViewById(R.id.rvEpisodes);
        btnLine = findViewById(R.id.btnLine);
        btnPlay = findViewById(R.id.btnPlay);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);

        findViewById(R.id.btnHome).setOnClickListener(v -> showHome());
        findViewById(R.id.btnCatalog).setOnClickListener(v -> showCatalog());
        findViewById(R.id.btnHistory).setOnClickListener(v -> showHistory());
        findViewById(R.id.btnSearch).setOnClickListener(v -> doSearch());
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); return true; }
            return false;
        });
        btnPlay.setOnClickListener(v -> playCurrent());
        btnPrev.setOnClickListener(v -> prevEp());
        btnNext.setOnClickListener(v -> nextEp());
        btnLine.setOnClickListener(v -> switchLine());
        findViewById(R.id.btnExternal).setOnClickListener(v -> externalPlay());
    }

    private void setupList() {
        rvList.setLayoutManager(new LinearLayoutManager(this));
        rvList.setAdapter(listAdapter);
        rvEpisodes.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        rvEpisodes.setAdapter(epAdapter);
    }

    // ================= 模式切换 =================
    private void showHome() {
        if (busy) return;
        busy = true;
        ivDetailCover.setVisibility(View.GONE);
        tvInfo.setText("⏳ 正在加载首页...\n\n请稍候");
        listMode = "home";
        pool.execute(() -> {
            try {
                List<Anime> list = AgeApi.home();
                AnimeTVApp.log("home() 返回 " + list.size() + " 条");
                runOnUiThread(() -> {
                    busy = false;
                    renderAnimeList(list, "🔥 最新更新 / 本周新番");
                    AnimeTVApp.log("首页渲染完成 " + list.size() + " 条");
                });
            } catch (Exception e) {
                uiError("首页加载失败: " + e.getMessage());
            }
        });
    }

    private void showCatalog() {
        if (busy) return;
        busy = true;
        ivDetailCover.setVisibility(View.GONE);
        tvInfo.setText("⏳ 正在加载新番目录...");
        listMode = "catalog";
        pool.execute(() -> {
            try {
                List<Anime> list = new ArrayList<>();
                list.addAll(AgeApi.catalog(2026, 1));
                list.addAll(AgeApi.catalog(2026, 4));
                list.addAll(AgeApi.catalog(2026, 7));
                runOnUiThread(() -> {
                    busy = false;
                    renderAnimeList(list, "📺 2026 新番一览");
                });
            } catch (Exception e) {
                uiError("目录加载失败: " + e.getMessage());
            }
        });
    }

    private void showHistory() {
        busy = false;
        ivDetailCover.setVisibility(View.GONE);
        List<HistoryStore.Item> items = history.load();
        if (items.isEmpty()) {
            tvInfo.setText("暂无播放历史\n\n看过的番会记录在这里");
            listMode = "history";
            animeList.clear();
            listAdapter.notifyDataSetChanged();
            return;
        }
        List<Anime> list = new ArrayList<>();
        for (HistoryStore.Item it : items) {
            Anime a = new Anime(it.aid, it.name, "", "", "");
            a.display = "🕘 " + it.name + "  ▶ " + it.ep;
            list.add(a);
        }
        renderAnimeList(list, "🕘 播放历史 (OK=恢复)");
        listMode = "history";
    }

    private void doSearch() {
        if (busy) return;
        String kw = etSearch.getText().toString().trim();
        if (kw.isEmpty()) {
            tvInfo.setText("请输入番剧名称\n如: 海贼王 / 咒术回战 / 葬送的芙莉莲");
            return;
        }
        busy = true;
        ivDetailCover.setVisibility(View.GONE);
        tvInfo.setText("⏳ 正在搜索 [" + kw + "] ...");
        listMode = "search";
        pool.execute(() -> {
            try {
                List<Anime> list = AgeApi.search(kw);
                runOnUiThread(() -> {
                    busy = false;
                    if (list.isEmpty()) {
                        tvInfo.setText("未找到 [" + kw + "] 相关番剧\n\n换个关键词试试");
                        animeList.clear();
                        listAdapter.notifyDataSetChanged();
                    } else {
                        renderAnimeList(list, "🔍 搜索结果: " + kw);
                    }
                });
            } catch (Exception e) {
                uiError("搜索失败: " + e.getMessage());
            }
        });
    }

    // ================= 渲染 =================
    private void renderAnimeList(List<Anime> list, String title) {
        animeList.clear();
        animeList.addAll(list);
        tvListTitle.setText(title);
        listAdapter.notifyDataSetChanged();
    }

    private void uiError(String msg) {
        runOnUiThread(() -> {
            busy = false;
            tvInfo.setText(msg + "\n\n可重试或换操作");
        });
    }

    // ================= 详情 =================
    private void openAnime(Anime a, int resumeEp, String resumeLine) {
        if (busy) return;
        busy = true;
        tvInfo.setText("⏳ 正在解析《" + a.name + "》...");
        pool.execute(() -> {
            try {
                AnimeDetail d = AgeApi.detail(a.id);
                if (d.episodes.isEmpty()) {
                    runOnUiThread(() -> {
                        busy = false;
                        tvInfo.setText("《" + d.name + "》暂无免费播放线路\n\n版权番可能仅有 VIP 源");
                        epList.clear();
                        epAdapter.notifyDataSetChanged();
                    });
                    return;
                }
                if (resumeLine != null && !resumeLine.isEmpty() && hasLine(d, resumeLine)) {
                    d.currentLine = resumeLine;
                }
                int idx = Math.min(Math.max(resumeEp, 0), d.episodes.size() - 1);
                AnimeDetail dd = d;
                int ii = idx;
                runOnUiThread(() -> renderDetail(dd, ii));
            } catch (Exception e) {
                uiError("解析失败: " + e.getMessage());
            }
        });
    }

    private boolean hasLine(AnimeDetail d, String line) {
        for (Episode e : d.episodes) if (e.line.equals(line)) return true;
        return false;
    }

    private void renderDetail(AnimeDetail d, int idx) {
        busy = false;
        detail = d;
        epIndex = idx;
        StringBuilder sb = new StringBuilder();
        for (String t : d.tags) { if (sb.length() > 0) sb.append(" "); sb.append(t); }
        String tags = sb.toString();
        tvInfo.setText("《" + d.name + "》\n\n" +
                "类型: " + d.type + " | 首播: " + d.premiere + "\n" +
                "状态: " + d.status + " | " + d.uptodate + "\n" +
                "标签: " + tags + "\n\n" +
                "简介: " + (d.intro.length() > 160 ? d.intro.substring(0, 160) : d.intro) + "\n\n" +
                "⬇ 选择集数, ▶ 内置播放 (硬解全屏)");
        // 封面
        if (d.cover != null && !d.cover.isEmpty()) {
            ivDetailCover.setVisibility(View.VISIBLE);
            Glide.with(this).load(d.cover)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .override(640, 360)
                    .placeholder(R.color.bg_panel)
                    .error(R.color.bg_panel)
                    .into(ivDetailCover);
        } else {
            ivDetailCover.setVisibility(View.GONE);
        }
        epList.clear();
        epList.addAll(d.episodes);
        epAdapter.notifyDataSetChanged();
        updateButtons();
    }

    // ================= 选集 / 播放 =================
    private void selectEp(int i) {
        if (busy || epList.isEmpty()) return;
        epIndex = Math.min(i, epList.size() - 1);
        updateButtons();
        resolveAndPlay();
    }

    private void playCurrent() {
        if (busy || epList.isEmpty()) {
            tvInfo.setText("请先选择一部番剧");
            return;
        }
        updateButtons();
        resolveAndPlay();
    }

    private void resolveAndPlay() {
        Episode e = epList.get(epIndex);
        tvInfo.setText("《" + detail.name + "》 " + e.title + "\n\n⏳ 正在获取播放地址...");
        busy = true;
        pool.execute(() -> {
            String url = null;
            String usedLine = detail.currentLine;
            List<String> tried = new ArrayList<>();
            for (Episode ep : epList) {
                if (!ep.line.equals(detail.currentLine)) continue;
                tried.add(ep.lineLabel);
                try {
                    url = AgeApi.resolve(ep.enc, ep.vip, detail.jxZJ, detail.jxVIP);
                    break;
                } catch (Exception ignored) {}
            }
            if (url == null) {
                for (Episode ep : epList) {
                    if (ep.line.equals(detail.currentLine)) continue;
                    tried.add(ep.lineLabel);
                    try {
                        url = AgeApi.resolve(ep.enc, ep.vip, detail.jxZJ, detail.jxVIP);
                        usedLine = ep.line;
                        break;
                    } catch (Exception ignored) {}
                }
            }
            String finalUrl = url;
            String finalLine = usedLine;
            runOnUiThread(() -> {
                busy = false;
                if (finalUrl == null) {
                    tvInfo.setText("播放失败: 线路均无法解析\n\n可「换线路」重试或换一部番");
                    return;
                }
                history.add(detail.id, detail.name, e.title, epIndex, finalLine);
                launchPlayer(finalUrl, e, finalLine);
            });
        });
    }

    private void launchPlayer(String url, Episode e, String line) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("url", url);
        it.putExtra("title", detail.name + " " + e.title + " [" + e.lineLabel + "]");
        it.putExtra("animeId", detail.id);
        it.putExtra("epIndex", epIndex);
        it.putExtra("line", line);
        it.putExtra("episodes", new ArrayList<>(epList));
        it.putExtra("animeName", detail.name);
        it.putExtra("jxZj", detail.jxZJ);
        it.putExtra("jxVip", detail.jxVIP);
        startActivity(it);
    }

    // ================= 上下集 / 线路 =================
    private void prevEp() {
        if (epIndex > 0) selectEp(epIndex - 1);
    }

    private void nextEp() {
        if (epIndex < epList.size() - 1) selectEp(epIndex + 1);
        else tvInfo.setText("已经是最后一集了");
    }

    private void switchLine() {
        if (epList.isEmpty()) return;
        List<String> lines = new ArrayList<>();
        for (Episode e : epList) if (!lines.contains(e.line)) lines.add(e.line);
        if (lines.isEmpty()) return;
        int i = lines.indexOf(detail.currentLine);
        detail.currentLine = lines.get((i + 1) % lines.size());
        updateButtons();
        tvInfo.setText("已切换到线路: " + detail.currentLine + "\n\n按 ▶ 播放");
    }

    private void updateButtons() {
        if (epList.isEmpty()) return;
        Episode e = epList.get(epIndex);
        btnPlay.setText("▶ 播放 " + e.title);
        btnLine.setText("线路: " + e.lineLabel);
        btnPrev.setEnabled(epIndex > 0);
        btnNext.setEnabled(epIndex < epList.size() - 1);
    }

    // ================= 外部播放 =================
    private void externalPlay() {
        if (busy || epList.isEmpty()) {
            tvInfo.setText("请先选择一部番剧");
            return;
        }
        Episode e = epList.get(epIndex);
        tvInfo.setText("⏳ 正在获取直链...");
        busy = true;
        pool.execute(() -> {
            String url = null;
            for (Episode ep : epList) {
                if (!ep.line.equals(detail.currentLine)) continue;
                try { url = AgeApi.resolve(ep.enc, ep.vip, detail.jxZJ, detail.jxVIP); break; }
                catch (Exception ignored) {}
            }
            if (url == null) {
                for (Episode ep : epList) {
                    try { url = AgeApi.resolve(ep.enc, ep.vip, detail.jxZJ, detail.jxVIP); break; }
                    catch (Exception ignored) {}
                }
            }
            String finalUrl = url;
            runOnUiThread(() -> {
                busy = false;
                if (finalUrl == null) { tvInfo.setText("获取直链失败"); return; }
                Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl));
                it.setType(finalUrl.contains(".m3u8") ? "application/x-mpegURL" : "video/*");
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(Intent.createChooser(it, "选择播放器"));
                } catch (Exception ex) {
                    Toast.makeText(this, "没有可用的外部播放器", Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    // ================= 适配器 =================
    class ListAdapter extends RecyclerView.Adapter<ListAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView tv, tvSub;
            ImageView iv;
            VH(View v) { super(v); tv = v.findViewById(R.id.tvName); tvSub = v.findViewById(R.id.tvSub); iv = v.findViewById(R.id.ivCover); }
        }
        @Override public VH onCreateViewHolder(android.view.ViewGroup p, int t) {
            return new VH(getLayoutInflater().inflate(R.layout.item_anime, p, false));
        }
        @Override public void onBindViewHolder(VH h, int pos) {
            Anime a = animeList.get(pos);
            h.tv.setText(a.display);
            // 封面
            if (a.cover != null && !a.cover.isEmpty()) {
                h.iv.setVisibility(View.VISIBLE);
                Glide.with(MainActivity.this).load(a.cover)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .centerCrop()
                        .override(200, 120)
                        .placeholder(R.color.bg_panel)
                        .error(R.color.bg_panel)
                        .into(h.iv);
            } else {
                h.iv.setVisibility(View.GONE);
            }
            // 副标题
            if (a.premiere != null && !a.premiere.isEmpty()) {
                h.tvSub.setVisibility(View.VISIBLE);
                h.tvSub.setText(a.premiere + " | " + a.status);
            } else {
                h.tvSub.setVisibility(View.GONE);
            }
            h.itemView.setOnClickListener(v -> onItemClick(a));
            h.itemView.setOnFocusChangeListener((v, has) -> {
                h.tv.setTextColor(has ? getResources().getColor(R.color.text_focus)
                                      : getResources().getColor(R.color.text_primary));
            });
        }
        @Override public int getItemCount() { return animeList.size(); }
    }

    class EpAdapter extends RecyclerView.Adapter<EpAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView tv;
            VH(View v) { super(v); tv = v.findViewById(R.id.tvEp); }
        }
        @Override public VH onCreateViewHolder(android.view.ViewGroup p, int t) {
            return new VH(getLayoutInflater().inflate(R.layout.item_episode, p, false));
        }
        @Override public void onBindViewHolder(VH h, int pos) {
            Episode e = epList.get(pos);
            h.tv.setText(e.title);
            h.itemView.setOnClickListener(v -> selectEp(pos));
            h.itemView.setOnFocusChangeListener((v, has) -> {
                h.tv.setTextColor(has ? getResources().getColor(R.color.text_focus)
                                      : getResources().getColor(R.color.text_primary));
            });
        }
        @Override public int getItemCount() { return epList.size(); }
    }

    private void onItemClick(Anime a) {
        if (listMode.equals("history")) {
            for (HistoryStore.Item it : history.load()) {
                if (it.aid == a.id) { openAnime(a, it.epIndex, it.line); return; }
            }
        }
        openAnime(a, 0, null);
    }

    // ================= 遥控器返回键 =================
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (detail != null) {
                detail = null;
                epList.clear();
                epAdapter.notifyDataSetChanged();
                showHome();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }
}
