package com.animetv.util;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 播放历史 (SharedPreferences 持久化) */
public class HistoryStore {
    private static final String PREFS = "animetv";
    private static final String KEY = "history";

    public static class Item {
        public int aid;
        public String name = "";
        public String ep = "";
        public int epIndex;
        public String line = "";
    }

    private final SharedPreferences sp;

    public HistoryStore(Context ctx) {
        sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized List<Item> load() {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.aid = o.optInt("aid");
                it.name = o.optString("name");
                it.ep = o.optString("ep");
                it.epIndex = o.optInt("epIndex");
                it.line = o.optString("line");
                if (it.aid > 0) out.add(it);
            }
        } catch (Exception ignored) {}
        return out;
    }

    public synchronized void add(int aid, String name, String ep, int epIndex, String line) {
        try {
            List<Item> list = load();
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).aid == aid) { list.remove(i); break; }
            }
            Item it = new Item();
            it.aid = aid; it.name = name; it.ep = ep; it.epIndex = epIndex; it.line = line;
            list.add(0, it);
            while (list.size() > 20) list.remove(list.size() - 1);
            JSONArray arr = new JSONArray();
            for (Item x : list) {
                JSONObject o = new JSONObject();
                o.put("aid", x.aid); o.put("name", x.name); o.put("ep", x.ep);
                o.put("epIndex", x.epIndex); o.put("line", x.line);
                arr.put(o);
            }
            sp.edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {}
    }
}
