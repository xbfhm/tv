package com.animetv.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Request;
import okhttp3.Response;

/**
 * 弹幕数据源: B站弹幕 (免注册, 家庭网络可用)
 * 流程: buvid3 cookie -> 标题搜索番剧(season_id) -> 分集cid -> 弹幕XML
 * 限制: B站无版权的番没有弹幕 (如海贼王); 失败返回空(自动降级不影响播放)
 */
public class DanmakuApi {
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36";
    private static final String SPI = "https://api.bilibili.com/x/frontend/finger/spi";
    private static final String SEARCH = "https://api.bilibili.com/x/web-interface/search/type?search_type=media_bangumi&keyword=";
    private static final String SEASON = "https://api.bilibili.com/pgc/view/web/season?season_id=";
    private static final String DM = "https://api.bilibili.com/x/v1/dm/list.so?oid=";
    private static final Pattern DM_PATTERN = Pattern.compile("<d p=\"([^\"]+)\">([^<]*)</d>");

    public static class Item {
        public float time;
        public int type;      // 1=滚动 4=底部 5=顶部
        public int color;     // 0xRRGGBB
        public String text;
    }

    /** 主入口: 番剧标题 + 集号 -> 弹幕列表 (失败返回空列表, 不抛异常) */
    public static List<Item> fetchDanmaku(String title, int epNum) {
        try {
            String cookie = getBiliCookie();
            if (cookie == null || cookie.isEmpty()) return new ArrayList<>();
            int seasonId = searchSeason(title, cookie);
            if (seasonId <= 0) return new ArrayList<>();
            int cid = findCid(seasonId, epNum, cookie);
            if (cid <= 0) return new ArrayList<>();
            return parseXml(get(DM + cid, cookie));
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private static String getBiliCookie() throws Exception {
        JSONObject d = new JSONObject(get(SPI, ""));
        return "buvid3=" + d.optJSONObject("data").optString("b_3", "");
    }

    private static int searchSeason(String title, String cookie) throws Exception {
        String json = get(SEARCH + java.net.URLEncoder.encode(title, "UTF-8"), cookie);
        JSONObject d = new JSONObject(json);
        JSONArray items = d.optJSONObject("data").optJSONObject("result").optJSONArray("media_bangumi");
        if (items == null || items.length() == 0) return 0;
        String t = title == null ? "" : title.trim();
        int best = 0;
        double bestScore = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.getJSONObject(i);
            int sid = it.optInt("season_id");
            String name = stripHtml(it.optString("title", ""));
            double s = similarity(t, name);
            if (s > bestScore) { bestScore = s; best = sid; }
        }
        return bestScore > 0.25 ? best : 0;
    }

    private static int findCid(int seasonId, int epNum, String cookie) throws Exception {
        String json = get(SEASON + seasonId, cookie);
        JSONObject d = new JSONObject(json);
        JSONArray eps = d.optJSONObject("result").optJSONArray("episodes");
        if (eps == null || eps.length() == 0) return 0;
        for (int i = 0; i < eps.length(); i++) {
            JSONObject e = eps.getJSONObject(i);
            String t = e.optString("title", "");
            if (extractNum(t) == epNum) return e.optInt("cid");
        }
        if (epNum > 0 && epNum <= eps.length()) return eps.getJSONObject(epNum - 1).optInt("cid");
        return eps.getJSONObject(0).optInt("cid");
    }

    private static List<Item> parseXml(String xml) {
        List<Item> out = new ArrayList<>();
        if (xml == null) return out;
        Matcher m = DM_PATTERN.matcher(xml);
        while (m.find()) {
            String[] p = m.group(1).split(",");
            if (p.length < 3) continue;
            Item it = new Item();
            try { it.time = Float.parseFloat(p[0]); } catch (Exception e) { continue; }
            try { it.type = Integer.parseInt(p[1]); } catch (Exception e) { it.type = 1; }
            // B站/弹弹play 颜色都是十进制 (如 16777215=白色)
            try { it.color = Integer.parseInt(p[2]) & 0xFFFFFF; } catch (Exception e) { it.color = 0xFFFFFF; }
            it.text = m.group(2);
            if (it.text != null && !it.text.isEmpty() && it.time >= 0) out.add(it);
        }
        return out;
    }

    private static String get(String url, String cookie) throws Exception {
        Request.Builder b = new Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Referer", "https://www.bilibili.com/")
                .header("Accept", "*/*");
        if (cookie != null && !cookie.isEmpty()) b.header("Cookie", cookie);
        try (Response resp = com.animetv.api.AgeApi.getClient().newCall(b.build()).execute()) {
            if (!resp.isSuccessful()) throw new Exception("HTTP " + resp.code());
            return resp.body() != null ? resp.body().string() : "";
        }
    }

    private static String stripHtml(String s) {
        return s == null ? "" : s.replaceAll("<[^>]+>", "");
    }

    private static int extractNum(String s) {
        Matcher m = Pattern.compile("\\d+").matcher(s == null ? "" : s);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    private static double similarity(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        String sa = a.replaceAll("\\s+", ""), sb = b.replaceAll("\\s+", "");
        if (sa.equals(sb)) return 1.0;
        if (sa.contains(sb) || sb.contains(sa)) return 0.9;
        int common = 0;
        for (char c : sa.toCharArray()) if (sb.indexOf(c) >= 0) common++;
        return 0.6 * common / Math.max(sa.length(), sb.length());
    }
}
