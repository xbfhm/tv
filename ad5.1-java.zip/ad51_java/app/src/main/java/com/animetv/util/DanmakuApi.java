package com.animetv.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Request;
import okhttp3.Response;

/**
 * 弹幕数据源: 弹弹play (DanDanPlay) API — 与 Kazumi(28k★) 同款方案
 * 流程: 标题搜索匹配番剧 -> bangumi/{id} 拿集 -> comment/{epId} 弹幕XML
 * 注意: 官方接口可能需要开发者token, 部分网络匿名可用; 失败时返回空列表(弹幕功能自动降级)
 */
public class DanmakuApi {
    private static final String BASE = "https://api.dandanplay.net/api/v2/";
    private static final Pattern DM_PATTERN = Pattern.compile("<d p=\"([^\"]+)\">([^<]*)</d>");

    public static class Item {
        public float time;     // 秒
        public int type;       // 1=滚动 4=底部 5=顶部
        public int color;      // 0xRRGGBB
        public String text;
    }

    private static String get(String url) throws IOException {
        Request req = new Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .header("Accept", "application/json,text/xml,*/*")
                .build();
        try (Response resp = com.animetv.api.AgeApi.getClient().newCall(req).execute()) {
            if (!resp.isSuccessful()) throw new IOException("HTTP " + resp.code());
            String body = resp.body() != null ? resp.body().string() : "";
            return body;
        }
    }

    /** 标题搜索 -> 最佳匹配番剧ID (简单相似度: 完全包含优先, 其次长度比) */
    public static int searchAnime(String title) {
        try {
            String json = get(BASE + "search/anime?anime=" + java.net.URLEncoder.encode(title, "UTF-8"));
            JSONObject d = new JSONObject(json);
            JSONArray animes = d.optJSONArray("animes");
            if (animes == null) return 0;
            String t = title == null ? "" : title.trim();
            int bestId = 0;
            double bestScore = 0;
            for (int i = 0; i < animes.length(); i++) {
                JSONObject a = animes.getJSONObject(i);
                int id = a.optInt("animeId");
                String name = a.optString("animeTitle", "");
                if (id < 2 || id >= 100000) continue;
                double score = similarity(t, name);
                if (score > bestScore) { bestScore = score; bestId = id; }
            }
            return bestScore > 0.3 ? bestId : 0;   // 相似度阈值
        } catch (Exception e) {
            return 0;
        }
    }

    /** 番剧ID + 集号 -> 弹幕episodeId */
    public static int findEpisode(int animeId, int epNum) {
        try {
            String json = get(BASE + "bangumi/" + animeId);
            JSONObject d = new JSONObject(json);
            JSONArray eps = d.optJSONArray("episodes");
            if (eps == null) return 0;
            // 优先集号匹配, 否则按序号
            for (int i = 0; i < eps.length(); i++) {
                JSONObject e = eps.getJSONObject(i);
                String t = e.optString("episodeTitle", "");
                if (t.matches(".*\\d+.*") && extractNum(t) == epNum) return e.optInt("episodeId");
            }
            if (epNum > 0 && epNum <= eps.length()) {
                return eps.getJSONObject(epNum - 1).optInt("episodeId");
            }
            return eps.getJSONObject(0).optInt("episodeId");
        } catch (Exception e) {
            return 0;
        }
    }

    /** 拉取弹幕 XML -> 弹幕列表 */
    public static List<Item> getComments(int episodeId) {
        List<Item> out = new ArrayList<>();
        try {
            String xml = get(BASE + "comment/" + episodeId);
            Matcher m = DM_PATTERN.matcher(xml);
            while (m.find()) {
                String[] p = m.group(1).split(",");
                if (p.length < 3) continue;
                Item it = new Item();
                try { it.time = Float.parseFloat(p[0]); } catch (Exception e) { continue; }
                try { it.type = Integer.parseInt(p[1]); } catch (Exception e) { it.type = 1; }
                try { it.color = (int) Long.parseLong(p[2], 16) & 0xFFFFFF; } catch (Exception e) { it.color = 0xFFFFFF; }
                it.text = m.group(2);
                if (it.text != null && !it.text.isEmpty() && it.time >= 0) out.add(it);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static int extractNum(String s) {
        Matcher m = Pattern.compile("\\d+").matcher(s);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    /** 简单标题相似度 (0~1): 包含 + 公共前缀 */
    private static double similarity(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        String sa = a.replaceAll("\\s+", ""), sb = b.replaceAll("\\s+", "");
        if (sa.equals(sb)) return 1.0;
        if (sa.contains(sb) || sb.contains(sa)) return 0.9;
        // 字符重合率
        int common = 0;
        for (char c : sa.toCharArray()) {
            if (sb.indexOf(c) >= 0) common++;
        }
        return 0.6 * common / Math.max(sa.length(), sb.length());
    }
}
