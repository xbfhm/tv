package com.animetv;

import android.app.Application;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 全局崩溃捕获: 闪退时把堆栈写入文件, 便于排障 */
public class AnimeTVApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                File dir = getExternalFilesDir(null);
                if (dir == null) dir = getFilesDir();
                File f = new File(dir, "crash.txt");
                try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
                    pw.println("===== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                            .format(new Date()) + " =====");
                    throwable.printStackTrace(pw);
                }
                Log.e("AnimeTV", "CRASH", throwable);
            } catch (Exception ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        });
    }
}
