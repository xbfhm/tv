package com.animetv;

import android.app.Application;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 全局崩溃捕获: 闪退时把堆栈写入文件, 便于排障 */
public class AnimeTVApp extends Application {
    private static String TAG = "AnimeTV";

    /** 启动/崩溃打点: 每步写一行, 闪退后能看出卡在哪一步 */
    public static void log(String msg) {
        try {
            File dir = null;
            try {
                if (AnimeTVApp.app != null) dir = AnimeTVApp.app.getExternalFilesDir(null);
            } catch (Exception ignored) {}
            if (dir == null) dir = new File("/sdcard/Android/data/com.animetv/files");
            dir.mkdirs();
            File f = new File(dir, "startup.log");
            try (PrintWriter pw = new PrintWriter(new FileWriter(f, true))) {
                pw.println(new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date()) + " " + msg);
            }
        } catch (Exception ignored) {}
    }

    public static AnimeTVApp app;

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        log("APP onCreate");
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                File dir = getExternalFilesDir(null);
                if (dir == null) dir = getFilesDir();
                File f = new File(dir, "crash.txt");
                try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
                    pw.println("===== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                            .format(new Date()) + " =====");
                    throwable.printStackTrace(pw);
                }
                Log.e("AnimeTV", "CRASH", throwable);
                log("CRASH: " + throwable.toString());
            } catch (Exception ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        });
    }
}
