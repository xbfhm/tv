package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 内置浏览器: 打开任意网站/网页版番剧源
 * - 地址栏 (可输入网址) + 后退/前进/刷新/主页
 * - 网页内链接直接在当前页打开
 * - 全屏沉浸 (电视遥控器可操作: 左右键切换按钮)
 */
public class WebPlayActivity extends Activity {

    private WebView webView;
    private EditText urlBar;
    private String homeUrl = "https://anime7.top/";
    private int chromeVer = 0;                 // 系统 WebView 版本
    private TextView tipBar;                   // 兼容提示条

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String url = getIntent().getStringExtra("url");
        if (url != null && !url.isEmpty()) homeUrl = url;

        // 检测系统 WebView 版本 (老版本电视兼容模式)
        try {
            Matcher m = Pattern.compile("Chrome/(\\d+)")
                    .matcher(new WebView(this).getSettings().getUserAgentString());
            if (m.find()) chromeVer = Integer.parseInt(m.group(1));
        } catch (Exception ignored) {}

        // ===== 根布局 (竖排: 提示条 + 工具栏 + WebView) =====
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#101018"));

        // 老 WebView 提示条
        if (chromeVer > 0 && chromeVer < 60) {
            tipBar = new TextView(this);
            tipBar.setText("系统浏览器版本过旧 (Chrome " + chromeVer + "), 网页可能白屏。建议: 手机打开 或 试 m.agedm.io");
            tipBar.setTextColor(Color.parseColor("#1A1A1A"));
            tipBar.setTextSize(13);
            tipBar.setBackgroundColor(Color.parseColor("#FFD54F"));
            tipBar.setPadding(dp(8), dp(6), dp(8), dp(6));
            root.addView(tipBar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            // 老设备 Mali-450 硬件加速白屏: 用软件渲染
            // (在 webView 创建后设置)
        }

        // ===== 工具栏 =====
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(4), dp(6), dp(4));
        bar.setBackgroundColor(Color.parseColor("#1A1A24"));

        Button btnBack = mkButton("◀", 48);
        Button btnFwd  = mkButton("▶", 48);
        Button btnGo   = mkButton("打开", 64);
        Button btnHome = mkButton("主页", 64);

        urlBar = new EditText(this);
        urlBar.setText(homeUrl);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setTextSize(14);
        urlBar.setSingleLine(true);
        urlBar.setBackgroundColor(Color.parseColor("#232330"));
        urlBar.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams lpBar = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lpBar.setMargins(dp(4), 0, dp(4), 0);
        urlBar.setLayoutParams(lpBar);

        bar.addView(btnBack);
        bar.addView(btnFwd);
        bar.addView(urlBar);
        bar.addView(btnGo);
        bar.addView(btnHome);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        // ===== WebView =====
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        // 老 WebView / Mali-450: 软件渲染避免白屏
        if (chromeVer > 0 && chromeVer < 60) {
            webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                urlBar.setText(url);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(WebPlayActivity.this, "网页加载失败: " + description, Toast.LENGTH_LONG).show();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        // ===== 按钮事件 =====
        btnBack.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        btnFwd.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });
        btnGo.setOnClickListener(v -> openUrl(urlBar.getText().toString()));
        // 老 WebView: 主页用 AGE 官方网页版 (老站兼容旧浏览器)
        if (chromeVer > 0 && chromeVer < 60 && homeUrl.equals("https://anime7.top/")) {
            homeUrl = "https://m.agedm.io/";
            urlBar.setText(homeUrl);
        }
        btnHome.setOnClickListener(v -> openUrl(homeUrl));

        webView.loadUrl(homeUrl);
        hideSystemUi();
    }

    private void openUrl(String u) {
        if (u == null) return;
        u = u.trim();
        if (u.isEmpty()) return;
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
        webView.loadUrl(u);
    }

    private Button mkButton(String text, int w) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.parseColor("#2A2A3A"));
        b.setMinHeight(dp(40));
        b.setPadding(dp(8), 0, dp(8), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(w), dp(42));
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (urlBar.isFocused()) {
                urlBar.clearFocus();
                webView.requestFocus();
                return true;
            }
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
                return true;
            }
            finish();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            if (webView != null) webView.requestFocus();
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webView != null) { webView.destroy(); webView = null; }
    }
}
