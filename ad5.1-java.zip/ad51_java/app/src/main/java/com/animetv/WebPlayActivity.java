package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 内置浏览器: 打开任意网站/网页版番剧源
 * 双引擎: 手机新 WebView 直用; 电视老 WebView(Chromium<60) 自动切 GeckoView(Firefox 91 现代内核)
 */
public class WebPlayActivity extends Activity {

    private WebView webView;
    private EditText urlBar;
    private String homeUrl = "https://anime7.top/";
    private int chromeVer = 0;                 // 系统 WebView 版本
    private TextView tipBar;                   // 兼容提示条
    private TextView statusBar;                // 加载状态条
    private ProgressBar progressBar;           // 加载进度

    // GeckoView (电视老 WebView 兜底)
    private boolean useGecko = false;
    private GeckoRuntime gkRuntime;
    private GeckoSession gkSession;
    private GeckoView gkView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String url = getIntent().getStringExtra("url");
        if (url != null && !url.isEmpty()) homeUrl = url;

        // 检测系统 WebView 版本: <60 (电视 2016 Chromium44) 用 GeckoView
        try {
            Matcher m = Pattern.compile("Chrome/(\\d+)")
                    .matcher(new WebView(this).getSettings().getUserAgentString());
            if (m.find()) chromeVer = Integer.parseInt(m.group(1));
            if (chromeVer > 0 && chromeVer < 60) useGecko = true;
        } catch (Exception ignored) {}

        // ===== 根布局 (竖排: 提示条 + 工具栏 + 状态条 + 进度条 + 内容) =====
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#101018"));

        // 老 WebView 提示条
        if (chromeVer > 0 && chromeVer < 60) {
            tipBar = new TextView(this);
            tipBar.setText("检测到旧版浏览器, 已启用内置 Firefox 内核 (电视老系统兼容)");
            tipBar.setTextColor(Color.parseColor("#1A1A1A"));
            tipBar.setTextSize(13);
            tipBar.setBackgroundColor(Color.parseColor("#FFD54F"));
            tipBar.setPadding(dp(8), dp(6), dp(8), dp(6));
            root.addView(tipBar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // ===== 工具栏 =====
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(4), dp(6), dp(4));
        bar.setBackgroundColor(Color.parseColor("#1A1A24"));

        Button btnBack = mkButton("◀", 48);
        Button btnFwd  = mkButton("▶", 48);
        Button btnGo   = mkButton("打开", 64);
        Button btnHome = mkButton("主页", 64);

        urlBar = new EditText(this);
        urlBar.setText(homeUrl);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setTextSize(14);
        urlBar.setSingleLine(true);
        urlBar.setBackgroundColor(Color.parseColor("#232330"));
        urlBar.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams lpBar = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lpBar.setMargins(dp(4), 0, dp(4), 0);
        urlBar.setLayoutParams(lpBar);

        bar.addView(btnBack);
        bar.addView(btnFwd);
        bar.addView(urlBar);
        bar.addView(btnGo);
        bar.addView(btnHome);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        // ===== 加载状态条 + 进度条 =====
        statusBar = new TextView(this);
        statusBar.setText("就绪");
        statusBar.setTextColor(Color.parseColor("#9AA0B0"));
        statusBar.setTextSize(12);
        statusBar.setPadding(dp(10), dp(2), dp(10), dp(2));
        root.addView(statusBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setMinimumHeight(dp(3));
        root.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        // ===== 内容区 (双引擎) =====
        if (useGecko) {
            initGeckoView(root);
        } else {
            initWebView(root);
        }

        setContentView(root);

        // ===== 按钮事件 =====
        btnBack.setOnClickListener(v -> {
            if (useGecko) { if (gkSession != null) gkSession.goBack(); }
            else if (webView != null && webView.canGoBack()) webView.goBack();
        });
        btnFwd.setOnClickListener(v -> {
            if (useGecko) { if (gkSession != null) gkSession.goForward(); }
            else if (webView != null && webView.canGoForward()) webView.goForward();
        });
        btnGo.setOnClickListener(v -> {
            String u = urlBar.getText().toString().trim();
            if (u.isEmpty()) { statusBar.setText("请输入网址"); return; }
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
            statusBar.setText("加载中: " + shortUrl(u));
            load(u);
        });
        btnHome.setOnClickListener(v -> {
            statusBar.setText("回主页: " + shortUrl(homeUrl));
            load(homeUrl);
        });

        load(homeUrl);
        hideSystemUi();
    }

    /** 系统 WebView 引擎 (手机等新版 WebView) */
    private void initWebView(LinearLayout root) {
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                urlBar.setText(url);
                statusBar.setText("加载中: " + shortUrl(url));
                progressBar.setProgress(5);
            }
            @Override public void onPageFinished(WebView view, String url) {
                urlBar.setText(url);
                statusBar.setText("✓ 完成: " + shortUrl(url));
                progressBar.setProgress(100);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                statusBar.setText("加载失败: " + description);
                Toast.makeText(WebPlayActivity.this, "网页加载失败: " + description, Toast.LENGTH_LONG).show();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    /** GeckoView 引擎 (电视老 WebView 兜底, Firefox 91 现代内核) */
    private void initGeckoView(LinearLayout root) {
        try {
            gkRuntime = GeckoRuntime.create(this);
            gkSession = new GeckoSession();
            gkSession.open(gkRuntime);
            gkView = new GeckoView(this);
            gkView.setSession(gkSession);

            gkSession.setProgressDelegate(new GeckoSession.ProgressDelegate() {
                @Override public void onProgressChange(GeckoSession session, int progress) {
                    progressBar.setProgress(progress);
                }
                @Override public void onPageStart(GeckoSession session, String url) {
                    urlBar.setText(url);
                    statusBar.setText("加载中: " + shortUrl(url));
                    progressBar.setProgress(5);
                }
                @Override public void onPageStop(GeckoSession session, boolean success) {
                    statusBar.setText(success ? "✓ 完成" : "加载失败");
                    progressBar.setProgress(100);
                }
            });
            gkSession.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
                @Override public void onLocationChange(GeckoSession session, String url) {
                    urlBar.setText(url);
                }
                @Override public org.mozilla.geckoview.GeckoResult<String> onLoadError(
                        GeckoSession session, String uri, org.mozilla.geckoview.WebRequestError err) {
                    statusBar.setText("加载失败: " + (err != null ? err.getMessage() : "未知"));
                    return null;
                }
            });

            root.addView(gkView, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        } catch (Exception e) {
            useGecko = false;
            initWebView(root);   // 降级: GeckoView 初始化失败用系统 WebView
        }
    }

    /** 统一加载 */
    private void load(String u) {
        if (useGecko) { if (gkSession != null) gkSession.loadUri(u); }
        else if (webView != null) webView.loadUrl(u);
    }

    private Button mkButton(String text, int w) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.parseColor("#2A2A3A"));
        b.setMinHeight(dp(40));
        b.setPadding(dp(8), 0, dp(8), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(w), dp(42));
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private String shortUrl(String u) {
        if (u == null) return "";
        String s = u.replace("https://", "").replace("http://", "");
        return s.length() > 40 ? s.substring(0, 40) + "..." : s;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (urlBar.isFocused()) {
                urlBar.clearFocus();
                return true;
            }
            if (useGecko) {
                if (gkSession != null) gkSession.goBack();
                else finish();
                return true;
            }
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
                return true;
            }
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (gkSession != null) { gkSession.close(); gkSession = null; }
            if (gkRuntime != null) { gkRuntime.shutdown(); gkRuntime = null; }
        } catch (Exception ignored) {}
        if (webView != null) { webView.destroy(); webView = null; }
    }
}
