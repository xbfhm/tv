package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.common.TrackSelectionParameters;
import java.util.HashMap;
import java.util.Map;
import androidx.media3.ui.PlayerView;

import com.animetv.api.AgeApi;
import com.animetv.model.Episode;
import com.animetv.util.HistoryStore;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 内置播放器 v3: 沉浸全屏 + 进度条(可调) + 倍速 + 自动连播
 * OK=唤出控制条, ←→=快进/快退(焦点在进度条时=调进度), ↑↓=音量, 返回=退出
 */
public class PlayerActivity extends Activity {

    private static final float[] SPEEDS = {1.0f, 1.25f, 1.5f, 2.0f, 0.75f, 0.5f};

    // 画质预设: [名称, 最大宽, 最大高, 最大码率bps]
    private static final String[][] QUALITY = {
            {"自适应", "100000", "100000", "100000000"},
            {"1080p", "1920", "1080", "8000000"},
            {"720p",  "1280", "720",  "4000000"},
            {"480p",  "854",  "480",  "1500000"},
            {"360p",  "640",  "360",  "800000"}
    };
    private int qualityIdx = 2;   // 默认 720p: 快速起播

    private PlayerView playerView;
    private TextView tvNowPlaying, tvProgress;
    private LinearLayout controlBar, loadingBox;
    private Button btnPause, btnSpeed, btnQuality;
    private SeekBar seekBar;
    private ExoPlayer player;
    private DefaultTrackSelector trackSelector;
    private final ExecutorService pool = Executors.newFixedThreadPool(1);
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String url, title, animeName, line, jxZj, jxVip;
    private int animeId, epIndex;
    private ArrayList<Episode> episodes;
    private AudioManager audioManager;

    private boolean controlVisible = false;
    private boolean seekBarTouching = false;
    private int speedIdx = 0;

    private final Runnable hideControl = () -> showControl(false);
    private final Runnable updateProgress = new Runnable() {
        @Override public void run() {
            if (player != null && controlVisible) {
                long durMs = player.getDuration();
                long posMs = player.getCurrentPosition();
                if (durMs > 0) {
                    long dur = durMs / 1000, pos = posMs / 1000;
                    tvProgress.setText(fmt(pos) + "/" + fmt(dur));
                    if (!seekBarTouching) {
                        seekBar.setMax((int) dur);
                        seekBar.setProgress((int) pos);
                    }
                }
            }
            handler.postDelayed(this, 500);
        }
    };

    private static String fmt(long s) {
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    private static String fmtSpeed(float s) {
        if (s == Math.floor(s)) return ((int) s) + ".0x";
        return s + "x";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        Intent it = getIntent();
        url = it.getStringExtra("url");
        title = it.getStringExtra("title");
        animeId = it.getIntExtra("animeId", 0);
        epIndex = it.getIntExtra("epIndex", 0);
        line = it.getStringExtra("line");
        episodes = (ArrayList<Episode>) it.getSerializableExtra("episodes");
        animeName = it.getStringExtra("animeName");
        jxZj = it.getStringExtra("jxZj");
        jxVip = it.getStringExtra("jxVip");
        if (episodes == null) episodes = new ArrayList<>();
        if (jxZj == null) jxZj = "https://jx.wuzhoupai.com:8443/m3u8/?url=";
        if (jxVip == null) jxVip = "https://jx.wuzhoupai.com:8443/vip/?url=";

        playerView = findViewById(R.id.playerView);
        tvNowPlaying = findViewById(R.id.tvNowPlaying);
        tvProgress = findViewById(R.id.tvProgress);
        controlBar = findViewById(R.id.controlBar);
        loadingBox = findViewById(R.id.loadingBox);
        btnPause = findViewById(R.id.btnPause);
        btnSpeed = findViewById(R.id.btnSpeed);
        btnQuality = findViewById(R.id.btnQuality);
        seekBar = findViewById(R.id.seekBar);
        if (title != null) tvNowPlaying.setText(title);

        // ---- 进度条: 触摸拖动 + 遥控器左右键调节 ----
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && player != null) {
                    player.seekTo((long) progress * 1000);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { seekBarTouching = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) { seekBarTouching = false; }
        });

        // ---- 倍速循环 ----
        btnSpeed.setText(fmtSpeed(SPEEDS[0]));
        btnSpeed.setOnClickListener(v -> cycleSpeed());

        findViewById(R.id.btnPause).setOnClickListener(v -> togglePlay());
        findViewById(R.id.btnPrevEp).setOnClickListener(v -> loadEp(epIndex - 1));
        findViewById(R.id.btnNextEp).setOnClickListener(v -> loadEp(epIndex + 1));
        findViewById(R.id.btnExtPlay).setOnClickListener(v -> externalPlay());
        findViewById(R.id.btnExit).setOnClickListener(v -> finish());

        // 触摸屏幕: 唤出/收起控制条 (手机端无OK键)
        findViewById(android.R.id.content).setOnClickListener(v -> toggleControl());
        playerView.setOnClickListener(v -> toggleControl());

        initPlayer();
        playUrl(url);
        handler.post(updateProgress);
    }

    private void toggleControl() {
        showControl(!controlVisible);
    }

    /** 按当前画质预设生成 TrackSelection 参数 */
    private TrackSelectionParameters qualityParams(DefaultTrackSelector ts) {
        String[] q = QUALITY[qualityIdx];
        return ts.buildUponParameters()
                .setMaxVideoSize(Integer.parseInt(q[1]), Integer.parseInt(q[2]))
                .setMaxVideoBitrate(Integer.parseInt(q[3]))
                .build();
    }

    /** 循环切换画质 (运行时立即生效) */
    private void cycleQuality() {
        qualityIdx = (qualityIdx + 1) % QUALITY.length;
        trackSelector.setParameters(qualityParams(trackSelector));
        btnQuality.setText(QUALITY[qualityIdx][0]);
        Toast.makeText(this, "画质: " + QUALITY[qualityIdx][0], Toast.LENGTH_SHORT).show();
    }

    private void initPlayer() {
        trackSelector = new DefaultTrackSelector(this);
        trackSelector.setParameters(qualityParams(trackSelector));
        btnQuality.setText(QUALITY[qualityIdx][0]);
        btnQuality.setOnClickListener(v -> cycleQuality());
        // OkHttp 数据源: 复用 AgeApi 的全信任证书 client + 现代TLS
        // (解决 Android 5.1 系统CA库旧导致视频CDN证书验证失败 -> 网络连接错误)
        Map<String, String> headers = new HashMap<>();
        headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 7.0; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0 Mobile Safari/537.36");
        headers.put("Referer", "https://www.agedm.io/");
        OkHttpDataSource.Factory dataSourceFactory = new OkHttpDataSource.Factory(AgeApi.getClient())
                .setDefaultRequestProperties(headers);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSourceFactory))
                .setTrackSelector(trackSelector)
                .build();
        playerView.setUseController(false);   // 自定义控制条
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    loadingBox.setVisibility(View.VISIBLE);
                } else {
                    loadingBox.setVisibility(View.GONE);
                }
                if (state == Player.STATE_ENDED) {
                    Toast.makeText(PlayerActivity.this, "本集播完, 自动下一集", Toast.LENGTH_SHORT).show();
                    loadEp(epIndex + 1);
                }
            }
            @Override public void onPlayerError(PlaybackException e) {
                loadingBox.setVisibility(View.GONE);
                int errCode = e.errorCode;
                // 所有 IO 类错误(1000-1999): 网络/超时/HTTP状态/文件等 一律自动换源
                boolean networkErr = errCode >= 1000 && errCode < 2000;
                if (networkErr && !switchingLine) {
                    Toast.makeText(PlayerActivity.this, "网络异常, 自动切换线路重试...", Toast.LENGTH_SHORT).show();
                    switchLineAuto();
                } else {
                    Toast.makeText(PlayerActivity.this, "播放出错: " + e.getErrorCodeName(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void playUrl(String u) {
        player.setMediaItem(MediaItem.fromUri(Uri.parse(u)));
        player.setPlaybackSpeed(SPEEDS[speedIdx]);   // 跨集保持倍速
        player.prepare();
        player.play();
    }

    private void cycleSpeed() {
        speedIdx = (speedIdx + 1) % SPEEDS.length;
        player.setPlaybackSpeed(SPEEDS[speedIdx]);
        btnSpeed.setText(fmtSpeed(SPEEDS[speedIdx]));
        Toast.makeText(this, "倍速 " + fmtSpeed(SPEEDS[speedIdx]), Toast.LENGTH_SHORT).show();
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.isPlaying()) player.pause(); else player.play();
        btnPause.setText(player.isPlaying() ? "⏸ 暂停" : "▶ 播放");
    }

    private void seekBy(long sec) {
        if (player == null) return;
        player.seekTo(Math.max(0, player.getCurrentPosition() + sec * 1000));
    }

    private void adjustVolume(int dir) {
        if (audioManager != null) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
        }
    }

    private boolean switchingLine = false;

    /** 网络错误时: 自动切换到下一条线路重试当前集 */
    private void switchLineAuto() {
        if (episodes.isEmpty() || switchingLine) return;
        List<String> lines = new ArrayList<>();
        for (Episode e : episodes) if (!lines.contains(e.line)) lines.add(e.line);
        if (lines.size() <= 1) { switchingLine = false; return; }
        int i = lines.indexOf(line);
        line = lines.get((i + 1) % lines.size());
        switchingLine = true;
        int order = lines.indexOf(line) + 1;
        Toast.makeText(this, "切换到第 " + order + " 个播放源: " + line, Toast.LENGTH_SHORT).show();
        loadEp(epIndex);
    }

    // ================= 控制条显示/隐藏 =================
    private void showControl(boolean show) {
        controlVisible = show;
        controlBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            btnPause.setText(player != null && player.isPlaying() ? "⏸ 暂停" : "▶ 播放");
            handler.removeCallbacks(hideControl);
            handler.postDelayed(hideControl, 6000);
        } else {
            handler.removeCallbacks(hideControl);
        }
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    // ================= 加载指定集 =================
    private void loadEp(int i) {
        if (i < 0 || i >= episodes.size()) {
            if (i >= episodes.size()) Toast.makeText(this, "已经是最后一集", Toast.LENGTH_SHORT).show();
            return;
        }
        final int idx = i;
        final Episode cur = episodes.get(idx);
        tvNowPlaying.setText(animeName + " " + cur.title + "  解析中...");
        loadingBox.setVisibility(View.VISIBLE);
        pool.execute(() -> {
            // 有序线路: 当前线路优先, 其余按出现顺序
            List<String> lines = new ArrayList<>();
            if (line != null && !line.isEmpty()) lines.add(line);
            for (Episode e : episodes) if (!lines.contains(e.line)) lines.add(e.line);
            int curEpNum = epNumber(cur.title);
            String u = null, usedLine = null, usedLabel = null;
            int usedOrder = 0, tried = 0;
            StringBuilder triedInfo = new StringBuilder();
            for (int li = 0; li < lines.size(); li++) {
                Episode target = findSameEpisode(lines.get(li), curEpNum, idx);
                if (target == null) continue;
                tried++;
                try {
                    u = AgeApi.resolve(target.enc, target.vip, jxZj, jxVip);
                    usedLine = target.line;
                    usedLabel = target.lineLabel;
                    usedOrder = li + 1;
                    break;   // 换源成功: 不再尝试剩下的
                } catch (Exception ignored) {
                    if (triedInfo.length() > 0) triedInfo.append("; ");
                    triedInfo.append(target.lineLabel).append("(第").append(li + 1).append("个播放源)失败");
                }
            }
            final String fu = u, fl = usedLine, flabel = usedLabel;
            final int forder = usedOrder, ftried = tried;
            final String fTried = triedInfo.toString();
            runOnUiThread(() -> {
                loadingBox.setVisibility(View.GONE);
                if (fu == null) {
                    switchingLine = false;
                    Toast.makeText(this, "全部 " + ftried + " 个播放源失败: " + fTried, Toast.LENGTH_LONG).show();
                    return;
                }
                epIndex = idx;
                line = fl;
                url = fu;
                switchingLine = false;
                tvNowPlaying.setText(animeName + " " + cur.title + " [" + flabel + " · 第" + forder + "个播放源]");
                btnPause.setText("⏸ 暂停");
                playUrl(fu);
                new HistoryStore(this).add(animeId, animeName, cur.title, idx, fl);
            });
        });
    }

    /** 从集标题提取集号 */
    private static int epNumber(String title) {
        if (title == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(title);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    /** 在指定线路里找同一集: 优先集号匹配, 否则按序号 */
    private Episode findSameEpisode(String l, int epNum, int fallbackIdx) {
        List<Episode> lineEps = new ArrayList<>();
        for (Episode e : episodes) if (e.line.equals(l)) lineEps.add(e);
        if (lineEps.isEmpty()) return null;
        if (epNum > 0) {
            for (Episode e : lineEps) if (epNumber(e.title) == epNum) return e;
        }
        return lineEps.get(Math.min(fallbackIdx, lineEps.size() - 1));
    }

    /** 外部播放器 (系统选择器) */
    private void externalPlay() {
        if (url == null) return;
        try {
            Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            it.setType(url.contains(".m3u8") ? "application/x-mpegURL" : "video/*");
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(it, "选择播放器"));
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的外部播放器", Toast.LENGTH_LONG).show();
        }
    }

    // ============ 遥控器按键 (新逻辑) ============
    // OK=暂停/播放; 单击←→=唤起进度条; 长按←→=拖动进度条; ↑↓=音量/焦点切换; 返回=退出播放
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // OK / 确认 / 媒体键: 按钮聚焦时触发按钮, 否则暂停/播放
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            View f = getCurrentFocus();
            if (f instanceof Button) {
                return super.onKeyDown(keyCode, event);   // 触发按钮
            }
            togglePlay();
            return true;
        }
        // ←→: 单击唤起进度条, 长按拖动进度
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            int dir = keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ? 1 : -1;
            boolean repeat = event.getRepeatCount() > 0;
            View f = getCurrentFocus();
            boolean onSeekBar = f == seekBar;
            boolean onButton = f instanceof Button;
            if (!controlVisible) {
                showControl(true);          // 唤起进度条
                seekBar.requestFocus();
                if (repeat) {               // 长按: 直接开始拖动
                    handler.removeCallbacks(hideControl);
                    seekBy(dir * 2);
                }
                return true;
            }
            if (onSeekBar) {
                if (repeat) {               // 长按拖动进度
                    handler.removeCallbacks(hideControl);
                    seekBy(dir * 2);
                }
                // 单击: 已唤起, 不动进度
                return true;
            }
            if (onButton) {
                return super.onKeyDown(keyCode, event);   // 按钮间移动
            }
            seekBar.requestFocus();
            if (repeat) seekBy(dir * 2);
            return true;
        }
        // ↑↓: 控制条可见时切换 进度条/按钮 焦点; 全屏时音量
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            if (controlVisible) {
                View f = getCurrentFocus();
                if (f == seekBar) {
                    findViewById(R.id.btnPause).requestFocus();
                } else if (f instanceof Button) {
                    seekBar.requestFocus();
                }
                return true;
            }
            adjustVolume(keyCode == KeyEvent.KEYCODE_DPAD_UP
                    ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER);
            return true;
        }
        // 返回: 退出播放器 (回主界面)
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
