package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;

import com.animetv.api.AgeApi;
import com.animetv.model.Episode;
import com.animetv.util.HistoryStore;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 内置播放器 v3: 沉浸全屏 + 进度条(可调) + 倍速 + 自动连播
 * OK=唤出控制条, ←→=快进/快退(焦点在进度条时=调进度), ↑↓=音量, 返回=退出
 */
public class PlayerActivity extends Activity {

    private static final float[] SPEEDS = {1.0f, 1.25f, 1.5f, 2.0f, 0.75f, 0.5f};

    private PlayerView playerView;
    private TextView tvNowPlaying, tvProgress;
    private LinearLayout controlBar, loadingBox;
    private Button btnPause, btnSpeed;
    private SeekBar seekBar;
    private ExoPlayer player;
    private final ExecutorService pool = Executors.newFixedThreadPool(1);
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String url, title, animeName, line, jxZj, jxVip;
    private int animeId, epIndex;
    private ArrayList<Episode> episodes;
    private AudioManager audioManager;

    private boolean controlVisible = false;
    private boolean seekBarTouching = false;
    private int speedIdx = 0;

    private final Runnable hideControl = () -> showControl(false);
    private final Runnable updateProgress = new Runnable() {
        @Override public void run() {
            if (player != null && controlVisible) {
                long durMs = player.getDuration();
                long posMs = player.getCurrentPosition();
                if (durMs > 0) {
                    long dur = durMs / 1000, pos = posMs / 1000;
                    tvProgress.setText(fmt(pos) + "/" + fmt(dur));
                    if (!seekBarTouching) {
                        seekBar.setMax((int) dur);
                        seekBar.setProgress((int) pos);
                    }
                }
            }
            handler.postDelayed(this, 500);
        }
    };

    private static String fmt(long s) {
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    private static String fmtSpeed(float s) {
        if (s == Math.floor(s)) return ((int) s) + ".0x";
        return s + "x";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        Intent it = getIntent();
        url = it.getStringExtra("url");
        title = it.getStringExtra("title");
        animeId = it.getIntExtra("animeId", 0);
        epIndex = it.getIntExtra("epIndex", 0);
        line = it.getStringExtra("line");
        episodes = (ArrayList<Episode>) it.getSerializableExtra("episodes");
        animeName = it.getStringExtra("animeName");
        jxZj = it.getStringExtra("jxZj");
        jxVip = it.getStringExtra("jxVip");
        if (episodes == null) episodes = new ArrayList<>();
        if (jxZj == null) jxZj = "https://jx.wuzhoupai.com:8443/m3u8/?url=";
        if (jxVip == null) jxVip = "https://jx.wuzhoupai.com:8443/vip/?url=";

        playerView = findViewById(R.id.playerView);
        tvNowPlaying = findViewById(R.id.tvNowPlaying);
        tvProgress = findViewById(R.id.tvProgress);
        controlBar = findViewById(R.id.controlBar);
        loadingBox = findViewById(R.id.loadingBox);
        btnPause = findViewById(R.id.btnPause);
        btnSpeed = findViewById(R.id.btnSpeed);
        seekBar = findViewById(R.id.seekBar);
        if (title != null) tvNowPlaying.setText(title);

        // ---- 进度条: 触摸拖动 + 遥控器左右键调节 ----
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && player != null) {
                    player.seekTo((long) progress * 1000);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { seekBarTouching = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) { seekBarTouching = false; }
        });

        // ---- 倍速循环 ----
        btnSpeed.setText(fmtSpeed(SPEEDS[0]));
        btnSpeed.setOnClickListener(v -> cycleSpeed());

        findViewById(R.id.btnPause).setOnClickListener(v -> togglePlay());
        findViewById(R.id.btnPrevEp).setOnClickListener(v -> loadEp(epIndex - 1));
        findViewById(R.id.btnNextEp).setOnClickListener(v -> loadEp(epIndex + 1));
        findViewById(R.id.btnExtPlay).setOnClickListener(v -> externalPlay());
        findViewById(R.id.btnExit).setOnClickListener(v -> finish());

        initPlayer();
        playUrl(url);
        handler.post(updateProgress);
    }

    private void initPlayer() {
        DefaultTrackSelector ts = new DefaultTrackSelector(this);
        ts.setParameters(ts.buildUponParameters()
                .setMaxVideoSize(1280, 720)
                .build());
        player = new ExoPlayer.Builder(this)
                .setTrackSelector(ts)
                .build();
        playerView.setUseController(false);   // 自定义控制条
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    loadingBox.setVisibility(View.VISIBLE);
                } else {
                    loadingBox.setVisibility(View.GONE);
                }
                if (state == Player.STATE_ENDED) {
                    Toast.makeText(PlayerActivity.this, "本集播完, 自动下一集", Toast.LENGTH_SHORT).show();
                    loadEp(epIndex + 1);
                }
            }
            @Override public void onPlayerError(PlaybackException e) {
                loadingBox.setVisibility(View.GONE);
                Toast.makeText(PlayerActivity.this, "播放出错: " + e.getErrorCodeName(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void playUrl(String u) {
        player.setMediaItem(MediaItem.fromUri(Uri.parse(u)));
        player.setPlaybackSpeed(SPEEDS[speedIdx]);   // 跨集保持倍速
        player.prepare();
        player.play();
    }

    private void cycleSpeed() {
        speedIdx = (speedIdx + 1) % SPEEDS.length;
        player.setPlaybackSpeed(SPEEDS[speedIdx]);
        btnSpeed.setText(fmtSpeed(SPEEDS[speedIdx]));
        Toast.makeText(this, "倍速 " + fmtSpeed(SPEEDS[speedIdx]), Toast.LENGTH_SHORT).show();
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.isPlaying()) player.pause(); else player.play();
        btnPause.setText(player.isPlaying() ? "⏸ 暂停" : "▶ 播放");
    }

    private void seekBy(long sec) {
        if (player == null) return;
        player.seekTo(Math.max(0, player.getCurrentPosition() + sec * 1000));
    }

    private void adjustVolume(int dir) {
        if (audioManager != null) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
        }
    }

    // ================= 控制条显示/隐藏 =================
    private void showControl(boolean show) {
        controlVisible = show;
        controlBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            btnPause.setText(player != null && player.isPlaying() ? "⏸ 暂停" : "▶ 播放");
            handler.removeCallbacks(hideControl);
            handler.postDelayed(hideControl, 6000);
        } else {
            handler.removeCallbacks(hideControl);
        }
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    // ================= 加载指定集 =================
    private void loadEp(int i) {
        if (i < 0 || i >= episodes.size()) {
            if (i >= episodes.size()) Toast.makeText(this, "已经是最后一集", Toast.LENGTH_SHORT).show();
            return;
        }
        final int idx = i;
        tvNowPlaying.setText(animeName + " " + episodes.get(i).title + "  解析中...");
        loadingBox.setVisibility(View.VISIBLE);
        pool.execute(() -> {
            String u = null;
            String usedLine = line;
            for (Episode e : episodes) {
                if (!e.line.equals(line)) continue;
                try { u = AgeApi.resolve(e.enc, e.vip, jxZj, jxVip); break; } catch (Exception ignored) {}
            }
            if (u == null) {
                for (Episode e : episodes) {
                    try { u = AgeApi.resolve(e.enc, e.vip, jxZj, jxVip); usedLine = e.line; break; }
                    catch (Exception ignored) {}
                }
            }
            final String fu = u;
            final String fl = usedLine;
            runOnUiThread(() -> {
                if (fu == null) {
                    loadingBox.setVisibility(View.GONE);
                    Toast.makeText(this, "解析失败, 请退出重试", Toast.LENGTH_LONG).show();
                    return;
                }
                epIndex = idx;
                line = fl;
                url = fu;
                Episode e = episodes.get(idx);
                tvNowPlaying.setText(animeName + " " + e.title + " [" + e.lineLabel + "]");
                btnPause.setText("⏸ 暂停");
                playUrl(fu);
                new HistoryStore(this).add(animeId, animeName, e.title, idx, fl);
            });
        });
    }

    /** 外部播放器 (系统选择器) */
    private void externalPlay() {
        if (url == null) return;
        try {
            Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            it.setType(url.contains(".m3u8") ? "application/x-mpegURL" : "video/*");
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(it, "选择播放器"));
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的外部播放器", Toast.LENGTH_LONG).show();
        }
    }

    // ============ 遥控器按键 ============
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (controlVisible) {
            // 进度条聚焦时: 左右键由 SeekBar 内部处理(调进度), 其他交给焦点导航
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                if (seekBar.hasFocus()) {
                    return super.onKeyDown(keyCode, event);   // SeekBar 调进度
                }
                return super.onKeyDown(keyCode, event);       // 移动按钮焦点
            }
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                finish();
                return true;
            }
            return super.onKeyDown(keyCode, event);
        }
        // 控制条隐藏 (全屏): 全局遥控
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            showControl(true);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { seekBy(-15); return true; }
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { seekBy(15); return true; }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) { adjustVolume(AudioManager.ADJUST_RAISE); return true; }
        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) { adjustVolume(AudioManager.ADJUST_LOWER); return true; }
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
