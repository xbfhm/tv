package com.animetv.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import com.animetv.util.DanmakuApi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 自绘弹幕层 (纯 Canvas, 零依赖, 老电视友好)
 * - 滚动弹幕(1): 从右向左; 顶部(5)/底部(4): 停留3秒
 * - 与播放进度绝对时间对齐: seek/暂停 自动正确
 * - 密度限制 + 30fps, 老 GPU 可流畅
 */
public class DanmakuOverlay extends View {
    private static final float SPEED = 150f;       // 滚动速度 px/s
    private static final int MAX_ACTIVE = 24;      // 同时最多弹幕数
    private static final int LANE_COUNT = 6;       // 轨道数
    private static final float STAY = 3f;          // 顶部/底部停留秒数

    private final List<DanmakuApi.Item> all = new ArrayList<>();
    private final List<Active> active = new ArrayList<>();
    private final Paint fill = new Paint();
    private final Paint stroke = new Paint();

    private float posMs = 0;
    private boolean playing = false;
    private long baseReal = 0;      // 内部时钟基准 (播放位置对齐)
    private boolean enabled = true;
    private int nextIdx = 0;
    private float laneH = 40f;
    private float textSize = 22f;

    private static class Active {
        DanmakuApi.Item item;
        int lane;
    }

    public DanmakuOverlay(Context ctx) {
        super(ctx);
        fill.setAntiAlias(true);
        fill.setTextSize(textSize);
        stroke.setAntiAlias(true);
        stroke.setTextSize(textSize);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3f);
        stroke.setColor(Color.BLACK);
        setFocusable(false);
        setClickable(false);
    }

    public void setData(List<DanmakuApi.Item> items) {
        all.clear();
        if (items != null) all.addAll(items);
        Collections.sort(all, new Comparator<DanmakuApi.Item>() {
            @Override public int compare(DanmakuApi.Item a, DanmakuApi.Item b) {
                return Float.compare(a.time, b.time);
            }
        });
        nextIdx = 0;
        active.clear();
        invalidate();
    }

    public void setPosition(long ms) {
        posMs = ms;
        baseReal = SystemClock.elapsedRealtime();
        invalidate();
    }
    public void setPlaying(boolean p) {
        playing = p;
        if (p) baseReal = SystemClock.elapsedRealtime();
        invalidate();
    }

    /** 当前播放秒数 (内部时钟自驱动, 不依赖外部刷新) */
    private float nowSec() {
        if (!playing) return posMs / 1000f;
        return posMs / 1000f + (SystemClock.elapsedRealtime() - baseReal) / 1000f;
    }
    public void setEnabled2(boolean e) { enabled = e; if (!e) active.clear(); invalidate(); }
    public boolean isDanmakuOn() { return enabled; }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        laneH = Math.max(28f, h / (float) (LANE_COUNT + 2));
        textSize = Math.max(16f, w / 55f);
        fill.setTextSize(textSize);
        stroke.setTextSize(textSize);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        try {
            drawInternal(canvas);
        } catch (Exception ignored) {
            // 绘制异常不闪退
        }
    }

    private void drawInternal(Canvas canvas) {
        if (!enabled) return;
        float now = nowSec();
        if (playing) {
            // 注入到点弹幕
            while (nextIdx < all.size() && all.get(nextIdx).time <= now + 0.2f) {
                DanmakuApi.Item it = all.get(nextIdx);
                if (active.size() < MAX_ACTIVE) {
                    Active a = new Active();
                    a.item = it;
                    a.lane = nextIdx % LANE_COUNT;
                    active.add(a);
                }
                nextIdx++;
            }
        }
        float w = getWidth();
        // 移除过期
        for (int i = active.size() - 1; i >= 0; i--) {
            Active a = active.get(i);
            float age = now - a.item.time;
            if (age < 0 || age > 10f) { active.remove(i); continue; }
            if (a.item.type == 1 && (w - age * SPEED < -200f)) { active.remove(i); }
            if (a.item.type != 1 && age > STAY) { active.remove(i); }
        }
        // 绘制
        for (Active a : active) {
            float age = now - a.item.time;
            float x, y;
            int color = a.item.color == 0 ? Color.WHITE : (0xFF000000 | a.item.color);
            fill.setColor(color);
            stroke.setColor(Color.BLACK);
            if (a.item.type == 1) {
                x = w - age * SPEED;
                y = laneH * (a.lane + 1);
            } else if (a.item.type == 5) {           // 顶部
                x = w / 2f - fill.measureText(a.item.text) / 2f;
                y = laneH * (a.lane + 1);
            } else {                                  // 底部
                x = w / 2f - fill.measureText(a.item.text) / 2f;
                y = getHeight() - laneH * (LANE_COUNT - a.lane);
            }
            canvas.drawText(a.item.text, x, y, stroke);
            canvas.drawText(a.item.text, x, y, fill);
        }
        if (playing) postInvalidateDelayed(33);   // ~30fps
    }
}
