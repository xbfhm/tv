# AnimeTV — Java 原生版 (对标云视听小电视)

基于 **AGE 动漫官方 API** 的免费追番 TV 应用，**原生 Java 重写**，
专为老电视（海信 VIDAA V1 / Android 5.1.1 / Mali-450 / 2GB）打造。

## 为什么重写 Java

| | Kivy/Python 版 | Java 原生版（本仓库） |
|---|---|---|
| 渲染 | SDL2 + OpenGL 自绘（老GPU兼容差） | **Android 系统控件** + 硬件加速 |
| 播放 | ffpyplayer 软解（1080p 卡） | **ExoPlayer 硬解**（走电视芯片解码器） |
| 内存 | 解释器+SDL2 ≈250MB | 原生 ≈80MB |
| 老系统兼容 | 闪退风险 | **minSdk 21 + targetSdk 26**（云视听式宽适配） |
| 中文字体 | 需打包 5.7MB 字体 | **系统自带 CJK 字体** |

## 功能

- 🔥 首页：最新更新 + 本周新番（**封面图**加载）
- 🔍 搜索：中文番名（海贼王/咒术回战/葬送的芙莉莲...），搜索结果带封面
- 📺 2026 新番目录（冬/春/夏）
- ▶ 内置播放：**ExoPlayer 硬解 m3u8**（自动限 720p 保老电视流畅）
- 🎬 **沉浸全屏播放**：控制条自动隐藏（6秒），OK 键唤出
- 🎚️ **可调进度条**：触摸拖动 / 遥控器聚焦进度条后 ←→ 调节（实时跳转）
- ⏩ **倍速播放**：1.0x → 1.25x → 1.5x → 2.0x → 0.75x → 0.5x 循环，跨集保持
- 遥控器全屏操作：OK=唤出控制条、←→=快进/快退15秒、↑↓=音量、返回=退出
- 播放体验：缓冲提示、时间显示（当前/总长）、屏幕常亮
- 自动连播：一集播完自动下一集
- 换线路：7 条免费 m3u8 线路自动轮换
- 外部播放：系统选择器（VLC/MX/浏览器等）
- 🕘 播放历史自动记忆 + 续看
- 焦点放大动画（选中项轻微放大）

## 构建 APK（GitHub Actions，无需电脑）

1. 本目录推送到 GitHub 仓库（main 分支）
2. Actions → **Build Java APK**（自动触发）→ 等 5~15 分钟
3. 下载 `animetv-java-apk` 中的 APK 安装到电视

> 首次构建要下载 Gradle 依赖，之后增量很快。
> 本地构建：`gradle assembleDebug`（需 JDK 17）

## 项目结构

```
app/src/main/java/com/animetv/
├── MainActivity.java     # 主界面: 首页/搜索/目录/详情/选集/历史
├── PlayerActivity.java   # 内置播放器 (ExoPlayer 硬解)
├── api/AgeApi.java       # AGE 官方 API 客户端 (纯 Java, OkHttp)
├── model/                # 数据模型
└── util/HistoryStore.java# 播放历史
app/src/main/res/         # 布局/主题/焦点样式 (TV 遥控器优化)
.github/workflows/build.yml
```

## 技术备注

- 片源：`api.agedm.io/v2` + `jx.wuzhoupai.com:8443`（2026-08 实测可用）
- 若片源失效：改 `api/AgeApi.java` 顶部的 `API_BASE` / `JX_BASE`
- minSdk 21 / targetSdk 26 / 双 ABI 自动（Gradle 默认）
- 内置播放默认限制 720p（Mali-450 4×A53 软解保险），如要 1080p 改 `PlayerActivity.setMaxVideoSize`
