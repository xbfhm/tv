package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;

import com.animetv.api.AgeApi;
import com.animetv.model.Episode;
import com.animetv.util.HistoryStore;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 内置播放器: ExoPlayer/Media3 硬件解码, 对标云视听
 * 遥控器: OK=暂停/播放, 左右=快进/快退15秒, 返回=退出
 */
public class PlayerActivity extends Activity {

    private PlayerView playerView;
    private TextView tvNowPlaying;
    private Button btnPause;
    private ExoPlayer player;
    private final ExecutorService pool = Executors.newFixedThreadPool(1);

    private String url, title, animeName, line, jxZj, jxVip;
    private int animeId, epIndex;
    private ArrayList<Episode> episodes;

    private boolean isEnded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent it = getIntent();
        url = it.getStringExtra("url");
        title = it.getStringExtra("title");
        animeId = it.getIntExtra("animeId", 0);
        epIndex = it.getIntExtra("epIndex", 0);
        line = it.getStringExtra("line");
        episodes = (ArrayList<Episode>) it.getSerializableExtra("episodes");
        animeName = it.getStringExtra("animeName");
        jxZj = it.getStringExtra("jxZj");
        jxVip = it.getStringExtra("jxVip");
        if (episodes == null) episodes = new ArrayList<>();
        if (jxZj == null) jxZj = "https://jx.wuzhoupai.com:8443/m3u8/?url=";
        if (jxVip == null) jxVip = "https://jx.wuzhoupai.com:8443/vip/?url=";

        playerView = findViewById(R.id.playerView);
        tvNowPlaying = findViewById(R.id.tvNowPlaying);
        btnPause = findViewById(R.id.btnPause);
        if (title != null) tvNowPlaying.setText(title);

        findViewById(R.id.btnPause).setOnClickListener(v -> togglePlay());
        findViewById(R.id.btnPrevEp).setOnClickListener(v -> loadEp(epIndex - 1));
        findViewById(R.id.btnNextEp).setOnClickListener(v -> loadEp(epIndex + 1));
        findViewById(R.id.btnExtPlay).setOnClickListener(v -> externalPlay());
        findViewById(R.id.btnExit).setOnClickListener(v -> finish());

        initPlayer();
        playUrl(url);
    }

    private void initPlayer() {
        DefaultTrackSelector ts = new DefaultTrackSelector(this);
        ts.setParameters(ts.buildUponParameters()
                .setMaxVideoSize(1280, 720)   // 老电视 Mali-450 保险画质
                .build());
        player = new ExoPlayer.Builder(this)
                .setTrackSelector(ts)
                .build();
        playerView.setPlayer(player);
        player.addListener(new androidx.media3.common.Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == androidx.media3.common.Player.STATE_ENDED) {
                    isEnded = true;
                    Toast.makeText(PlayerActivity.this, "本集播完, 自动下一集", Toast.LENGTH_SHORT).show();
                    loadEp(epIndex + 1);
                }
            }
            @Override public void onPlayerError(androidx.media3.common.PlaybackException e) {
                Toast.makeText(PlayerActivity.this, "播放出错: " + e.getErrorCodeName(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void playUrl(String u) {
        player.setMediaItem(MediaItem.fromUri(Uri.parse(u)));
        player.prepare();
        player.play();
        isEnded = false;
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.isPlaying()) player.pause(); else player.play();
        btnPause.setText(player.isPlaying() ? "⏸ 暂停" : "▶ 播放");
    }

    private void seekBy(long sec) {
        if (player == null) return;
        long pos = Math.max(0, player.getCurrentPosition() + sec * 1000);
        player.seekTo(pos);
    }

    /** 加载指定集: 后台解析直链后切换 */
    private void loadEp(int i) {
        if (i < 0 || i >= episodes.size()) {
            if (i >= episodes.size()) Toast.makeText(this, "已经是最后一集", Toast.LENGTH_SHORT).show();
            return;
        }
        final int idx = i;
        tvNowPlaying.setText(animeName + " " + episodes.get(i).title + "  解析中...");
        pool.execute(() -> {
            String u = null;
            String usedLine = line;
            for (Episode e : episodes) {
                if (!e.line.equals(line)) continue;
                try { u = AgeApi.resolve(e.enc, e.vip, jxZj, jxVip); break; } catch (Exception ignored) {}
            }
            if (u == null) {
                for (Episode e : episodes) {
                    try { u = AgeApi.resolve(e.enc, e.vip, jxZj, jxVip); usedLine = e.line; break; }
                    catch (Exception ignored) {}
                }
            }
            final String fu = u;
            final String fl = usedLine;
            runOnUiThread(() -> {
                if (fu == null) {
                    Toast.makeText(this, "解析失败, 请退出重试", Toast.LENGTH_LONG).show();
                    return;
                }
                epIndex = idx;
                line = fl;
                Episode e = episodes.get(idx);
                tvNowPlaying.setText(animeName + " " + e.title + " [" + e.lineLabel + "]");
                btnPause.setText("⏸ 暂停");
                playUrl(fu);
                new HistoryStore(this).add(animeId, animeName, e.title, idx, fl);
            });
        });
    }

    /** 外部播放器 (系统选择器) */
    private void externalPlay() {
        if (url == null) return;
        try {
            Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            it.setType(url.contains(".m3u8") ? "application/x-mpegURL" : "video/*");
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(it, "选择播放器"));
        } catch (Exception e) {
            Toast.makeText(this, "没有可用的外部播放器", Toast.LENGTH_LONG).show();
        }
    }

    // ============ 遥控器按键 ============
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            togglePlay();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) { seekBy(-15); return true; }
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) { seekBy(15); return true; }
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
