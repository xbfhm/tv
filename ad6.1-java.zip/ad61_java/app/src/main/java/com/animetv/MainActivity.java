package com.animetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.animetv.api.AgeApi;
import com.animetv.model.Anime;
import com.animetv.model.AnimeDetail;
import com.animetv.model.Episode;
import com.animetv.rule.KazumiEngine;
import com.animetv.rule.KazumiRule;
import com.animetv.rule.PlayUrlSniffer;
import com.animetv.rule.RuleRepo;
import com.animetv.util.FocusAnim;
import com.animetv.util.HistoryStore;
import com.animetv.util.UIMode;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private TextView tvInfo, tvListTitle;
    private EditText etSearch;
    private ImageView ivDetailCover;
    private RecyclerView rvList, rvEpisodes;
    private Button btnLine, btnPlay, btnPrev, btnNext;
    private View detailPanel, bottomBar;   // 详情/播放区 (点击海报才显示)

    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final List<Anime> animeList = new ArrayList<>();
    private final List<Episode> epList = new ArrayList<>();
    private final ListAdapter listAdapter = new ListAdapter();
    private final EpAdapter epAdapter = new EpAdapter();

    private AnimeDetail detail;
    private int epIndex = 0;
    private boolean busy = false;
    private String listMode = "home";

    private HistoryStore history;
    private boolean tvMode = true;
    private boolean fromPlayer = false;    // 从播放器返回标记
    private long lastBackAt = 0;           // 返回键时间戳 (二次确认)

    private String lastKeyword = "";       // 最近搜索词 (失败重试用)
    private long resumePos = 0;            // 待续播位置 (毫秒)
    private int resumeEpForPos = -1;       // 与续播位置对应的集序号
    private boolean searchDialogOpen = false;      // 搜索弹窗防重入
    private long lastSearchDialogClose = 0;        // 上次关闭时间 (防焦点回弹再弹窗)

    // ===== Kazumi 规则源 =====
    private String source = "AGE";        // 当前搜索源: "AGE" / "聚合" / 规则名
    private KazumiEngine engine;          // 规则引擎
    private Button btnSource;             // 顶栏源切换按钮

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 首次启动: 弹界面模式选择 (遥控器OK + 触屏均可操作)
        if (!UIMode.chosen(this)) {
            showModeDialog();
        }
        tvMode = UIMode.isTV(this);
        setContentView(tvMode ? R.layout.activity_main : R.layout.activity_main_phone);
        AnimeTVApp.log("Main onCreate: 布局完成 (mode=" + tvMode + ")");
        history = new HistoryStore(this);
        RuleRepo.init(this);
        engine = new KazumiEngine(AgeApi.getClient());
        bindViews();
        AnimeTVApp.log("Main onCreate: 控件绑定完成");
        setupList();
        AnimeTVApp.log("Main onCreate: 列表初始化完成");
        showHome();
        AnimeTVApp.log("Main onCreate: 首页请求已发起");
    }

    private boolean firstFocus = true;

    /** 窗口可见后自动聚焦首页按钮 (否则遥控器按键无响应) */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && firstFocus) {
            firstFocus = false;
            if (tvMode) {
                findViewById(R.id.btnHome).post(() -> {
                    View v = findViewById(R.id.btnHome);
                    if (v != null) v.requestFocus();
                });
            }
        }
    }

    /** 首次启动: 选择电视端/手机端界面 */
    private void showModeDialog() {
        try {
            AlertDialog d = new AlertDialog.Builder(this)
                    .setTitle("选择界面模式")
                    .setMessage("第一次使用, 请选择操作方式\n\n" +
                            "📺 电视端: 遥控器操作, 大字体界面\n" +
                            "📱 手机端: 触屏操作, 竖屏界面")
                    .setPositiveButton("电视端", (di, w) -> {
                        UIMode.set(this, UIMode.TV);
                        recreate();
                    })
                    .setNegativeButton("手机端", (di, w) -> {
                        UIMode.set(this, UIMode.PHONE);
                        recreate();
                    })
                    .setCancelable(false)
                    .create();
            d.show();
        } catch (Exception ignored) {}
    }

    private void bindViews() {
        tvInfo = findViewById(R.id.tvInfo);
        tvListTitle = findViewById(R.id.tvListTitle);
        etSearch = findViewById(R.id.etSearch);
        ivDetailCover = findViewById(R.id.ivDetailCover);
        rvList = findViewById(R.id.rvList);
        rvEpisodes = findViewById(R.id.rvEpisodes);
        btnLine = findViewById(R.id.btnLine);
        btnPlay = findViewById(R.id.btnPlay);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        detailPanel = findViewById(R.id.detailPanel);
        bottomBar = findViewById(R.id.bottomBar);

        findViewById(R.id.btnHome).setOnClickListener(v -> showHome());
        findViewById(R.id.btnCatalog).setOnClickListener(v -> showCatalog());
        findViewById(R.id.btnHistory).setOnClickListener(v -> showHistory());
        findViewById(R.id.btnSearch).setOnClickListener(v -> {
            if (tvMode) showSearchDialog(); else doSearch();
        });
        etSearch.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { doSearch(); return true; }
            return false;
        });
        btnPlay.setOnClickListener(v -> playCurrent());
        btnPrev.setOnClickListener(v -> prevEp());
        btnNext.setOnClickListener(v -> nextEp());
        btnLine.setOnClickListener(v -> switchLine());
        btnSource = findViewById(R.id.btnSource);
        if (btnSource != null) {
            btnSource.setOnClickListener(v -> showSourceDialog());
            updateSourceBtn();
        }
        View btnSettings = findViewById(R.id.btnSettings);
        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        }
        // 底部"◀ 返回"按钮: 一键回到首页 (遥控器焦点在按钮上按 OK 即可)
        View btnBackHome = findViewById(R.id.btnBackHome);
        if (btnBackHome != null) btnBackHome.setOnClickListener(v -> resetToHome());

        // 手机端"续看"按钮 (电视端无此按钮, 首页自带继续观看行)
        View btnResume = findViewById(R.id.btnResume);
        if (btnResume != null) {
            btnResume.setOnClickListener(v -> resumeFirst());
            FocusAnim.bind(btnResume);
        }

        // 电视端: 顶部/底部按钮统一加焦点缩放动画
        if (tvMode) {
            FocusAnim.bind(findViewById(R.id.btnHome));
            FocusAnim.bind(findViewById(R.id.btnCatalog));
            FocusAnim.bind(findViewById(R.id.btnHistory));
            FocusAnim.bind(findViewById(R.id.btnSearch));
            FocusAnim.bind(findViewById(R.id.btnBackHome));
            FocusAnim.bind(findViewById(R.id.btnPrev));
            FocusAnim.bind(findViewById(R.id.btnPlay));
            FocusAnim.bind(findViewById(R.id.btnNext));
            FocusAnim.bind(findViewById(R.id.btnLine));
            if (btnSource != null) FocusAnim.bind(btnSource);
            View bs = findViewById(R.id.btnSettings);
            if (bs != null) FocusAnim.bind(bs);

            // 电视端搜索: 聚焦输入框即弹输入对话框 (遥控器友好)
            etSearch.setOnFocusChangeListener((v, has) -> {
                if (has && !searchDialogOpen &&
                        android.os.SystemClock.elapsedRealtime() - lastSearchDialogClose > 500) {
                    showSearchDialog();
                }
            });
        }

        // 信息区: 聚焦变色 (错误重试提示醒目)
        tvInfo.setOnFocusChangeListener((v, has) -> {
            tvInfo.setTextColor(getResources().getColor(
                    has ? R.color.text_focus : R.color.text_primary));
        });
    }

    private void setupList() {
        // 电视端: 海报墙网格, 列数按屏幕宽度自适应 (海报占满整屏)
        if (tvMode) {
            int dpW = (int) (getResources().getDisplayMetrics().widthPixels
                    / getResources().getDisplayMetrics().density);
            int cols = Math.max(2, Math.min(6, dpW / 180));
            rvList.setLayoutManager(new GridLayoutManager(this, cols));
        } else {
            rvList.setLayoutManager(new LinearLayoutManager(this));
        }
        rvList.setAdapter(listAdapter);
        rvEpisodes.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        rvEpisodes.setAdapter(epAdapter);
    }

    /** 列表浏览模式: 隐藏详情/选集/播放区, 海报墙占满整屏 */
    private void hideDetailUi() {
        if (detailPanel != null) detailPanel.setVisibility(View.GONE);
        rvEpisodes.setVisibility(View.GONE);
        if (bottomBar != null) bottomBar.setVisibility(View.GONE);
    }

    /** 详情模式: 显示详情/选集/播放区 */
    private void showDetailUi() {
        if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
        rvEpisodes.setVisibility(View.VISIBLE);
        if (bottomBar != null) bottomBar.setVisibility(View.VISIBLE);
    }

    // ================= 模式切换 =================
    private void showHome() {
        if (busy) return;
        busy = true;
        hideDetailUi();
        ivDetailCover.setVisibility(View.GONE);
        tvInfo.setText("⏳ 正在加载首页...\n\n请稍候");
        listMode = "home";
        pool.execute(() -> {
            try {
                List<Anime> list = AgeApi.home();
                AnimeTVApp.log("home() 返回 " + list.size() + " 条");
                // 首页顶部插入"继续观看" (最近一次播放记录)
                final List<HistoryStore.Item> hists = history.load();
                if (!hists.isEmpty()) {
                    HistoryStore.Item it = hists.get(0);
                    Anime r = new Anime(it.aid, it.name, "", "", "");
                    r.display = "▶ 继续观看: " + it.name + "  " + it.ep;
                    r.isResume = true;
                    list.add(0, r);
                }
                runOnUiThread(() -> {
                    busy = false;
                    renderAnimeList(list, "🔥 最新更新 / 本周新番");
                    AnimeTVApp.log("首页渲染完成 " + list.size() + " 条");
                });
            } catch (Exception e) {
                // 首页加载失败: 回退到"继续观看"列表 (不再硬报错)
                final List<HistoryStore.Item> hists = history.load();
                runOnUiThread(() -> {
                    busy = false;
                    if (!hists.isEmpty()) {
                        List<Anime> fallback = new ArrayList<>();
                        for (HistoryStore.Item it : hists) {
                            Anime r = new Anime(it.aid, it.name, "", "", "");
                            r.display = "▶ 继续观看: " + it.name + "  " + it.ep;
                            r.isResume = true;
                            fallback.add(r);
                        }
                        renderAnimeList(fallback, "🕘 继续观看 (首页片源暂不可用)");
                        Toast.makeText(this, "首页片源暂不可用, 可搜索番剧", Toast.LENGTH_LONG).show();
                    } else {
                        uiError("首页加载失败: " + e.getMessage() + "\n\n可点「搜索」直接搜番");
                    }
                });
            }
        });
    }

    private void showCatalog() {
        if (busy) return;
        busy = true;
        hideDetailUi();
        ivDetailCover.setVisibility(View.GONE);
        tvInfo.setText("⏳ 正在加载新番目录...");
        listMode = "catalog";
        pool.execute(() -> {
            try {
                List<Anime> list = new ArrayList<>();
                list.addAll(AgeApi.catalog(2026, 1));
                list.addAll(AgeApi.catalog(2026, 4));
                list.addAll(AgeApi.catalog(2026, 7));
                runOnUiThread(() -> {
                    busy = false;
                    renderAnimeList(list, "📺 2026 新番一览");
                });
            } catch (Exception e) {
                uiError("目录加载失败: " + e.getMessage());
            }
        });
    }

    private void showHistory() {
        busy = false;
        List<HistoryStore.Item> items = history.load();
        if (items.isEmpty()) {
            // 无历史: 详情面板显示提示, 隐藏其余
            if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
            ivDetailCover.setVisibility(View.GONE);
            tvInfo.setText("暂无播放历史\n\n看过的番会记录在这里");
            rvEpisodes.setVisibility(View.GONE);
            if (bottomBar != null) bottomBar.setVisibility(View.GONE);
            listMode = "history";
            animeList.clear();
            listAdapter.notifyDataSetChanged();
            return;
        }
        hideDetailUi();
        List<Anime> list = new ArrayList<>();
        for (HistoryStore.Item it : items) {
            Anime a = new Anime(it.aid, it.name, "", "", "");
            a.display = "🕘 " + it.name + "  ▶ " + it.ep;
            list.add(a);
        }
        renderAnimeList(list, "🕘 播放历史 (OK=恢复)");
        listMode = "history";
    }

    private void doSearch() {
        doSearch(etSearch.getText().toString().trim());
    }

    private void doSearch(String kw) {
        if (busy) return;
        lastKeyword = kw;
        if (kw.isEmpty()) {
            if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
            rvEpisodes.setVisibility(View.GONE);
            if (bottomBar != null) bottomBar.setVisibility(View.GONE);
            tvInfo.setText("请输入番剧名称\n如: 海贼王 / 咒术回战 / 葬送的芙莉莲");
            return;
        }
        busy = true;
        hideDetailUi();
        ivDetailCover.setVisibility(View.GONE);
        tvInfo.setText("⏳ 正在搜索 [" + kw + "] (" + sourceLabel() + ") ...");
        listMode = "search";
        pool.execute(() -> {
            try {
                List<Anime> list = searchBySource(kw);
                final String title = "🔍 搜索[" + sourceLabel() + "]: " + kw;
                runOnUiThread(() -> {
                    busy = false;
                    if (list.isEmpty()) {
                        tvInfo.setText("未找到 [" + kw + "] 相关番剧 (源: " + sourceLabel() + ")\n\n换个关键词或切换搜索源试试");
                        animeList.clear();
                        listAdapter.notifyDataSetChanged();
                    } else {
                        renderAnimeList(list, title);
                    }
                });
            } catch (Exception e) {
                uiError("搜索失败: " + e.getMessage());
            }
        });
    }

    /** 按当前源搜索 */
    private List<Anime> searchBySource(String kw) throws Exception {
        if ("AGE".equals(source)) {
            return AgeApi.search(kw);
        }
        if ("聚合".equals(source)) {
            return aggregateSearch(kw);
        }
        KazumiRule rule = RuleRepo.get(source);
        if (rule == null) return AgeApi.search(kw);
        List<KazumiEngine.SearchItem> items = engine.search(rule, kw);
        List<Anime> out = new ArrayList<>();
        for (KazumiEngine.SearchItem it : items) {
            Anime a = new Anime();
            a.name = it.name;
            a.display = "[" + rule.name + "] " + it.name;
            a.url = it.url;
            a.source = rule.name;
            a.baseUrl = rule.baseUrl;
            out.add(a);
        }
        return out;
    }

    /** 聚合搜索: 并行搜 AGE + 全部 kazumi 规则, 合并去重 */
    private List<Anime> aggregateSearch(String kw) throws Exception {
        List<Anime> out = new ArrayList<>();
        List<KazumiRule> rules = new ArrayList<>(RuleRepo.getRules());
        // AGE 先跑
        try { out.addAll(AgeApi.search(kw)); } catch (Exception ignored) {}
        // 并行搜各规则
        final java.util.concurrent.atomic.AtomicInteger done = new java.util.concurrent.atomic.AtomicInteger();
        java.util.concurrent.ExecutorService p = java.util.concurrent.Executors.newFixedThreadPool(6);
        final java.util.List<Anime> sync = java.util.Collections.synchronizedList(new ArrayList<>());
        for (KazumiRule r : rules) {
            p.execute(() -> {
                try {
                    List<KazumiEngine.SearchItem> items = engine.search(r, kw);
                    List<Anime> tmp = new ArrayList<>();
                    for (KazumiEngine.SearchItem it : items) {
                        Anime a = new Anime();
                        a.name = it.name;
                        a.display = "[" + r.name + "] " + it.name;
                        a.url = it.url;
                        a.source = r.name;
                        a.baseUrl = r.baseUrl;
                        tmp.add(a);
                    }
                    synchronized (sync) { sync.addAll(tmp); }
                } catch (Exception ignored) {} finally {
                    done.incrementAndGet();
                }
            });
        }
        p.shutdown();
        try { p.awaitTermination(30, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        out.addAll(sync);
        return out;
    }

    /** 源按钮显示文本 */
    private String sourceLabel() {
        if ("AGE".equals(source)) return "AGE官方";
        if ("聚合".equals(source)) return "聚合搜索";
        return source;
    }

    private void updateSourceBtn() {
        if (btnSource != null) {
            String s = "AGE".equals(source) ? "AGE" : ("聚合".equals(source) ? "聚合" : source);
            btnSource.setText("源:" + s);
        }
    }

    /** 源切换对话框 (电视遥控器可用) */
    private void showSourceDialog() {
        List<String> names = new ArrayList<>();
        names.add("AGE官方 (官方API, 最稳定)");
        names.add("聚合搜索 (全部源一起搜)");
        for (KazumiRule r : RuleRepo.getRules()) names.add(r.name);
        final String[] arr = names.toArray(new String[0]);
        new android.app.AlertDialog.Builder(this)
                .setTitle("选择搜索源")
                .setItems(arr, (dialog, which) -> {
                    if (which == 0) source = "AGE";
                    else if (which == 1) source = "聚合";
                    else source = RuleRepo.getRules().get(which - 2).name;
                    updateSourceBtn();
                    if (listMode.equals("search") && !lastKeyword.isEmpty()) {
                        doSearch(lastKeyword);   // 换源后立即重搜
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ================= 渲染 =================
    private void renderAnimeList(List<Anime> list, String title) {
        animeList.clear();
        animeList.addAll(list);
        tvListTitle.setText(title);
        listAdapter.notifyDataSetChanged();
    }

    private void uiError(String msg) {
        runOnUiThread(() -> {
            busy = false;
            if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
            rvEpisodes.setVisibility(View.GONE);
            if (bottomBar != null) bottomBar.setVisibility(View.GONE);
            tvInfo.setText(msg + "\n\n[OK] 重试当前操作");
            tvInfo.setFocusable(true);
            tvInfo.setClickable(true);
            tvInfo.setOnClickListener(v -> retryCurrent());
            tvInfo.requestFocus();
        });
    }

    /** 错误重试: 按当前列表模式重新请求 */
    private void retryCurrent() {
        if (busy) return;
        tvInfo.setFocusable(false);
        tvInfo.setClickable(false);
        tvInfo.setOnClickListener(null);
        if ("catalog".equals(listMode)) {
            showCatalog();
        } else if ("search".equals(listMode) && !lastKeyword.isEmpty()) {
            doSearch(lastKeyword);
        } else {
            showHome();
        }
    }

    // ================= 详情 =================
    private void openAnime(Anime a, int resumeEp, String resumeLine, long resumePosMs) {
        if (busy) return;
        busy = true;
        tvInfo.setText("⏳ 正在解析《" + a.name + "》(" + a.source + ")...");
        pool.execute(() -> {
            try {
                AnimeDetail d = "AGE".equals(a.source) ? AgeApi.detail(a.id) : kazumiDetail(a);
                if (d.episodes.isEmpty()) {
                    runOnUiThread(() -> {
                        busy = false;
                        if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
                        rvEpisodes.setVisibility(View.GONE);
                        if (bottomBar != null) bottomBar.setVisibility(View.GONE);
                        tvInfo.setText("《" + d.name + "》暂无免费播放线路\n\n版权番可能仅有 VIP 源");
                        epList.clear();
                        epAdapter.notifyDataSetChanged();
                    });
                    return;
                }
                if (resumeLine != null && !resumeLine.isEmpty() && hasLine(d, resumeLine)) {
                    d.currentLine = resumeLine;
                }
                int idx = Math.min(Math.max(resumeEp, 0), d.episodes.size() - 1);
                resumePos = resumePosMs;
                resumeEpForPos = idx;
                AnimeDetail dd = d;
                int ii = idx;
                runOnUiThread(() -> renderDetail(dd, ii));
            } catch (Exception e) {
                uiError("解析失败: " + e.getMessage());
            }
        });
    }

    private boolean hasLine(AnimeDetail d, String line) {
        for (Episode e : d.episodes) if (e.line.equals(line)) return true;
        return false;
    }

    /** kazumi 源: 用规则解析详情页 -> 线路 + 剧集 */
    private AnimeDetail kazumiDetail(Anime a) throws Exception {
        KazumiRule rule = RuleRepo.get(a.source);
        if (rule == null) throw new Exception("规则不存在: " + a.source);
        List<KazumiEngine.Road> roads = engine.chapters(rule, a.url);
        AnimeDetail d = new AnimeDetail();
        d.name = a.name;
        d.source = a.source;
        d.baseUrl = rule.baseUrl;
        d.detailUrl = a.url;
        int roadIdx = 0;
        for (KazumiEngine.Road road : roads) {
            String roadName = road.name.isEmpty() ? ("线路" + (roadIdx + 1)) : road.name;
            for (KazumiEngine.Ep ep : road.eps) {
                Episode e = new Episode();
                e.line = String.valueOf(roadIdx);
                e.lineLabel = roadName;
                e.title = ep.name;
                e.url = ep.url;
                e.source = a.source;
                e.baseUrl = rule.baseUrl;
                e.vip = false;
                d.episodes.add(e);
            }
            roadIdx++;
        }
        if (!d.episodes.isEmpty()) d.currentLine = d.episodes.get(0).line;
        d.vipOnly = d.episodes.isEmpty();
        return d;
    }

    private void renderDetail(AnimeDetail d, int idx) {
        busy = false;
        detail = d;
        epIndex = idx;
        showDetailUi();
        StringBuilder sb = new StringBuilder();
        for (String t : d.tags) { if (sb.length() > 0) sb.append(" "); sb.append(t); }
        String tags = sb.toString();
        String meta = "";
        if (!"AGE".equals(d.source)) {
            meta = "源: " + d.source + " | 共 " + d.episodes.size() + " 集\n";
        } else {
            meta = "类型: " + d.type + " | 首播: " + d.premiere + "\n" +
                    "状态: " + d.status + " | " + d.uptodate + "\n" +
                    "标签: " + tags + "\n";
        }
        String intro = d.intro.length() > 160 ? d.intro.substring(0, 160) : d.intro;
        tvInfo.setText("《" + d.name + "》\n\n" +
                meta +
                (intro.isEmpty() ? "" : "简介: " + intro + "\n\n") +
                "⬇ 选择集数, ▶ 内置播放 (硬解全屏)");
        // 封面
        if (d.cover != null && !d.cover.isEmpty()) {
            ivDetailCover.setVisibility(View.VISIBLE);
            Glide.with(this).load(d.cover)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .override(640, 360)
                    .placeholder(R.color.bg_panel)
                    .error(R.color.bg_panel)
                    .into(ivDetailCover);
        } else {
            ivDetailCover.setVisibility(View.GONE);
        }
        epList.clear();
        epList.addAll(d.episodes);
        epAdapter.notifyDataSetChanged();
        // 自动滚动到当前集 (遥控器免手动翻)
        rvEpisodes.post(() -> rvEpisodes.scrollToPosition(epIndex));
        updateButtons();
    }

    // ================= 选集 / 播放 =================
    private void selectEp(int i) {
        if (busy || epList.isEmpty()) return;
        epIndex = Math.min(i, epList.size() - 1);
        resumePos = 0;              // 手动选集一律从头播
        resumeEpForPos = -1;
        updateButtons();
        resolveAndPlay();
    }

    private void playCurrent() {
        if (busy || epList.isEmpty()) {
            tvInfo.setText("请先选择一部番剧");
            return;
        }
        updateButtons();
        resolveAndPlay();
    }

    private void resolveAndPlay() {
        Episode e = epList.get(epIndex);
        tvInfo.setText("《" + detail.name + "》 " + e.title + "\n\n⏳ 正在获取播放地址...");
        busy = true;
        pool.execute(() -> {
            try {
            // 有序线路: 当前线路优先, 其余按出现顺序
            List<String> lines = new ArrayList<>();
            if (detail.currentLine != null) lines.add(detail.currentLine);
            for (Episode ep : epList) if (!lines.contains(ep.line)) lines.add(ep.line);
            int curEpNum = epNumber(e.title);
            String url = null, usedLine = null, usedLabel = null;
            int usedOrder = 0, tried = 0;
            StringBuilder triedInfo = new StringBuilder();
            for (int li = 0; li < lines.size(); li++) {
                Episode target = findSameEpisode(lines.get(li), curEpNum, epIndex);
                if (target == null) continue;
                tried++;
                try {
                    url = resolveEpisode(target);
                    if (url == null) throw new Exception("未解析到直链");
                    usedLine = target.line;
                    usedLabel = target.lineLabel;
                    usedOrder = li + 1;
                    break;   // 换源成功: 不再尝试剩下的
                } catch (Exception ignored) {
                    if (triedInfo.length() > 0) triedInfo.append("; ");
                    triedInfo.append(target.lineLabel).append("(第").append(li + 1).append("个播放源)失败");
                }
            }
            final String fu = url, fl = usedLine, flabel = usedLabel;
            final int forder = usedOrder, ftried = tried;
            final String fTried = triedInfo.toString();
            // 续播位置: 仅当播的还是"继续观看/历史"进入的那一集时才带进度
            final long startPos = (epIndex == resumeEpForPos) ? resumePos : 0;
            runOnUiThread(() -> {
                busy = false;
                if (fu == null) {
                    // kazumi 源: 原生嗅探失败 (无网页兜底, 提示换源)
                    if (detail != null && !"AGE".equals(detail.source)) {
                        tvInfo.setText("《" + detail.name + "》解析失败\n\n" +
                                "已尝试全部 " + ftried + " 个线路\n" +
                                "该源可能失效, 请换一个搜索源重试");
                        return;
                    }
                    if (detail != null && detail.vipOnly) {
                        tvInfo.setText("《" + detail.name + "》为版权番\n\n仅提供VIP源(腾讯/爱奇艺等)\n需开通视频会员才能观看, 免费无法播放");
                    } else {
                        tvInfo.setText("播放失败: 已尝试全部 " + ftried + " 个播放源\n\n" + fTried + "\n可换一部番试试");
                    }
                    return;
                }
                if ("AGE".equals(detail.source)) {
                    history.add(detail.id, detail.name, e.title, epIndex, fl, startPos);
                }
                launchPlayer(fu, e, fl, flabel, forder, startPos);
            });
            } catch (Exception ex) {
                runOnUiThread(() -> { busy = false; tvInfo.setText("播放出错: " + ex.getMessage()); });
            }
        });
    }

    /** 从集标题提取集号 (跨线路找同集用) */
    private static int epNumber(String title) {
        if (title == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(title);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    /** 解析单集播放直链 (AGE: jx解析; kazumi: 嗅探播放页) */
    private String resolveEpisode(Episode target) throws Exception {
        if ("AGE".equals(target.source)) {
            return AgeApi.resolve(target.enc, target.vip, detail.jxZJ, detail.jxVIP);
        }
        PlayUrlSniffer sniffer = new PlayUrlSniffer(AgeApi.getClient(), target.baseUrl, "");
        return sniffer.sniff(target.url);
    }

    /** 在指定线路里找"同一集": 优先集号匹配, 否则按序号 */
    private Episode findSameEpisode(String line, int epNum, int fallbackIdx) {
        List<Episode> lineEps = new ArrayList<>();
        for (Episode ep : epList) if (ep.line.equals(line)) lineEps.add(ep);
        if (lineEps.isEmpty()) return null;
        if (epNum > 0) {
            for (Episode ep : lineEps) if (epNumber(ep.title) == epNum) return ep;
        }
        return lineEps.get(Math.min(fallbackIdx, lineEps.size() - 1));
    }

    private void launchPlayer(String url, Episode e, String line, String lineLabel, int order, long resumePosMs) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("url", url);
        it.putExtra("title", detail.name + " " + e.title + " [" + e.lineLabel + "]");
        it.putExtra("animeId", detail.id);
        it.putExtra("epIndex", epIndex);
        it.putExtra("line", line);
        it.putExtra("episodes", new ArrayList<>(epList));
        it.putExtra("animeName", detail.name);
        it.putExtra("jxZj", detail.jxZJ);
        it.putExtra("jxVip", detail.jxVIP);
        it.putExtra("source", detail.source);
        it.putExtra("baseUrl", detail.baseUrl);
        it.putExtra("lineLabel", lineLabel);
        it.putExtra("lineOrder", order);
        it.putExtra("resumePos", resumePosMs);
        fromPlayer = true;
        startActivity(it);
    }

    // ================= 上下集 / 线路 =================
    private void prevEp() {
        if (epIndex > 0) selectEp(epIndex - 1);
    }

    private void nextEp() {
        if (epIndex < epList.size() - 1) selectEp(epIndex + 1);
        else tvInfo.setText("已经是最后一集了");
    }

    private void switchLine() {
        if (epList.isEmpty()) return;
        List<String> lines = new ArrayList<>();
        for (Episode e : epList) if (!lines.contains(e.line)) lines.add(e.line);
        if (lines.isEmpty()) return;
        int i = lines.indexOf(detail.currentLine);
        detail.currentLine = lines.get((i + 1) % lines.size());
        updateButtons();
        int order = lines.indexOf(detail.currentLine) + 1;
        tvInfo.setText("已切换到: " + detail.currentLine + " (第" + order + "个播放源)\n\n按 ▶ 播放");
    }

    private void updateButtons() {
        if (epList.isEmpty()) return;
        Episode e = epList.get(epIndex);
        btnPlay.setText("▶ 播放 " + e.title);
        btnLine.setText("线路: " + e.lineLabel);
        btnPrev.setEnabled(epIndex > 0);
        btnNext.setEnabled(epIndex < epList.size() - 1);
    }

    // ================= 电视端搜索对话框 =================
    private void showSearchDialog() {
        if (searchDialogOpen) return;
        searchDialogOpen = true;
        try {
            EditText input = new EditText(this);
            input.setHint("输入番剧名 (如: 海贼王 / 咒术回战)");
            input.setText(etSearch.getText());
            input.setTextColor(getResources().getColor(R.color.text_primary));
            input.setTextSize(20);
            input.setSingleLine(true);
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
            input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
            input.setSelectAllOnFocus(true);
            input.setPadding(dp(16), dp(8), dp(16), dp(8));
            input.setBackgroundColor(getResources().getColor(R.color.bg_panel));
            final EditText fInput = input;
            new AlertDialog.Builder(this)
                    .setTitle("🔍 搜索番剧")
                    .setView(input)
                    .setPositiveButton("搜索", (d, w) -> {
                        String kw = fInput.getText().toString().trim();
                        etSearch.setText(kw);
                        doSearch(kw);
                    })
                    .setNegativeButton("取消", null)
                    .setOnDismissListener(d -> {
                        // 焦点还给搜索按钮, 避免输入框残留聚焦再次弹窗
                        searchDialogOpen = false;
                        lastSearchDialogClose = android.os.SystemClock.elapsedRealtime();
                        etSearch.clearFocus();
                        View v = findViewById(R.id.btnSearch);
                        if (v != null) v.requestFocus();
                    })
                    .show();
            input.post(() -> {
                input.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {
                    try { imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT); } catch (Exception ignored) {}
                }
            });
        } catch (Exception e) {
            searchDialogOpen = false;
        }
    }

    /** 续播最近一条历史 (首页"继续观看"行 / 手机端"续看"按钮) */
    private void resumeFirst() {
        List<HistoryStore.Item> hists = history.load();
        if (hists.isEmpty()) {
            Toast.makeText(this, "暂无播放历史", Toast.LENGTH_SHORT).show();
            return;
        }
        HistoryStore.Item it = hists.get(0);
        Anime a = new Anime(it.aid, it.name, "", "", "");
        openAnime(a, it.epIndex, it.line, it.pos);
    }

    /** 删除单条历史 (长按确认) */
    private void confirmDeleteHistory(Anime a) {
        new AlertDialog.Builder(this)
                .setTitle("删除历史")
                .setMessage("删除《" + a.name + "》的播放记录?")
                .setPositiveButton("删除", (d, w) -> {
                    history.remove(a.id);
                    Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
                    showHistory();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ================= 适配器 =================
    class ListAdapter extends RecyclerView.Adapter<ListAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView tv, tvSub;
            ImageView iv;
            VH(View v) { super(v); tv = v.findViewById(R.id.tvName); tvSub = v.findViewById(R.id.tvSub); iv = v.findViewById(R.id.ivCover); }
        }
        @Override public VH onCreateViewHolder(android.view.ViewGroup p, int t) {
            // 电视端: 海报卡片; 手机端: 图文列表
            int layout = tvMode ? R.layout.item_poster : R.layout.item_anime;
            return new VH(getLayoutInflater().inflate(layout, p, false));
        }
        @Override public void onBindViewHolder(VH h, int pos) {
            Anime a = animeList.get(pos);
            h.tv.setText(a.display);
            // 封面 (海报卡无封面时留占位背景, 列表卡隐藏)
            if (a.cover != null && !a.cover.isEmpty()) {
                h.iv.setVisibility(View.VISIBLE);
                Glide.with(MainActivity.this).load(a.cover)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .centerCrop()
                        .override(tvMode ? 400 : 200, tvMode ? 240 : 120)
                        .placeholder(R.color.bg_panel)
                        .error(R.color.bg_panel)
                        .into(h.iv);
            } else if (tvMode) {
                h.iv.setVisibility(View.VISIBLE);
                h.iv.setImageDrawable(null);
            } else {
                h.iv.setVisibility(View.GONE);
            }
            // 副标题 (仅列表卡有)
            if (h.tvSub != null) {
                if (a.premiere != null && !a.premiere.isEmpty()) {
                    h.tvSub.setVisibility(View.VISIBLE);
                    h.tvSub.setText(a.premiere + " | " + a.status);
                } else {
                    h.tvSub.setVisibility(View.GONE);
                }
            }
            h.itemView.setOnClickListener(v -> onItemClick(a));
            h.itemView.setOnFocusChangeListener((v, has) -> {
                FocusAnim.scale(v, has);
                h.tv.setTextColor(has ? getResources().getColor(R.color.text_focus)
                                      : getResources().getColor(R.color.text_primary));
                // 焦点滚动: 聚焦到屏幕边缘的项时, 列表跟着滚动露出更多 (遥控器下滑看更多)
                if (has) {
                    rvList.post(() -> {
                        RecyclerView.LayoutManager lm = rvList.getLayoutManager();
                        if (lm == null) return;
                        int lastVisible = lm instanceof GridLayoutManager
                                ? ((GridLayoutManager) lm).findLastCompletelyVisibleItemPosition()
                                : ((LinearLayoutManager) lm).findLastCompletelyVisibleItemPosition();
                        if (pos >= lastVisible) rvList.smoothScrollToPosition(pos);
                    });
                }
            });
            // 历史页: 长按删除该条记录 (遥控器长按OK / 触屏长按)
            h.itemView.setOnLongClickListener(v -> {
                if ("history".equals(listMode)) {
                    confirmDeleteHistory(a);
                    return true;
                }
                return false;
            });
        }
        @Override public int getItemCount() { return animeList.size(); }
    }

    class EpAdapter extends RecyclerView.Adapter<EpAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView tv;
            VH(View v) { super(v); tv = v.findViewById(R.id.tvEp); }
        }
        @Override public VH onCreateViewHolder(android.view.ViewGroup p, int t) {
            return new VH(getLayoutInflater().inflate(R.layout.item_episode, p, false));
        }
        @Override public void onBindViewHolder(VH h, int pos) {
            Episode e = epList.get(pos);
            h.tv.setText(e.title);
            // 当前集高亮 (黄色边框 + 加粗), 遥控器扫一眼就知道在哪儿
            h.itemView.setSelected(pos == epIndex);
            h.tv.setTypeface(android.graphics.Typeface.DEFAULT,
                    pos == epIndex ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            h.itemView.setOnClickListener(v -> selectEp(pos));
            h.itemView.setOnFocusChangeListener((v, has) -> {
                FocusAnim.scale(v, has);
                h.tv.setTextColor(has ? getResources().getColor(R.color.text_focus)
                                      : getResources().getColor(R.color.text_primary));
            });
        }
        @Override public int getItemCount() { return epList.size(); }
    }

    private void onItemClick(Anime a) {
        // 首页"继续观看"行: 直接续播最近一条
        if (a.isResume) {
            resumeFirst();
            return;
        }
        if (listMode.equals("history")) {
            for (HistoryStore.Item it : history.load()) {
                if (it.aid == a.id) { openAnime(a, it.epIndex, it.line, it.pos); return; }
            }
        }
        openAnime(a, 0, null, 0);
    }

    // ================= 遥控器返回键 (防误触: 两次退出) =================
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // 详情页: 第一次返回首页
            if (detail != null) {
                resetToHome();
                return true;
            }
            // 从播放器返回后: 本次返回直接退出 (播放已算一次返回)
            if (fromPlayer) {
                fromPlayer = false;
                finish();
                return true;
            }
            // 首页/列表: 2秒内连按两次退出
            long now = System.currentTimeMillis();
            if (now - lastBackAt < 2000) {
                finish();
                return true;
            }
            lastBackAt = now;
            Toast.makeText(this, "再按一次返回退出应用", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /** 回到首页列表 (无论当前处于什么状态, 强制重置) */
    private void resetToHome() {
        detail = null;
        epList.clear();
        epAdapter.notifyDataSetChanged();
        busy = false;            // 解除加载中标志, 保证返回键/返回按钮一定能回首页
        showHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 从播放器返回: 清详情回首页, 保证"播放中返回两次即退出"
        if (fromPlayer) {
            resetToHome();
        }
        // 焦点兜底: 从弹窗/播放器回来后若无焦点, 回到顶部按钮 (遥控器不会失灵)
        if (tvMode) {
            getWindow().getDecorView().post(() -> {
                View f = getCurrentFocus();
                if (f == null || !f.isFocused()) {
                    View v = findViewById(R.id.btnHome);
                    if (v != null) v.requestFocus();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        pool.shutdownNow();
    }
}
