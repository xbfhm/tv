package com.animetv;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.animetv.rule.RuleRepo;

/**
 * 设置 / 关于页面: 片源信息 + 操作说明 + 开源声明。
 * 纯代码构建, 复用深色主题配色 (无需额外布局文件)。
 */
public class SettingsActivity extends Activity {

    private static final int C_BG = Color.parseColor("#0B0E14");
    private static final int C_PANEL = Color.parseColor("#171B24");
    private static final int C_ACCENT = Color.parseColor("#FF3D71");
    private static final int C_TEXT = Color.parseColor("#F0F2F8");
    private static final int C_DIM = Color.parseColor("#8A93A8");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));

        // 标题
        TextView title = new TextView(this);
        title.setText("设置 · 关于");
        title.setTextColor(C_ACCENT);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        root.addView(space(16));
        root.addView(section("片源"));
        root.addView(info("搜索源：AGE 官方 API（最稳定）+ 聚合搜索"));
        root.addView(info("Kazumi 规则源：" + RuleRepo.getRules().size() + " 条内置规则\n"
                + "（来自 Predidit/KazumiRules，可在首页顶栏「源」切换）"));

        root.addView(space(16));
        root.addView(section("播放"));
        root.addView(info("内置 ExoPlayer 硬解，默认 720p 起播\n"
                + "画质/倍速选择自动记忆\n"
                + "自动连播、线路自动切换"));

        root.addView(space(16));
        root.addView(section("遥控器操作"));
        root.addView(info("方向键 = 移动选择\nOK = 确认/播放暂停\n"
                + "播放中 ←→ = 快进/快退 15 秒\n播放中 ↑↓ = 音量\n"
                + "返回 = 后退/退出"));

        root.addView(space(16));
        root.addView(section("开源"));
        root.addView(info("项目：github.com/xbfhm/tv\n"
                + "规则：github.com/Predidit/KazumiRules\n"
                + "仅供学习交流，片源版权归原作者所有"));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        // 返回键退出
        scroll.setFocusable(true);
        scroll.requestFocus();
    }

    private TextView section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(C_ACCENT);
        t.setTextSize(19);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView info(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(C_TEXT);
        t.setTextSize(15);
        t.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, 0);
        t.setLayoutParams(lp);
        return t;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
