# AnimeTV — Java 原生版 (对标云视听小电视)

基于 **AGE 动漫官方 API + Kazumi 规则源** 的免费追番 TV 应用，**原生 Java 重写**，
专为老电视（海信 VIDAA V1 / Android 5.1.1 / Mali-450 / 2GB）打造。

> 当前版本: **v6.1** (构建产物: `animetv-tv-apk`)

## v6.0/v6.1 新特性：原生 Kazumi 规则引擎 + 瘦身

- 🔌 **内置 16 条 Kazumi 官方规则**（来自 `Predidit/KazumiRules`），顶栏「源」按钮一键切换
- 🔍 **原生搜索/选集**：不再是网页套壳，直接解析规则源 HTML/JSON（XPath + JSONPath）
- ⚡ **原生播放**：从播放页嗅探 m3u8/mp4 直链 → ExoPlayer 硬解
- 🎯 支持「聚合搜索」：AGE + 全部规则源并行搜索，结果带来源标签
- 🛠️ 规则引擎依赖：jsoup(HTML解析) + JsoupXpath(XPath) + 内置 JSONPath
- 🎨 **Kazumi 风格深色 UI**：粉红强调色 + 圆角海报卡 + 标题渐变遮罩
- 📉 **体积 200MB → 约 15MB**：彻底移除 GeckoView(Firefox 内核) + 内置浏览器
- ⚙️ 新增「设置」页（片源 / 播放 / 遥控器说明 / 开源声明）
- 🛡️ 修复 AGE 首页间歇性 403（预热 cookie + 重试 + 回退续播列表）

## 为什么重写 Java

| | Kivy/Python 版 | Java 原生版（本仓库） |
|---|---|---|
| 渲染 | SDL2 + OpenGL 自绘（老GPU兼容差） | **Android 系统控件** + 硬件加速 |
| 播放 | ffpyplayer 软解（1080p 卡） | **ExoPlayer 硬解**（走电视芯片解码器） |
| 内存 | 解释器+SDL2 ≈250MB | 原生 ≈80MB |
| 老系统兼容 | 闪退风险 | **minSdk 21 + targetSdk 26**（云视听式宽适配） |
| 中文字体 | 需打包 5.7MB 字体 | **系统自带 CJK 字体** |

## UI (v5.3: 借鉴 Kazumi + 云视听小电视)

### 主界面 (借鉴 Kazumi)
- 🧭 **左侧导航栏**：首页 / 追番 / 历史 竖排菜单，方向键上下切换
- 🖼️ **海报墙网格**：首页最新更新、追番目录、搜索结果全部以海报卡片墙展示（封面 + 名称），聚焦放大浮起
- 🔍 顶部搜索框：电视端聚焦即弹输入对话框
- 📋 底部详情面板：选中海报后显示封面 + 简介 + 选集条 + 播放控制

### 播放器 (借鉴云视听小电视)
- 🎬 **顶部渐变标题条** + **底部半透明控制条**（进度条 + 时间 + 按钮行）
- ⏯ **中央大播放/暂停按钮**：暂停时显示，OK 或点击切换
- ▶ 内置 ExoPlayer 硬解，默认 720p 保老电视流畅
- ⏪ 续播记忆 / 画质倍速记忆 / 自动连播 / 自动换源
- 🧭 只保留内置播放器（已移除网页版/浏览器/外部播放，体积从 200MB 降到约 15MB）

## 功能

- 🔥 首页：最新更新 + 本周新番（封面图加载），顶部固定「▶ 继续观看」一键续播
- 🔍 搜索：中文番名（海贼王/咒术回战/葬送的芙莉莲...），海报墙结果
- 📺 2026 新番目录（冬/春/夏）
- 🕘 播放历史：OK 恢复进度，长按删除单条
- 🎚️ 可调进度条：触摸拖动 / 遥控器聚焦后 ←→ 调节
- ⏩ 倍速：1.0x → 1.25x → 1.5x → 2.0x → 0.75x → 0.5x，跨集跨会话记忆
- 🎞️ 画质：自适应/1080p/720p/480p/360p，选择自动记忆
- 遥控器全屏操作：OK=控制条、←→=快进/快退15秒、↑↓=音量
- 自动连播、14 条免费线路自动轮换 + 网络错误自动换源
- 错误重试：加载失败后 [OK] 直接重试当前操作

## 构建 APK（GitHub Actions，无需电脑）

1. 把 `ad6.1-java.zip` 上传到仓库（main 分支），确认 `.github/workflows/build.yml` 为最新版（自动兼容任意 `ad*-java.zip`）
2. Actions → **Build Java APK** → 等 5~15 分钟
3. 下载 `animetv-tv-apk` 中的 APK 安装到电视

> 本地构建：`gradle assembleDebug`（需 JDK 17）

## 项目结构

```
app/src/main/java/com/animetv/
├── MainActivity.java     # 主界面: 顶部导航 + 海报墙 + 详情/选集/历史/源切换
├── PlayerActivity.java   # 播放器 (云视听式控制条 + 续播/画质/倍速记忆)
├── SettingsActivity.java # 设置/关于 (片源/播放/操作说明/开源)
├── api/AgeApi.java       # AGE 官方 API 客户端 (纯 Java, OkHttp)
├── rule/                 # Kazumi 规则引擎
│   ├── RuleRepo.java     # 内置规则仓库 (assets/rules.json)
│   ├── KazumiRule.java   # 规则模型 (XPath + API 模式)
│   ├── KazumiEngine.java # 搜索/章节解析 (jsoup + JsoupXpath)
│   ├── JsonPath.java     # 极简 JSONPath + @变量模板
│   └── PlayUrlSniffer.java # 播放页嗅探 m3u8/mp4
├── model/                # 数据模型
└── util/
    ├── HistoryStore.java # 播放历史 (带进度, 支持删除)
    ├── FocusAnim.java    # 电视焦点缩放/浮起动画
    ├── UIMode.java       # 电视端/手机端模式
    └── DiskCache.java    # API 磁盘缓存
app/src/main/res/         # 布局/主题/焦点样式 (TV 遥控器优化)
.github/workflows/build.yml
```

## 技术备注

- AGE 片源：`api.agedm.io/v2` + `jx.wuzhoupai.com:8443`
- Kazumi 规则源：内置在 `assets/rules.json`（16 条，来自 KazumiRules 官方仓库），失效时替换该文件即可
- 规则引擎依赖 jsoup / JsoupXpath / commons-lang3 / antlr4-runtime / slf4j-api，均纯 Java 兼容 Android 5.x（已启用 core library desugaring 回填 Java8 API）
- 若片源失效：改 `api/AgeApi.java` 顶部的 `API_BASE` / `JX_BASE`
- minSdk 21 / targetSdk 26 / 双 ABI 自动（Gradle 默认）
- 体积瘦身：已移除 GeckoView + 内置浏览器，APK 约 15MB（原 200MB 大头是 Firefox 内核）
- 焦点动画若嫌大/嫌卡：改 `util/FocusAnim.java` 的 `SCALE`（如 1.03）
