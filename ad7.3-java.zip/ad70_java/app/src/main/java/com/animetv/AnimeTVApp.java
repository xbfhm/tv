package com.animetv;

import android.app.Application;
import android.content.Intent;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 全局崩溃捕获: 闪退时把堆栈写入文件, 便于排障 */
public class AnimeTVApp extends Application {
    private static String TAG = "AnimeTV";

    /** 启动/崩溃打点: 私有目录+外部目录双写 */
    public static void log(String msg) {
        try {
            String line = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date()) + " " + msg;
            File[] dirs = new File[2];
            try {
                if (app != null) {
                    dirs[0] = app.getFilesDir();
                    try { dirs[1] = app.getExternalFilesDir(null); } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
            if (dirs[0] == null) dirs[0] = new File("/data/data/com.animetv/files");
            for (File dir : dirs) {
                if (dir == null) continue;
                try {
                    dir.mkdirs();
                    File f = new File(dir, "startup.log");
                    try (PrintWriter pw = new PrintWriter(new FileWriter(f, true))) {
                        pw.println(line);
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    public static AnimeTVApp app;

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        com.animetv.api.AgeApi.init(this);   // 初始化磁盘缓存
        com.animetv.rule.RuleRepo.init(this); // 加载 Kazumi 规则
        log("APP onCreate");
        // 后台预热 AGE 主站 cookie (规避首页间歇性 403)
        new Thread(() -> com.animetv.api.AgeApi.warmUp(), "age-warmup").start();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            String stack = "";
            try {
                java.io.StringWriter sw = new java.io.StringWriter();
                throwable.printStackTrace(new java.io.PrintWriter(sw));
                stack = sw.toString();
            } catch (Throwable ignored) {}
            try {
                File[] dirs = new File[]{ getFilesDir(), getExternalFilesDir(null) };
                for (File dir : dirs) {
                    if (dir == null) continue;
                    try {
                        dir.mkdirs();
                        File f = new File(dir, "crash.txt");
                        try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
                            pw.println("===== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                                    .format(new Date()) + " =====");
                            pw.println(stack);
                        }
                    } catch (Exception ignored) {}
                }
                Log.e("AnimeTV", "CRASH", throwable);
                // 诊断: 存一份到偏好里, 设置页"诊断信息"可以直接看
                com.animetv.util.Prefs.diag(this, com.animetv.util.Prefs.K_LAST_CRASH, stack);
            } catch (Throwable ignored) {}

            // 崩溃时不要只留一片黑: 拉起一个能看堆栈的页面
            try {
                Intent i = new Intent(this, CrashActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.putExtra("stack", stack);
                startActivity(i);
                Thread.sleep(1500);
            } catch (Throwable ignored) {}

            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        });
    }
}
