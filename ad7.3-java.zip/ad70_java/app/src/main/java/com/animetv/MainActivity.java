package com.animetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.animetv.api.AgeApi;
import com.animetv.api.FfzyApi;
import com.animetv.model.Anime;
import com.animetv.model.AnimeDetail;
import com.animetv.model.Episode;
import com.animetv.rule.AutoSource;
import com.animetv.rule.KazumiEngine;
import com.animetv.rule.KazumiRule;
import com.animetv.rule.PlayUrlSniffer;
import com.animetv.rule.RuleRepo;
import com.animetv.util.FocusAnim;
import com.animetv.util.HistoryStore;
import com.animetv.util.Motion;
import com.animetv.util.Prefs;
import com.animetv.util.UIMode;
import com.animetv.util.UrlCache;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 主界面 v7
 * <p>
 * 交互: 顶部胶囊导航 + 全屏海报墙 + 底部滑出详情面板。
 * 性能: 首页"缓存直出 + 后台刷新"(打开即有内容), 海报聚焦时后台预取详情,
 * 详情打开时提前解析第一条播放直链 —— 播放时基本 0 等待。
 */
public class MainActivity extends AppCompatActivity {

    private TextView tvTitle, tvSlogan, tvHome, tvCatalog, tvHistory, tvSettings;
    private TextView tvInfo, tvListTitle, btnSearch, btnSource, btnPlay, btnPrev, btnNext, btnLine, btnBackHome, btnResume;
    private TextView tvLoading;
    private EditText etSearch;
    private ImageView ivDetailCover;
    private RecyclerView rvList, rvEpisodes;
    private View detailPanel, bottomBar, loadingBox;

    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Anime> animeList = new ArrayList<>();
    private final List<Episode> epList = new ArrayList<>();
    private final ListAdapter listAdapter = new ListAdapter();
    private final EpAdapter epAdapter = new EpAdapter();

    private AnimeDetail detail;
    private int epIndex = 0;
    private boolean busy = false;
    private String listMode = "home";
    private int reqSeq = 0;

    private HistoryStore history;
    private boolean tvMode = true;
    private boolean fromPlayer = false;
    private long lastBackAt = 0;

    private String lastKeyword = "";
    private long resumePos = 0;
    private int resumeEpForPos = -1;
    private boolean searchDialogOpen = false;
    private long lastSearchDialogClose = 0;

    private String source = "AGE";
    private KazumiEngine engine;

    private int prefetchAid = 0;
    private boolean firstFocus = true;

    // ==================== 生命周期 ====================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!UIMode.chosen(this)) showModeDialog();
        tvMode = UIMode.isTV(this);
        try {
            setRequestedOrientation(tvMode
                    ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } catch (Exception ignored) {}
        setContentView(tvMode ? R.layout.activity_main : R.layout.activity_main_phone);
        AnimeTVApp.log("Main onCreate: 布局完成 (mode=" + tvMode + ")");

        history = new HistoryStore(this);
        RuleRepo.init(this);
        engine = new KazumiEngine(AgeApi.getClient());

        bindViews();
        setupNav();
        setupList();
        selectNav(0);
        showHome();

        // 首屏动画: 内容区淡入
        if (rvList != null) {
            rvList.setAlpha(0f);
            rvList.animate().alpha(1f).setDuration(260).start();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && firstFocus && tvMode) {
            firstFocus = false;
            View v = tvHome != null ? tvHome : rvList;
            if (v != null) v.post(v::requestFocus);
        }
    }

    private void showModeDialog() {
        try {
            new AlertDialog.Builder(this)
                    .setTitle("选择界面模式")
                    .setMessage("第一次使用，请选择操作方式\n\n"
                            + "📺 电视端：遥控器操作，大字体界面\n"
                            + "📱 手机端：触屏操作，竖屏界面")
                    .setPositiveButton("电视端", (di, w) -> {
                        UIMode.set(this, UIMode.TV);
                        recreate();
                    })
                    .setNegativeButton("手机端", (di, w) -> {
                        UIMode.set(this, UIMode.PHONE);
                        recreate();
                    })
                    .setCancelable(false)
                    .show();
        } catch (Exception ignored) {}
    }

    // ==================== 绑定 ====================

    private void bindViews() {
        tvTitle = findViewById(R.id.tvTitle);
        tvSlogan = findViewById(R.id.tvSlogan);
        tvHome = findViewById(R.id.tvHome);
        tvCatalog = findViewById(R.id.tvCatalog);
        tvHistory = findViewById(R.id.tvHistory);
        tvSettings = findViewById(R.id.tvSettings);
        tvInfo = findViewById(R.id.tvInfo);
        tvListTitle = findViewById(R.id.tvListTitle);
        tvLoading = findViewById(R.id.tvLoading);
        etSearch = findViewById(R.id.etSearch);
        btnSearch = findViewById(R.id.btnSearch);
        btnSource = findViewById(R.id.btnSource);
        btnPlay = findViewById(R.id.btnPlay);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnLine = findViewById(R.id.btnLine);
        btnBackHome = findViewById(R.id.btnBackHome);
        btnResume = findViewById(R.id.btnResume);
        ivDetailCover = findViewById(R.id.ivDetailCover);
        rvList = findViewById(R.id.rvList);
        rvEpisodes = findViewById(R.id.rvEpisodes);
        detailPanel = findViewById(R.id.detailPanel);
        bottomBar = findViewById(R.id.bottomBar);
        loadingBox = findViewById(R.id.loadingBox);
        updateSourceBtn();
    }

    private void setupNav() {
        if (tvHome != null) {
            tvHome.setOnClickListener(v -> {
                selectNav(0);
                showHome();
            });
            FocusAnim.bind(tvHome);
        }
        if (tvCatalog != null) {
            tvCatalog.setOnClickListener(v -> {
                selectNav(1);
                showCatalog();
            });
            FocusAnim.bind(tvCatalog);
        }
        if (tvHistory != null) {
            tvHistory.setOnClickListener(v -> {
                selectNav(2);
                showHistory();
            });
            FocusAnim.bind(tvHistory);
        }
        if (tvSettings != null) {
            tvSettings.setOnClickListener(v -> {
                selectNav(3);
                startActivity(new Intent(this, SettingsActivity.class));
            });
            FocusAnim.bind(tvSettings);
        }

        if (btnSearch != null) {
            btnSearch.setOnClickListener(v -> {
                if (tvMode) showSearchDialog();
                else doSearch();
            });
            FocusAnim.bind(btnSearch);
        }
        if (btnSource != null) {
            btnSource.setOnClickListener(v -> showSourceDialog());
            FocusAnim.bind(btnSource);
        }
        if (etSearch != null) {
            etSearch.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    doSearch();
                    return true;
                }
                return false;
            });
        }

        if (btnPlay != null) {
            btnPlay.setOnClickListener(v -> playCurrent());
            FocusAnim.bind(btnPlay);
        }
        if (btnPrev != null) {
            btnPrev.setOnClickListener(v -> prevEp());
            FocusAnim.bind(btnPrev);
        }
        if (btnNext != null) {
            btnNext.setOnClickListener(v -> nextEp());
            FocusAnim.bind(btnNext);
        }
        if (btnLine != null) {
            btnLine.setOnClickListener(v -> switchLine());
            FocusAnim.bind(btnLine);
        }
        if (btnBackHome != null) {
            btnBackHome.setOnClickListener(v -> resetToHome());
            FocusAnim.bind(btnBackHome);
        }
        if (btnResume != null) {
            btnResume.setOnClickListener(v -> resumeFirst());
            FocusAnim.bind(btnResume);
        }
        if (tvInfo != null) {
            tvInfo.setOnClickListener(v -> {
                if ("error".equals(listMode)) retryCurrent();
            });
        }
    }

    private void selectNav(int idx) {
        TextView[] navs = {tvHome, tvCatalog, tvHistory, tvSettings};
        for (int i = 0; i < navs.length; i++) {
            if (navs[i] == null) continue;
            navs[i].setSelected(i == idx);
            navs[i].setAlpha(i == idx ? 1f : 0.92f);
        }
    }

    private void setupList() {
        if (rvList == null) return;
        if (tvMode) {
            int dpW = (int) (getResources().getDisplayMetrics().widthPixels
                    / getResources().getDisplayMetrics().density);
            int cols = Prefs.getInt(this, Prefs.K_COLUMNS, 0);
            if (cols <= 0) cols = Math.max(3, Math.min(6, dpW / 240));
            rvList.setLayoutManager(new GridLayoutManager(this, cols));
        } else {
            rvList.setLayoutManager(new LinearLayoutManager(this));
        }
        rvList.setAdapter(listAdapter);
        rvList.setItemAnimator(null);
        rvList.setHasFixedSize(true);
        rvList.setItemViewCacheSize(18);
        rvList.setVerticalScrollBarEnabled(false);

        if (rvEpisodes != null) {
            rvEpisodes.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
            rvEpisodes.setAdapter(epAdapter);
            rvEpisodes.setItemAnimator(null);
        }
    }

    private void hideDetailUi() {
        if (detailPanel != null) detailPanel.setVisibility(View.GONE);
        if (rvEpisodes != null) rvEpisodes.setVisibility(View.GONE);
        if (bottomBar != null) bottomBar.setVisibility(View.GONE);
    }

    private void showDetailUi() {
        if (detailPanel != null) {
            if (detailPanel.getVisibility() != View.VISIBLE) {
                Motion.slideUpIn(detailPanel, dp(48), 0);
            }
        }
        if (rvEpisodes != null) rvEpisodes.setVisibility(View.VISIBLE);
        if (bottomBar != null) bottomBar.setVisibility(View.VISIBLE);
    }

    private void showLoading(boolean show, String msg) {
        if (loadingBox == null) return;
        if (show) {
            if (msg != null && tvLoading != null) tvLoading.setText(msg);
            if (loadingBox.getVisibility() != View.VISIBLE) Motion.fadeIn(loadingBox, 0);
        } else {
            if (loadingBox.getVisibility() == View.VISIBLE) Motion.fadeOut(loadingBox, 0);
        }
    }

    // ==================== 首页 / 目录 / 历史 ====================

    private void showHome() {
        detail = null;
        epList.clear();
        epAdapter.notifyDataSetChanged();
        listMode = "home";
        hideDetailUi();
        if (ivDetailCover != null) ivDetailCover.setVisibility(View.GONE);
        final int seq = ++reqSeq;

        // 1) 缓存直出: 打开 App 第一帧就有海报墙
        List<Anime> cached = AgeApi.homeCached();
        if (!cached.isEmpty()) {
            renderAnimeList(withResume(cached), "最新更新 · 本周新番");
            showLoading(false, null);
        } else {
            if (tvListTitle != null) tvListTitle.setText("");
            if (tvInfo != null) tvInfo.setText("");
            showLoading(true, "正在获取最新番剧…");
        }

        // 2) 后台刷新
        pool.execute(() -> {
            try {
                final List<Anime> list = AgeApi.home();
                AnimeTVApp.log("home() 返回 " + list.size() + " 条");
                ui.post(() -> {
                    if (seq != reqSeq) return;
                    showLoading(false, null);
                    renderAnimeList(withResume(list), "最新更新 · 本周新番");
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (seq != reqSeq) return;
                    showLoading(false, null);
                    if (animeList.isEmpty()) {
                        List<Anime> fallback = resumeOnlyList();
                        if (!fallback.isEmpty()) {
                            renderAnimeList(fallback, "继续观看（首页片源暂不可用）");
                            Toast.makeText(this, "首页片源暂不可用，可搜索番剧", Toast.LENGTH_LONG).show();
                        } else {
                            uiError("首页加载失败: " + e.getMessage() + "\n\n可点「搜索」直接搜番");
                        }
                    }
                });
            }
        });
    }

    private List<Anime> withResume(List<Anime> list) {
        List<Anime> out = new ArrayList<>();
        List<HistoryStore.Item> hists = history.load();
        if (!hists.isEmpty()) {
            HistoryStore.Item it = hists.get(0);
            Anime r = new Anime(it.aid, it.name, "", "", "");
            r.cover = "";
            r.display = "▶ 继续观看\n" + it.name + " · " + it.ep;
            r.isResume = true;
            out.add(r);
        }
        if (list != null) out.addAll(list);
        return out;
    }

    private List<Anime> resumeOnlyList() {
        List<Anime> out = new ArrayList<>();
        for (HistoryStore.Item it : history.load()) {
            Anime r = new Anime(it.aid, it.name, "", "", "");
            r.display = "▶ 继续观看\n" + it.name + " · " + it.ep;
            r.isResume = true;
            out.add(r);
        }
        return out;
    }

    private void showCatalog() {
        detail = null;
        epList.clear();
        epAdapter.notifyDataSetChanged();
        listMode = "catalog";
        hideDetailUi();
        if (rvList != null) rvList.scrollToPosition(0);
        final int seq = ++reqSeq;
        showLoading(true, "正在加载 2026 新番目录…");
        pool.execute(() -> {
            try {
                List<Anime> list = new ArrayList<>();
                list.addAll(AgeApi.catalog(2026, 1));
                list.addAll(AgeApi.catalog(2026, 4));
                list.addAll(AgeApi.catalog(2026, 7));
                final List<Anime> fl = list;
                ui.post(() -> {
                    if (seq != reqSeq) return;
                    showLoading(false, null);
                    renderAnimeList(fl, "2026 新番一览");
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (seq != reqSeq) return;
                    showLoading(false, null);
                    uiError("目录加载失败: " + e.getMessage());
                });
            }
        });
    }

    private void showHistory() {
        detail = null;
        epList.clear();
        epAdapter.notifyDataSetChanged();
        listMode = "history";
        hideDetailUi();
        List<HistoryStore.Item> items = history.load();
        if (items.isEmpty()) {
            if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
            if (ivDetailCover != null) ivDetailCover.setVisibility(View.GONE);
            if (tvInfo != null) tvInfo.setText("暂无播放历史\n\n看过的番会记录在这里");
            if (rvEpisodes != null) rvEpisodes.setVisibility(View.GONE);
            if (bottomBar != null) bottomBar.setVisibility(View.GONE);
            animeList.clear();
            listAdapter.notifyDataSetChanged();
            if (tvListTitle != null) tvListTitle.setText("");
            return;
        }
        List<Anime> list = new ArrayList<>();
        for (HistoryStore.Item it : items) {
            Anime a = new Anime(it.aid, it.name, "", "", "");
            a.display = it.name + "\n▶ " + it.ep;
            list.add(a);
        }
        renderAnimeList(list, "播放历史 · OK 恢复 / 长按删除");
    }

    private void doSearch() {
        doSearch(etSearch != null ? etSearch.getText().toString().trim() : "");
    }

    private void doSearch(String kw) {
        lastKeyword = kw;
        if (kw.isEmpty()) {
            if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
            if (rvEpisodes != null) rvEpisodes.setVisibility(View.GONE);
            if (bottomBar != null) bottomBar.setVisibility(View.GONE);
            if (tvInfo != null) tvInfo.setText("请输入番剧名称，如：海贼王 / 咒术回战 / 葬送的芙莉莲");
            return;
        }
        listMode = "search";
        hideDetailUi();
        if (rvList != null) rvList.scrollToPosition(0);
        final int seq = ++reqSeq;
        showLoading(true, "正在搜索「" + kw + "」(" + sourceLabel() + ")…");
        pool.execute(() -> {
            try {
                final List<Anime> list = searchBySource(kw);
                ui.post(() -> {
                    if (seq != reqSeq) return;
                    showLoading(false, null);
                    if (list.isEmpty()) {
                        animeList.clear();
                        listAdapter.notifyDataSetChanged();
                        if (tvListTitle != null) tvListTitle.setText("未找到「" + kw + "」");
                        if (tvInfo != null) {
                            tvInfo.setText("未找到「" + kw + "」相关番剧（源: " + sourceLabel() + "）\n\n换个关键词或切换搜索源试试");
                        }
                    } else {
                        renderAnimeList(list, "搜索「" + kw + "」 · " + list.size() + " 个结果");
                    }
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (seq != reqSeq) return;
                    showLoading(false, null);
                    uiError("搜索失败: " + e.getMessage());
                });
            }
        });
    }

    private List<Anime> searchBySource(String kw) throws Exception {
        if ("AGE".equals(source)) return AgeApi.search(kw);
        if (FfzyApi.NAME.equals(source)) return FfzyApi.search(kw);
        if ("聚合".equals(source)) return aggregateSearch(kw);
        KazumiRule rule = RuleRepo.get(source);
        if (rule == null) return AgeApi.search(kw);
        List<KazumiEngine.SearchItem> items = engine.search(rule, kw);
        List<Anime> out = new ArrayList<>();
        for (KazumiEngine.SearchItem it : items) {
            Anime a = new Anime();
            a.name = it.name;
            a.display = it.name;
            a.url = it.url;
            a.source = rule.name;
            a.baseUrl = rule.baseUrl;
            out.add(a);
        }
        return out;
    }

    private List<Anime> aggregateSearch(String kw) throws Exception {
        List<Anime> out = new ArrayList<>();
        List<KazumiRule> rules = new ArrayList<>(RuleRepo.getRules());
        try { out.addAll(AgeApi.search(kw)); } catch (Exception ignored) {}
        try { out.addAll(FfzyApi.search(kw)); } catch (Exception ignored) {}
        java.util.concurrent.ExecutorService p = java.util.concurrent.Executors.newFixedThreadPool(6);
        final List<Anime> sync = java.util.Collections.synchronizedList(new ArrayList<Anime>());
        for (KazumiRule r : rules) {
            p.execute(() -> {
                try {
                    List<KazumiEngine.SearchItem> items = engine.search(r, kw);
                    List<Anime> tmp = new ArrayList<>();
                    for (KazumiEngine.SearchItem it : items) {
                        Anime a = new Anime();
                        a.name = it.name;
                        a.display = it.name;
                        a.url = it.url;
                        a.source = r.name;
                        a.baseUrl = r.baseUrl;
                        tmp.add(a);
                    }
                    synchronized (sync) { sync.addAll(tmp); }
                } catch (Exception ignored) {}
            });
        }
        p.shutdown();
        try { p.awaitTermination(25, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        out.addAll(sync);
        return out;
    }

    private String sourceLabel() {
        if ("AGE".equals(source)) return "AGE官方";
        if (FfzyApi.NAME.equals(source)) return "非凡资源";
        if ("聚合".equals(source)) return "聚合搜索";
        return source;
    }

    private void updateSourceBtn() {
        if (btnSource != null) btnSource.setText("源: " + sourceLabel());
    }

    private void showSourceDialog() {
        final List<String> names = new ArrayList<>();
        names.add("AGE官方（最稳定）");
        names.add("非凡资源（备用大库，10万+）");
        names.add("聚合搜索（全部源一起搜）");
        for (KazumiRule r : RuleRepo.getRules()) names.add(r.name);
        final String[] arr = names.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("选择搜索源")
                .setItems(arr, (dialog, which) -> {
                    if (which == 0) source = "AGE";
                    else if (which == 1) source = FfzyApi.NAME;
                    else if (which == 2) source = "聚合";
                    else source = RuleRepo.getRules().get(which - 3).name;
                    updateSourceBtn();
                    if ("search".equals(listMode) && !lastKeyword.isEmpty()) doSearch(lastKeyword);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ==================== 渲染 ====================

    private void renderAnimeList(List<Anime> list, String title) {
        animeList.clear();
        animeList.addAll(list);
        listAdapter.notifyDataSetChanged();
        if (tvListTitle != null) {
            tvListTitle.setText(title + (list.isEmpty() ? "" : "  ·  " + list.size() + " 部"));
        }
        if (rvList != null) rvList.scrollToPosition(0);
    }

    private void uiError(String msg) {
        listMode = "error";
        if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
        if (rvEpisodes != null) rvEpisodes.setVisibility(View.GONE);
        if (bottomBar != null) bottomBar.setVisibility(View.GONE);
        if (tvInfo != null) {
            tvInfo.setText(msg + "\n\n按 OK 重试");
            tvInfo.setFocusable(true);
            tvInfo.setClickable(true);
            tvInfo.requestFocus();
        }
        if (tvListTitle != null) tvListTitle.setText("");
    }

    private void retryCurrent() {
        if ("catalog".equals(listMode)) showCatalog();
        else if (!lastKeyword.isEmpty()) doSearch(lastKeyword);
        else showHome();
    }

    // ==================== 详情 ====================

    private void openAnime(Anime a, int resumeEp, String resumeLine, long resumePosMs) {
        if (busy) return;
        busy = true;
        if (tvInfo != null) tvInfo.setText("正在解析《" + a.name + "》…");
        pool.execute(() -> {
            try {
                final AnimeDetail d;
                if (a.source == null || "AGE".equals(a.source)) {
                    d = AgeApi.detail(a.id);
                } else if (FfzyApi.NAME.equals(a.source)) {
                    d = FfzyApi.detail(a.id);
                } else {
                    d = kazumiDetail(a);
                }
                if (d.episodes.isEmpty()) {
                    ui.post(() -> {
                        busy = false;
                        if (detailPanel != null) detailPanel.setVisibility(View.VISIBLE);
                        if (rvEpisodes != null) rvEpisodes.setVisibility(View.GONE);
                        if (bottomBar != null) bottomBar.setVisibility(View.GONE);
                        if (tvInfo != null) {
                            tvInfo.setText("《" + d.name + "》暂无免费播放线路\n\n版权番可能仅有 VIP 源");
                        }
                        epList.clear();
                        epAdapter.notifyDataSetChanged();
                    });
                    return;
                }
                if (resumeLine != null && !resumeLine.isEmpty() && hasLine(d, resumeLine)) {
                    d.currentLine = resumeLine;
                }
                final int idx = Math.min(Math.max(resumeEp, 0), d.episodes.size() - 1);
                resumePos = resumePosMs;
                resumeEpForPos = idx;
                ui.post(() -> {
                    busy = false;
                    renderDetail(d, idx);
                });
                prefetchFirstEpisode(d, idx);
            } catch (Exception e) {
                ui.post(() -> {
                    busy = false;
                    uiError("解析失败: " + e.getMessage());
                });
            }
        });
    }

    /** 后台预解析当前集直链: 用户按播放时直接命中缓存 */
    private void prefetchFirstEpisode(final AnimeDetail d, final int idx) {
        try {
            if (idx < 0 || idx >= d.episodes.size()) return;
            final Episode e = d.episodes.get(idx);
            if (UrlCache.get(epKey(e)) != null) return;
            pool.execute(() -> {
                try {
                    String u = resolveEpisode(e, d);
                    if (u != null) UrlCache.put(epKey(e), u);
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }

    private boolean hasLine(AnimeDetail d, String line) {
        for (Episode e : d.episodes) if (e.line.equals(line)) return true;
        return false;
    }

    private AnimeDetail kazumiDetail(Anime a) throws Exception {
        KazumiRule rule = RuleRepo.get(a.source);
        if (rule == null) throw new Exception("规则不存在: " + a.source);
        List<KazumiEngine.Road> roads = engine.chapters(rule, a.url);
        AnimeDetail d = new AnimeDetail();
        d.name = a.name;
        d.source = a.source;
        d.baseUrl = rule.baseUrl;
        d.detailUrl = a.url;
        int roadIdx = 0;
        for (KazumiEngine.Road road : roads) {
            String roadName = road.name.isEmpty() ? ("线路" + (roadIdx + 1)) : road.name;
            for (KazumiEngine.Ep ep : road.eps) {
                Episode e = new Episode();
                e.line = String.valueOf(roadIdx);
                e.lineLabel = roadName;
                e.title = ep.name;
                e.url = ep.url;
                e.source = a.source;
                e.baseUrl = rule.baseUrl;
                e.vip = false;
                d.episodes.add(e);
            }
            roadIdx++;
        }
        if (!d.episodes.isEmpty()) d.currentLine = d.episodes.get(0).line;
        d.vipOnly = d.episodes.isEmpty();
        return d;
    }

    private void renderDetail(AnimeDetail d, int idx) {
        detail = d;
        epIndex = idx;
        showDetailUi();

        StringBuilder sb = new StringBuilder();
        for (String t : d.tags) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(t);
        }
        StringBuilder info = new StringBuilder();
        info.append("《").append(d.name).append("》");
        if (!"AGE".equals(d.source)) {
            info.append("\n源: ").append(d.source).append(" · 共 ").append(d.episodes.size()).append(" 集");
        } else {
            info.append("\n").append(d.type).append(" · ").append(d.premiere)
                    .append(" · ").append(d.status).append(" · ").append(d.uptodate);
            if (sb.length() > 0) info.append("\n").append(sb);
        }
        String intro = d.intro == null ? "" : d.intro;
        if (!intro.isEmpty()) {
            info.append("\n\n简介: ").append(intro.length() > 220 ? intro.substring(0, 220) + "…" : intro);
        }
        info.append("\n\n↓ 选集  ▶ 播放（遥控器: OK / ←→ / 菜单键）");
        if (tvInfo != null) tvInfo.setText(info.toString());

        if (ivDetailCover != null) {
            if (d.cover != null && !d.cover.isEmpty()) {
                ivDetailCover.setVisibility(View.VISIBLE);
                Glide.with(this).load(d.cover)
                        .apply(new RequestOptions()
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .format(DecodeFormat.PREFER_RGB_565)
                                .centerCrop()
                                .override(480, 280)
                                .placeholder(R.color.bg_card)
                                .error(R.color.bg_card))
                        .transition(DrawableTransitionOptions.withCrossFade(180))
                        .into(ivDetailCover);
            } else {
                ivDetailCover.setVisibility(View.GONE);
            }
        }

        epList.clear();
        epList.addAll(d.episodes);
        epAdapter.notifyDataSetChanged();
        if (rvEpisodes != null) {
            final int target = epIndex;
            rvEpisodes.post(() -> rvEpisodes.scrollToPosition(target));
        }
        updateButtons();
        if (tvMode && rvEpisodes != null) {
            rvEpisodes.postDelayed(() -> {
                if (rvEpisodes.getChildCount() > 0) rvEpisodes.requestFocus();
            }, 120);
        }
    }

    // ==================== 选集 / 播放 ====================

    private void selectEp(int i) {
        if (epList.isEmpty()) return;
        epIndex = Math.min(Math.max(i, 0), epList.size() - 1);
        resumePos = 0;
        resumeEpForPos = -1;
        updateButtons();
        resolveAndPlay();
    }

    private void playCurrent() {
        if (epList.isEmpty()) {
            if (tvInfo != null) tvInfo.setText("请先选择一部番剧");
            return;
        }
        updateButtons();
        resolveAndPlay();
    }

    private void resolveAndPlay() {
        final Episode e = epList.get(epIndex);
        final AnimeDetail d = detail;
        String hit = UrlCache.get(epKey(e));
        if (hit != null) {
            // 预解析命中: 直接进播放器, 几乎无等待
            long startPos = (epIndex == resumeEpForPos) ? resumePos : 0;
            saveHistoryStart(e, startPos);
            launchPlayer(hit, e, e.line, e.lineLabel, 1, startPos, d, d.source);
            return;
        }
        if (tvInfo != null) tvInfo.setText("《" + d.name + "》" + e.title + "\n\n正在获取播放地址…");
        busy = true;
        final int curEpNum = epNumber(e.title);
        pool.execute(() -> {
            final List<String> lines = new ArrayList<>();
            if (d.currentLine != null) lines.add(d.currentLine);
            for (Episode ep : epList) if (!lines.contains(ep.line)) lines.add(ep.line);

            // 并行试全部线路 (成功即停, 比串行快 3~4 倍)
            final java.util.concurrent.atomic.AtomicBoolean done =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            final Object[] res = new Object[3];
            java.util.concurrent.ExecutorService p2 = java.util.concurrent.Executors
                    .newFixedThreadPool(Math.min(4, Math.max(1, lines.size())));
            for (int li = 0; li < lines.size(); li++) {
                final int order = li;
                p2.execute(() -> {
                    if (done.get()) return;
                    Episode target = findSameEpisode(lines.get(order), curEpNum, epIndex);
                    if (target == null) return;
                    try {
                        String u = resolveEpisode(target, d);
                        if (u != null && done.compareAndSet(false, true)) {
                            UrlCache.put(epKey(target), u);
                            synchronized (res) {
                                res[0] = u;
                                res[1] = target.line;
                                res[2] = target.lineLabel;
                            }
                        }
                    } catch (Exception ignored) {}
                });
            }
            p2.shutdown();
            try { p2.awaitTermination(20, java.util.concurrent.TimeUnit.SECONDS); }
            catch (InterruptedException ignored) {}

            String fu = null, fl = null, flabel = null;
            synchronized (res) {
                if (res[0] != null) {
                    fu = (String) res[0];
                    fl = (String) res[1];
                    flabel = (String) res[2];
                }
            }
            String usedSource = d.source;

            // 当前源全线阵亡 → 跨源兜底 (去别的规则源找同一集)
            if (fu == null) {
                try {
                    AutoSource.Result ar = AutoSource.find(AgeApi.getClient(), d.name,
                            epNumber(e.title), e.title, null);
                    if (ar != null) {
                        fu = ar.url;
                        fl = ar.source;
                        flabel = ar.source;
                        usedSource = ar.source;
                    }
                } catch (Exception ignored) {}
            }

            final String fUrl = fu, fLine = fl, fLabel = flabel, fSrc = usedSource;
            final long startPos = (epIndex == resumeEpForPos) ? resumePos : 0;
            ui.post(() -> {
                busy = false;
                if (fUrl == null) {
                    if (!"AGE".equals(d.source)) {
                        if (tvInfo != null) {
                            tvInfo.setText("《" + d.name + "》解析失败\n\n已尝试全部片源\n该源可能失效，请换一个搜索源重试");
                        }
                        return;
                    }
                    if (d.vipOnly) {
                        if (tvInfo != null) {
                            tvInfo.setText("《" + d.name + "》为版权番\n\n仅提供 VIP 源（腾讯/爱奇艺等）\n需开通视频会员，免费无法播放");
                        }
                    } else {
                        if (tvInfo != null) {
                            tvInfo.setText("《" + d.name + "》暂时无法播放\n\n已试过当前源全部线路 + 其他片源\n可能是片源临时故障，换一部或稍后再试");
                        }
                    }
                    return;
                }
                saveHistoryStart(e, startPos);
                launchPlayer(fUrl, e, fLine, fLabel, 1, startPos, d, fSrc);
            });
        });
    }

    private void saveHistoryStart(Episode e, long startPos) {
        try {
            if (detail != null && "AGE".equals(detail.source)) {
                history.add(detail.id, detail.name, e.title, epIndex, e.line, startPos);
            }
        } catch (Exception ignored) {}
    }

    private static int epNumber(String t) {
        if (t == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(t);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    private String resolveEpisode(Episode target, AnimeDetail d) throws Exception {
        // 直接就是 m3u8/mp4 的线路 (非凡 / 部分规则源) 不需要再解析
        if (target.url != null && (target.url.contains(".m3u8") || target.url.contains(".mp4"))) {
            return target.url;
        }
        if ("AGE".equals(target.source)) {
            return AgeApi.resolve(target.enc, target.vip, d.jxZJ, d.jxVIP);
        }
        PlayUrlSniffer sniffer = new PlayUrlSniffer(AgeApi.getClient(), target.baseUrl, "");
        return sniffer.sniff(target.url);
    }

    private static String epKey(Episode e) {
        if (e == null) return "";
        if (e.enc != null && !e.enc.isEmpty()) return "AGE|" + e.enc;
        return (e.source == null ? "" : e.source) + "|" + (e.url == null ? "" : e.url);
    }

    private Episode findSameEpisode(String line, int epNum, int fallbackIdx) {
        List<Episode> lineEps = new ArrayList<>();
        for (Episode ep : epList) if (ep.line.equals(line)) lineEps.add(ep);
        if (lineEps.isEmpty()) return null;
        if (epNum > 0) {
            for (Episode ep : lineEps) if (epNumber(ep.title) == epNum) return ep;
        }
        return lineEps.get(Math.min(fallbackIdx, lineEps.size() - 1));
    }

    private void launchPlayer(String url, Episode e, String line, String lineLabel, int order,
                              long resumePosMs, AnimeDetail d, String srcName) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("url", url);
        it.putExtra("title", d.name + " " + e.title + " [" + lineLabel + "]");
        it.putExtra("animeId", d.id);
        it.putExtra("epIndex", epIndex);
        it.putExtra("line", line);
        it.putExtra("episodes", new ArrayList<>(epList));
        it.putExtra("animeName", d.name);
        it.putExtra("jxZj", d.jxZJ);
        it.putExtra("jxVip", d.jxVIP);
        it.putExtra("source", srcName == null ? d.source : srcName);
        it.putExtra("baseUrl", d.baseUrl);
        it.putExtra("lineLabel", lineLabel);
        it.putExtra("lineOrder", order);
        it.putExtra("resumePos", resumePosMs);
        fromPlayer = true;
        startActivity(it);
    }

    // ==================== 上下集 / 线路 ====================

    private void prevEp() {
        if (epIndex > 0) selectEp(epIndex - 1);
        else toast("已经是第一集");
    }

    private void nextEp() {
        if (epIndex < epList.size() - 1) selectEp(epIndex + 1);
        else toast("已经是最后一集");
    }

    private void switchLine() {
        if (epList.isEmpty() || detail == null) return;
        List<String> lines = new ArrayList<>();
        for (Episode e : epList) if (!lines.contains(e.line)) lines.add(e.line);
        if (lines.size() <= 1) {
            toast("当前只有一条线路");
            return;
        }
        int i = lines.indexOf(detail.currentLine);
        detail.currentLine = lines.get((i + 1) % lines.size());
        updateButtons();
        toast("已切换到: " + labelOfLine(detail.currentLine));
    }

    private String labelOfLine(String l) {
        for (Episode e : epList) if (e.line.equals(l)) return e.lineLabel;
        return l;
    }

    private void updateButtons() {
        if (epList.isEmpty() || detail == null) return;
        Episode e = epList.get(epIndex);
        if (btnPlay != null) btnPlay.setText("▶ 播放");
        if (btnLine != null) btnLine.setText("线路: " + e.lineLabel);
        if (btnPrev != null) {
            btnPrev.setEnabled(epIndex > 0);
            btnPrev.setAlpha(epIndex > 0 ? 1f : 0.4f);
        }
        if (btnNext != null) {
            btnNext.setEnabled(epIndex < epList.size() - 1);
            btnNext.setAlpha(epIndex < epList.size() - 1 ? 1f : 0.4f);
        }
    }

    // ==================== 搜索对话框 ====================

    private void showSearchDialog() {
        if (searchDialogOpen) return;
        searchDialogOpen = true;
        try {
            final EditText input = new EditText(this);
            input.setHint("输入番剧名（如：海贼王 / 咒术回战）");
            if (etSearch != null) input.setText(etSearch.getText());
            input.setTextColor(getResources().getColor(R.color.text_primary));
            input.setTextSize(18);
            input.setSingleLine(true);
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
            input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
            input.setSelectAllOnFocus(true);
            input.setPadding(dp(16), dp(10), dp(16), dp(10));
            input.setBackgroundColor(getResources().getColor(R.color.bg_card));

            new AlertDialog.Builder(this)
                    .setTitle("搜索番剧")
                    .setView(input)
                    .setPositiveButton("搜索", (d, w) -> {
                        String kw = input.getText().toString().trim();
                        if (etSearch != null) etSearch.setText(kw);
                        doSearch(kw);
                    })
                    .setNegativeButton("取消", null)
                    .setOnDismissListener(d -> {
                        searchDialogOpen = false;
                        lastSearchDialogClose = SystemClock.elapsedRealtime();
                        input.clearFocus();
                        if (btnSearch != null) btnSearch.requestFocus();
                    })
                    .show();

            input.post(() -> {
                input.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {
                    try { imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT); } catch (Exception ignored) {}
                }
            });
        } catch (Exception e) {
            searchDialogOpen = false;
        }
    }

    private void resumeFirst() {
        List<HistoryStore.Item> hists = history.load();
        if (hists.isEmpty()) {
            toast("暂无播放历史");
            return;
        }
        HistoryStore.Item it = hists.get(0);
        Anime a = new Anime(it.aid, it.name, "", "", "");
        openAnime(a, it.epIndex, it.line, it.pos);
    }

    private void confirmDeleteHistory(Anime a) {
        new AlertDialog.Builder(this)
                .setTitle("删除历史")
                .setMessage("删除《" + a.name + "》的播放记录？")
                .setPositiveButton("删除", (d, w) -> {
                    history.remove(a.id);
                    toast("已删除");
                    showHistory();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ==================== 焦点预取 ====================

    private final Runnable doPrefetch = () -> {
        final int aid = prefetchAid;
        if (aid <= 0) return;
        pool.execute(() -> {
            try {
                AgeApi.detail(aid);   // 只写进磁盘缓存, 打开详情时即可秒开
            } catch (Exception ignored) {}
        });
    };

    private void schedulePrefetch(int aid) {
        if (aid <= 0 || aid == prefetchAid) return;
        prefetchAid = aid;
        ui.removeCallbacks(doPrefetch);
        ui.postDelayed(doPrefetch, 350);
    }

    // ==================== 适配器 ====================

    class ListAdapter extends RecyclerView.Adapter<ListAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView tv, tvSub;
            ImageView iv;
            VH(View v) {
                super(v);
                tv = v.findViewById(R.id.tvName);
                tvSub = v.findViewById(R.id.tvSub);
                iv = v.findViewById(R.id.ivCover);
            }
        }

        @Override
        public VH onCreateViewHolder(ViewGroup p, int t) {
            int layout = tvMode ? R.layout.item_poster : R.layout.item_anime;
            return new VH(getLayoutInflater().inflate(layout, p, false));
        }

        @Override
        public void onBindViewHolder(VH h, int pos) {
            final Anime a = animeList.get(pos);
            h.tv.setText(a.display);

            if (h.iv != null) {
                if (a.cover != null && !a.cover.isEmpty()) {
                    h.iv.setVisibility(View.VISIBLE);
                    Glide.with(MainActivity.this).load(a.cover)
                            .apply(new RequestOptions()
                                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                                    .format(DecodeFormat.PREFER_RGB_565)
                                    .centerCrop()
                                    .override(tvMode ? 420 : 240, tvMode ? 260 : 140)
                                    .placeholder(R.color.bg_card)
                                    .error(R.color.bg_card))
                            .transition(DrawableTransitionOptions.withCrossFade(150))
                            .into(h.iv);
                } else {
                    h.iv.setImageDrawable(null);
                    h.iv.setVisibility(tvMode ? View.VISIBLE : View.GONE);
                    h.iv.setBackgroundColor(getResources().getColor(R.color.bg_card));
                }
            }

            if (h.tvSub != null) {
                if (a.premiere != null && !a.premiere.isEmpty()) {
                    h.tvSub.setVisibility(View.VISIBLE);
                    h.tvSub.setText(a.premiere + " | " + a.status);
                } else {
                    h.tvSub.setVisibility(View.GONE);
                }
            }

            h.itemView.setOnClickListener(v -> onItemClick(a));
            h.itemView.setOnFocusChangeListener((v, has) -> {
                FocusAnim.scale(v, has);
                if (h.tv != null) {
                    h.tv.setTextColor(getResources().getColor(has ? R.color.text_focus : R.color.text_primary));
                }
                if (has) {
                    if (a.id > 0 && !a.isResume && "AGE".equals(a.source)) schedulePrefetch(a.id);
                    rvList.post(() -> {
                        RecyclerView.LayoutManager lm = rvList.getLayoutManager();
                        if (lm == null) return;
                        int lastVisible = lm instanceof GridLayoutManager
                                ? ((GridLayoutManager) lm).findLastCompletelyVisibleItemPosition()
                                : ((LinearLayoutManager) lm).findLastCompletelyVisibleItemPosition();
                        if (pos >= lastVisible) rvList.smoothScrollToPosition(pos);
                    });
                }
            });
            h.itemView.setOnLongClickListener(v -> {
                if ("history".equals(listMode)) {
                    confirmDeleteHistory(a);
                    return true;
                }
                return false;
            });
        }

        @Override
        public int getItemCount() {
            return animeList.size();
        }
    }

    class EpAdapter extends RecyclerView.Adapter<EpAdapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            TextView tv;
            VH(View v) {
                super(v);
                tv = v.findViewById(R.id.tvEp);
            }
        }

        @Override
        public VH onCreateViewHolder(ViewGroup p, int t) {
            return new VH(getLayoutInflater().inflate(R.layout.item_episode, p, false));
        }

        @Override
        public void onBindViewHolder(VH h, int pos) {
            final Episode e = epList.get(pos);
            h.tv.setText(e.title);
            h.itemView.setSelected(pos == epIndex);
            h.tv.setTypeface(android.graphics.Typeface.DEFAULT,
                    pos == epIndex ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            h.itemView.setOnClickListener(v -> selectEp(pos));
            h.itemView.setOnFocusChangeListener((v, has) -> {
                FocusAnim.scale(v, has);
                h.tv.setTextColor(getResources().getColor(has ? R.color.text_focus : R.color.text_primary));
            });
        }

        @Override
        public int getItemCount() {
            return epList.size();
        }
    }

    private void onItemClick(Anime a) {
        if (a.isResume) {
            resumeFirst();
            return;
        }
        if ("history".equals(listMode)) {
            for (HistoryStore.Item it : history.load()) {
                if (it.aid == a.id) {
                    openAnime(a, it.epIndex, it.line, it.pos);
                    return;
                }
            }
        }
        openAnime(a, 0, null, 0);
    }

    // ==================== 返回键 ====================

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (detail != null) {
                resetToHome();
                return true;
            }
            if (fromPlayer) {
                fromPlayer = false;
                finish();
                return true;
            }
            long now = System.currentTimeMillis();
            if (now - lastBackAt < 2000) {
                finish();
                return true;
            }
            lastBackAt = now;
            toast("再按一次返回退出应用");
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void resetToHome() {
        detail = null;
        epList.clear();
        epAdapter.notifyDataSetChanged();
        busy = false;
        selectNav(0);
        showHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // 设置页切换了「电视/手机」界面模式 → 重建布局
        recreate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (fromPlayer) {
            fromPlayer = false;
            resetToHome();
        }
        if (tvMode && tvHome != null) {
            getWindow().getDecorView().post(() -> {
                View f = getCurrentFocus();
                if (f == null) tvHome.requestFocus();
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        pool.shutdownNow();
    }
}
