package com.animetv.api;

import com.animetv.model.Anime;
import com.animetv.model.AnimeDetail;
import com.animetv.model.Episode;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Request;
import okhttp3.Response;

/**
 * 非凡资源 (ffzyapi) —— 独立大库备用片源 (v7.1)
 * <p>
 * 和 AGE 完全独立的另一套片库 (10 万+ 条目), 用来兜底:
 * 当 AGE 的解析站全挂时, 这里往往还能播。
 * <p>
 * 接口: https://api.ffzyapi.com/api.php/provide/vod/?ac=detail&wd=关键词
 * 返回 JSON, vod_play_url 里 "$$$" 分线路, "#" 分集, "第01集$http://…/index.m3u8"。
 * 只有 ffm3u8 线路是真实 m3u8 直链 (其他线路多为需要会员的页面)。
 */
public class FfzyApi {

    public static final String NAME = "非凡资源";

    private static final String BASE = "https://api.ffzyapi.com/api.php/provide/vod/";
    private static final String UA =
            "Mozilla/5.0 (Linux; Android 7.0; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0 Mobile Safari/537.36";

    /** 搜索 (一次拿全量字段: 封面 / 集数 / 直链) */
    public static List<Anime> search(String keyword) throws Exception {
        List<Anime> out = new ArrayList<>();
        JSONObject j = get(BASE + "?ac=detail&wd=" + URLEncoder.encode(keyword, "UTF-8"));
        JSONArray list = j.optJSONArray("list");
        if (list == null) return out;
        for (int i = 0; i < list.length() && i < 30; i++) {
            JSONObject v = list.optJSONObject(i);
            if (v == null) continue;
            Anime a = new Anime(v.optInt("vod_id"), v.optString("vod_name"),
                    v.optString("vod_year"), v.optString("vod_area"), v.optString("vod_remarks"));
            a.cover = v.optString("vod_pic");
            a.type = v.optString("type_name");
            a.display = a.name + (a.uptodate.isEmpty() ? "" : "  " + a.uptodate);
            a.source = NAME;
            out.add(a);
        }
        return out;
    }

    /** 详情 + 全集直链 */
    public static AnimeDetail detail(int vodId) throws Exception {
        AnimeDetail d = new AnimeDetail();
        d.id = vodId;
        d.source = NAME;
        d.baseUrl = "https://www.ffzy.tv/";
        JSONObject j = get(BASE + "?ac=detail&ids=" + vodId);
        JSONArray list = j.optJSONArray("list");
        if (list == null || list.length() == 0) throw new IOException("非凡资源: 无此条目");
        JSONObject v = list.optJSONObject(0);
        d.name = v.optString("vod_name");
        d.cover = v.optString("vod_pic");
        d.intro = clean(v.optString("vod_content"));
        d.premiere = v.optString("vod_year");
        d.status = v.optString("vod_area");
        d.uptodate = v.optString("vod_remarks");
        d.type = v.optString("type_name");
        String tag = v.optString("vod_class");
        if (!tag.isEmpty()) {
            for (String t : tag.split(",")) if (!t.trim().isEmpty()) d.tags.add(t.trim());
        }

        String[] froms = v.optString("vod_play_from").split("\\$\\$\\$");
        String[] urls = v.optString("vod_play_url").split("\\$\\$\\$");
        int use = -1;
        for (int i = 0; i < froms.length && i < urls.length; i++) {
            if (froms[i].contains("ffm3u8")) {
                use = i;
                break;
            }
        }
        if (use < 0) throw new IOException("非凡资源: 无 ffm3u8 线路");
        String lineName = froms[use];
        String lineLabel = lineName.contains("ffm3u8") ? "非凡" : lineName;

        for (String seg : urls[use].split("#")) {
            if (seg == null) continue;
            int idx = seg.indexOf('$');
            if (idx <= 0) continue;
            String title = seg.substring(0, idx).trim();
            String url = seg.substring(idx + 1).trim();
            if (url.isEmpty()) continue;
            Episode e = new Episode(lineName, lineLabel, title, "", false);
            e.source = NAME;
            e.url = url;
            e.baseUrl = d.baseUrl;
            d.episodes.add(e);
        }
        if (!d.episodes.isEmpty()) d.currentLine = d.episodes.get(0).line;
        d.vipOnly = d.episodes.isEmpty();
        return d;
    }

    /** 按番名找第 N 集直链 (自动换源用) —— 只做 1 次搜索 + 1 次详情 */
    public static String findEpisodeUrl(String animeName, int epNum, String epTitle) {
        try {
            List<Anime> list = search(animeName);
            Anime best = null;
            int bestScore = 0;
            String target = norm(animeName);
            for (Anime a : list) {
                int s = score(target, norm(a.name));
                if (s > bestScore) {
                    bestScore = s;
                    best = a;
                }
            }
            if (best == null || bestScore < 40) return null;
            AnimeDetail d = detail(best.id);
            if (d.episodes.isEmpty()) return null;
            if (epNum > 0) {
                for (Episode e : d.episodes) {
                    if (num(e.title) == epNum) return e.url;
                }
            }
            if (epTitle != null && !epTitle.isEmpty()) {
                String t = norm(epTitle);
                for (Episode e : d.episodes) if (norm(e.title).equals(t)) return e.url;
            }
            if (epNum > 0 && epNum <= d.episodes.size()) return d.episodes.get(epNum - 1).url;
            return d.episodes.get(0).url;
        } catch (Exception e) {
            return null;
        }
    }

    // ================= 工具 =================

    private static JSONObject get(String url) throws Exception {
        Request req = new Request.Builder()
                .url(url)
                .header("User-Agent", UA)
                .header("Accept", "application/json,*/*")
                .build();
        try (Response resp = AgeApi.getClient().newCall(req).execute()) {
            if (!resp.isSuccessful() || resp.body() == null) {
                throw new IOException("HTTP " + resp.code());
            }
            return new JSONObject(resp.body().string());
        }
    }

    private static String clean(String html) {
        if (html == null) return "";
        return html.replaceAll("<[^>]+>", "")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&quot;", "\"")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .trim();
    }

    private static String norm(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\s\\[\\]【】()（）·・:：\\-—_!！?？.。,，'\"“”]", "").toLowerCase();
    }

    private static int score(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        if (a.equals(b)) return 100;
        if (a.contains(b) || b.contains(a)) return 75;
        int n = Math.min(Math.min(a.length(), b.length()), 8);
        int i = 0;
        while (i < n && a.charAt(i) == b.charAt(i)) i++;
        return i >= 4 ? 55 : (i >= 3 ? 45 : 0);
    }

    private static int num(String s) {
        if (s == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(s);
        if (!m.find()) return -1;
        try {
            return Integer.parseInt(m.group());
        } catch (Exception e) {
            return -1;
        }
    }
}
