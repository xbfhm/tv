package com.animetv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 崩溃展示页 (v7.2)
 * <p>
 * 之前闪退 = 一片黑 + 返回键没反应, 什么都查不到。
 * 现在崩溃会把堆栈直接画在屏幕上, 还能在「设置 → 诊断信息」里再看到。
 * 纯系统控件 + 纯代码构建, 保证它自己不会再崩。
 */
public class CrashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String stack = "";
        try {
            stack = getIntent().getStringExtra("stack");
        } catch (Throwable ignored) {}
        if (stack == null || stack.isEmpty()) stack = "（没有拿到堆栈）";

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#070A11"));
        sv.setFillViewport(true);

        TextView tv = new TextView(this);
        tv.setTextColor(Color.parseColor("#EEF1F8"));
        tv.setTextSize(13);
        tv.setPadding(dp(28), dp(28), dp(28), dp(28));
        tv.setLineSpacing(dp(3), 1f);
        tv.setTextIsSelectable(true);
        tv.setGravity(Gravity.START);
        tv.setText("AnimeTV 崩溃了\n"
                + "机型: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL
                + " · Android " + android.os.Build.VERSION.RELEASE + "\n"
                + "版本: " + BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")\n\n"
                + "把下面这段截图发给我就能定位问题：\n"
                + "————————————————\n"
                + stack
                + "\n————————————————\n\n按「返回」退出");

        sv.addView(tv);
        setContentView(sv);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        finish();
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
