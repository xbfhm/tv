# AnimeTV — Java 原生版（v7.1）

基于 **AGE 动漫官方 API** 的免费追番 TV 应用，原生 Java 重写，
专为老电视（海信 VIDAA V1 / Android 5.1.1 / Mali-450 / 2GB）打造。

- 仓库：<https://github.com/xbfhm/tv>
- 完整文档（功能 / 键位 / FAQ / 许可）：见仓库根目录 `README.md`
- 版本变更：见 `CHANGELOG.md`

## 本版要点（v7.1）

| 分类 | 内容 |
|---|---|
| UI | 深海夜色 + 霓虹渐变、胶囊导航、全屏海报墙、底部抽屉式详情 |
| 交互 | OK=播放暂停；←→ 单击 ±5s；←→ 长按拖动进度条；菜单键=更多功能面板 |
| 设置 | 键位自定义（8 个动作）、画质/倍速/步长/缓冲/列数/自动连播 |
| 性能 | 首页缓存直出、焦点预取详情、直链预解析、4 线路并发、硬件加速 |
| 播放 | ExoPlayer 硬解、HLS、倍速、画质、画面比例、自动连播 |
| 片源 | AGE 官方 + 非凡资源（10 万+ 独立大库）+ 25 条规则源；全挂时自动跨源换源 |

## 构建

### GitHub Actions
仓库根目录放入 `ad7.0-java.zip`，push 到 `main` 即触发构建；
产物在 Actions Artifacts `animetv-tv-apk` 或 Release `latest`。

### 本地
```bash
gradle assembleDebug        # JDK 17 + Android SDK 34 + Gradle 8.5
```

## 关键参数

- `applicationId com.animetv`，`minSdk 21`，`targetSdk 26`，`compileSdk 34`
- ABI：`arm64-v8a` + `armeabi-v7a`
- 依赖：AppCompat 1.6.1 / RecyclerView 1.3.2 / CardView 1.0.0 /
  Media3 1.3.1 / OkHttp 4.12 / Glide 4.16 / jsoup 1.15.3

## 许可

GPL-3.0。第三方组件见仓库 `THIRD-PARTY-NOTICES.md`。
本软件不存储任何视频文件，仅做聚合播放，请支持正版。
