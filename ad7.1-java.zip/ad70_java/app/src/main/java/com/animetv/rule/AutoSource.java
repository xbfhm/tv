package com.animetv.rule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import com.animetv.api.FfzyApi;

import okhttp3.OkHttpClient;

/**
 * 跨源自动换源 (v7.1)
 * <p>
 * 当当前源的所有免费线路都失效时, 拿「番名 + 集号」去其它 Kazumi 规则源里找同一集,
 * 找到可播放直链就返回。
 * <p>
 * 分两阶段, 保证速度:
 * <ol>
 *   <li>并行搜索全部规则 (6 线程, 短超时), 收集标题最匹配的候选;</li>
 *   <li>只对相似度最高的几条候选并行「章节解析 + 播放页嗅探」, 谁先成功用谁。</li>
 * </ol>
 * 失败/成功的站点都会记 10 分钟冷却, 避免反复撞同一堵墙。
 */
public class AutoSource {

    public static class Result {
        public String url = "";
        public String source = "";
        public String baseUrl = "";
        public String epTitle = "";
    }

    private static final int SEARCH_THREADS = 6;
    private static final long SEARCH_BUDGET_MS = 9000;
    private static final long SNIFF_BUDGET_MS = 14000;
    private static final int MAX_CANDIDATES = 5;
    private static final long COOLDOWN_MS = 10 * 60 * 1000L;

    /** 成功结果缓存: key = 番名|集号 */
    private static final Map<String, Result> HIT = new ConcurrentHashMap<>();
    /** 站点冷却: ruleName -> 到期时间 */
    private static final Map<String, Long> COOLDOWN = new ConcurrentHashMap<>();

    public static void clearCache() {
        HIT.clear();
        COOLDOWN.clear();
    }

    private static String key(String name, int ep) {
        return (name == null ? "" : name) + "|" + ep;
    }

    public static Result cached(String animeName, int epNum) {
        return HIT.get(key(animeName, epNum));
    }

    /**
     * 查找可播放的跨源直链。
     *
     * @param client    复用主 OkHttpClient (会自动套一层短超时)
     * @param animeName 番名
     * @param epNum     集号 (1 开始; -1 表示未知, 按第一条线路第一集)
     * @param epTitle   当前集标题 (兜底匹配)
     * @param exclude   已经试过 / 不想再试的源名
     */
    public static Result find(OkHttpClient client, String animeName, int epNum, String epTitle,
                              Set<String> exclude) {
        if (animeName == null || animeName.trim().isEmpty()) return null;
        Result hit = cached(animeName, epNum);
        if (hit != null) return hit;

        final List<KazumiRule> rules = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (KazumiRule r : RuleRepo.getRules()) {
            if (exclude != null && exclude.contains(r.name)) continue;
            Long cool = COOLDOWN.get(r.name);
            if (cool != null && cool > now) continue;
            rules.add(r);
        }
        if (rules.isEmpty()) return null;

        // ---------- 阶段 0: 先试「非凡资源」 (独立大库, 1~2 次请求, 命中率最高) ----------
        String ff = null;
        try {
            ff = FfzyApi.findEpisodeUrl(animeName, epNum, epTitle);
        } catch (Exception ignored) {}
        if (ff != null && !ff.isEmpty()) {
            Result r = new Result();
            r.url = ff;
            r.source = FfzyApi.NAME;
            r.baseUrl = "https://www.ffzy.tv/";
            r.epTitle = "";
            if (HIT.size() > 80) HIT.clear();
            HIT.put(key(animeName, epNum), r);
            return r;
        }

        final OkHttpClient fast = client.newBuilder()
                .connectTimeout(6, TimeUnit.SECONDS)
                .readTimeout(9, TimeUnit.SECONDS)
                .writeTimeout(6, TimeUnit.SECONDS)
                .build();
        final KazumiEngine engine = new KazumiEngine(fast);

        // ---------- 阶段 1: 并行搜索 ----------
        final List<Cand> cands = Collections.synchronizedList(new ArrayList<Cand>());
        final AtomicInteger searching = new AtomicInteger(rules.size());
        ExecutorService sp = Executors.newFixedThreadPool(SEARCH_THREADS);
        final String target = norm(animeName);
        for (final KazumiRule rule : rules) {
            sp.execute(() -> {
                try {
                    List<KazumiEngine.SearchItem> items = engine.search(rule, animeName);
                    KazumiEngine.SearchItem best = pickAnime(items, target, animeName);
                    if (best != null) {
                        int score = score(target, norm(best.name));
                        cands.add(new Cand(rule, best, score));
                    } else {
                        cool(rule.name);
                    }
                } catch (Exception ignored) {
                    cool(rule.name);
                } finally {
                    searching.decrementAndGet();
                }
            });
        }
        sp.shutdown();
        long t0 = System.currentTimeMillis();
        while (searching.get() > 0 && System.currentTimeMillis() - t0 < SEARCH_BUDGET_MS) {
            try {
                Thread.sleep(120);
            } catch (InterruptedException ignored) {
                break;
            }
        }

        if (cands.isEmpty()) return null;
        // 相似度优先
        Collections.sort(cands, (a, b) -> b.score - a.score);
        int n = Math.min(MAX_CANDIDATES, cands.size());

        // ---------- 阶段 2: 并行解析章节 + 嗅探 ----------
        final BlockingQueue<Result> done = new LinkedBlockingQueue<>();
        final AtomicLong stop = new AtomicLong(0);
        ExecutorService ep = Executors.newFixedThreadPool(n);
        for (int i = 0; i < n; i++) {
            final Cand c = cands.get(i);
            ep.execute(() -> {
                if (stop.get() > 0) return;
                try {
                    List<KazumiEngine.Road> roads = engine.chapters(c.rule, c.item.url);
                    KazumiEngine.Ep target2 = pickEpisode(roads, epNum, epTitle);
                    if (target2 == null) {
                        cool(c.rule.name);
                        return;
                    }
                    String u = new PlayUrlSniffer(fast, c.rule.baseUrl, "").sniff(target2.url);
                    if (u == null || u.isEmpty()) {
                        cool(c.rule.name);
                        return;
                    }
                    if (stop.compareAndSet(0, 1)) {
                        Result r = new Result();
                        r.url = u;
                        r.source = c.rule.name;
                        r.baseUrl = c.rule.baseUrl;
                        r.epTitle = target2.name == null ? "" : target2.name;
                        done.offer(r);
                    }
                } catch (Exception ignored) {
                    cool(c.rule.name);
                }
            });
        }
        ep.shutdown();

        Result r = null;
        try {
            r = done.poll(SNIFF_BUDGET_MS, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {}
        stop.set(1);
        ep.shutdownNow();
        sp.shutdownNow();

        if (r != null) {
            if (HIT.size() > 80) HIT.clear();
            HIT.put(key(animeName, epNum), r);
        }
        return r;
    }

    // ================= 匹配 =================

    private static class Cand {
        final KazumiRule rule;
        final KazumiEngine.SearchItem item;
        final int score;

        Cand(KazumiRule r, KazumiEngine.SearchItem i, int s) {
            rule = r;
            item = i;
            score = s;
        }
    }

    private static KazumiEngine.SearchItem pickAnime(List<KazumiEngine.SearchItem> items,
                                                     String target, String raw) {
        if (items == null || items.isEmpty()) return null;
        KazumiEngine.SearchItem best = null;
        int bestScore = 0;
        for (KazumiEngine.SearchItem it : items) {
            if (it == null || it.name == null) continue;
            int s = score(target, norm(it.name));
            if (s > bestScore) {
                bestScore = s;
                best = it;
            }
        }
        // 低于 40 分视为同名不相关, 不乱播别人的番
        return bestScore >= 40 ? best : null;
    }

    private static String norm(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\s\\[\\]【】()（）·・:：\\-—_!！?？.。,，'\"“”]", "")
                .toLowerCase();
    }

    private static int score(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        if (a.equals(b)) return 100;
        if (a.contains(b) || b.contains(a)) return 75;
        int n = Math.min(Math.min(a.length(), b.length()), 8);
        int i = 0;
        while (i < n && a.charAt(i) == b.charAt(i)) i++;
        if (i >= 4) return 55;
        if (i >= 3) return 45;
        return 0;
    }

    private static KazumiEngine.Ep pickEpisode(List<KazumiEngine.Road> roads, int epNum, String epTitle) {
        if (roads == null || roads.isEmpty()) return null;
        KazumiEngine.Ep fallback = null;
        for (KazumiEngine.Road road : roads) {
            if (road == null || road.eps == null) continue;
            for (KazumiEngine.Ep e : road.eps) {
                if (e == null) continue;
                if (fallback == null) fallback = e;
                int n = num(e.name);
                if (epNum > 0 && n == epNum) return e;
            }
            // 该线路没有集号匹配, 就按序号取
            if (epNum > 0 && epNum <= road.eps.size()) {
                KazumiEngine.Ep byIdx = road.eps.get(epNum - 1);
                if (byIdx != null) return byIdx;
            }
        }
        if (epTitle != null && !epTitle.isEmpty()) {
            String t = norm(epTitle);
            for (KazumiEngine.Road road : roads) {
                if (road == null || road.eps == null) continue;
                for (KazumiEngine.Ep e : road.eps) {
                    if (e != null && norm(e.name).equals(t)) return e;
                }
            }
        }
        return fallback;
    }

    private static int num(String s) {
        if (s == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(s);
        if (!m.find()) return -1;
        try {
            return Integer.parseInt(m.group());
        } catch (Exception e) {
            return -1;
        }
    }

    private static void cool(String ruleName) {
        try {
            if (ruleName != null) COOLDOWN.put(ruleName, System.currentTimeMillis() + COOLDOWN_MS);
        } catch (Exception ignored) {}
    }
}
