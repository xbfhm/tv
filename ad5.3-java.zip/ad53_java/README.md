# AnimeTV — Java 原生版 (对标云视听小电视)

基于 **AGE 动漫官方 API** 的免费追番 TV 应用，**原生 Java 重写**，
专为老电视（海信 VIDAA V1 / Android 5.1.1 / Mali-450 / 2GB）打造。

> 当前版本: **v5.3** (构建产物: `animetv-tv-apk`)

## 为什么重写 Java

| | Kivy/Python 版 | Java 原生版（本仓库） |
|---|---|---|
| 渲染 | SDL2 + OpenGL 自绘（老GPU兼容差） | **Android 系统控件** + 硬件加速 |
| 播放 | ffpyplayer 软解（1080p 卡） | **ExoPlayer 硬解**（走电视芯片解码器） |
| 内存 | 解释器+SDL2 ≈250MB | 原生 ≈80MB |
| 老系统兼容 | 闪退风险 | **minSdk 21 + targetSdk 26**（云视听式宽适配） |
| 中文字体 | 需打包 5.7MB 字体 | **系统自带 CJK 字体** |

## UI (v5.3: 借鉴 Kazumi + 云视听小电视)

### 主界面 (借鉴 Kazumi)
- 🧭 **左侧导航栏**：首页 / 追番 / 历史 竖排菜单，方向键上下切换
- 🖼️ **海报墙网格**：首页最新更新、追番目录、搜索结果全部以海报卡片墙展示（封面 + 名称），聚焦放大浮起
- 🔍 顶部搜索框：电视端聚焦即弹输入对话框
- 📋 底部详情面板：选中海报后显示封面 + 简介 + 选集条 + 播放控制

### 播放器 (借鉴云视听小电视)
- 🎬 **顶部渐变标题条** + **底部半透明控制条**（进度条 + 时间 + 按钮行）
- ⏯ **中央大播放/暂停按钮**：暂停时显示，OK 或点击切换
- ▶ 内置 ExoPlayer 硬解，默认 720p 保老电视流畅
- ⏪ 续播记忆 / 画质倍速记忆 / 自动连播 / 自动换源 / 外部播放
- 🌐 **网页版按钮**：播放中一键打开当前番的网页播放搜索页

### 网页版 (v5.3 重做: 性能 + 遥控器鼠标)
- 🖱️ **遥控器虚拟鼠标**（解决网页遥控器无法操作）：
  - 方向键单击 = 移动光标（长按连续移动）
  - **上/下方向键连按两下 = 页面滚动**（上滑/下滑）
  - **OK 单击 = 光标处悬停**，**OK 快速连按两下 = 确认点击**（可点链接/按钮/工具栏）
  - 返回 = 后退一页，再按退出；地址栏聚焦时方向键正常输入
- ⚡ **性能优化**：网页 Activity 单独开启硬件加速（老电视网页卡顿主因是软件渲染）；光标纯 View 定位零开销；滚动一次注入不持续刷新
- 🔥 GeckoView(Firefox 91) 兜底老 WebView(Chromium44)，双引擎自动切换

## 功能

- 🔥 首页：最新更新 + 本周新番（封面图加载），顶部固定「▶ 继续观看」一键续播
- 🔍 搜索：中文番名（海贼王/咒术回战/葬送的芙莉莲...），海报墙结果
- 📺 2026 新番目录（冬/春/夏）
- 🕘 播放历史：OK 恢复进度，长按删除单条
- 🎚️ 可调进度条：触摸拖动 / 遥控器聚焦后 ←→ 调节
- ⏩ 倍速：1.0x → 1.25x → 1.5x → 2.0x → 0.75x → 0.5x，跨集跨会话记忆
- 🎞️ 画质：自适应/1080p/720p/480p/360p，选择自动记忆
- 遥控器全屏操作：OK=控制条、←→=快进/快退15秒、↑↓=音量
- 自动连播、14 条免费线路自动轮换 + 网络错误自动换源
- 错误重试：加载失败后 [OK] 直接重试当前操作

## 构建 APK（GitHub Actions，无需电脑）

1. 把 `ad5.3-java.zip` 上传到仓库（main 分支），确认 `.github/workflows/build.yml` 为最新版（自动兼容任意 `ad5.x-java.zip`）
2. Actions → **Build Java APK** → 等 5~15 分钟
3. 下载 `animetv-tv-apk` 中的 APK 安装到电视

> 本地构建：`gradle assembleDebug`（需 JDK 17）

## 项目结构

```
app/src/main/java/com/animetv/
├── MainActivity.java     # 主界面: 侧边导航 + 海报墙 + 详情/选集/历史
├── PlayerActivity.java   # 播放器 (云视听式控制条 + 续播/画质/倍速记忆)
├── WebPlayActivity.java  # 网页版 (双引擎 + 遥控器虚拟鼠标 + 硬件加速)
├── api/AgeApi.java       # AGE 官方 API 客户端 (纯 Java, OkHttp)
├── model/                # 数据模型
└── util/
    ├── HistoryStore.java # 播放历史 (带进度, 支持删除)
    ├── FocusAnim.java    # 电视焦点缩放/浮起动画
    ├── UIMode.java       # 电视端/手机端模式
    └── DiskCache.java    # API 磁盘缓存
app/src/main/res/         # 布局/主题/焦点样式 (TV 遥控器优化)
.github/workflows/build.yml
```

## 技术备注

- 片源：`api.agedm.io/v2` + `jx.wuzhoupai.com:8443`（2026-08 实测可用）
- 若片源失效：改 `api/AgeApi.java` 顶部的 `API_BASE` / `JX_BASE`
- minSdk 21 / targetSdk 26 / 双 ABI 自动（Gradle 默认）
- 网页版硬件加速独立开启于 `AndroidManifest.xml` 的 WebPlayActivity；若个别电视网页白屏，可改回 `false`
- 焦点动画若嫌大/嫌卡：改 `util/FocusAnim.java` 的 `SCALE`（如 1.03）
