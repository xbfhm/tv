package com.animetv.model;

/** 番剧条目 (搜索/列表结果) */
public class Anime {
    public int id;
    public String name = "";
    public String premiere = "";
    public String status = "";
    public String uptodate = "";
    public String type = "";
    public String cover = "";    // 封面图 URL
    public String display = "";   // 列表展示文本
    public boolean isResume = false;   // 首页"继续观看"占位条目

    public Anime() {}

    public Anime(int id, String name, String premiere, String status, String uptodate) {
        this.id = id;
        this.name = name;
        this.premiere = premiere;
        this.status = status;
        this.uptodate = uptodate;
        this.display = name + "  (" + premiere + " " + status + ")";
    }
}
