package com.animetv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 内置浏览器 v5.3: 网页版番剧源 (WebView/GeckoView 双引擎)
 *
 * 【性能优化】
 * - 本 Activity 在 Manifest 单独开启硬件加速 (老电视软件渲染是卡顿主因)
 * - 虚拟光标用纯 View 定位 (setX/setY, 无动画), 开销可忽略
 * - 滚动用一次触摸滑动注入, 不持续刷新
 *
 * 【遥控器虚拟鼠标模式】 (网页卡顿/无法操作的解决办法)
 * - 方向键单击: 移动光标 (长按连续移动)
 * - 上/下方向键连按两下: 页面滚动 (上滑/下滑)
 * - OK 单击: 光标处悬停 (触发 hover)
 * - OK 快速连按两下: 确认点击 (模拟左键, 可点网页按钮/链接/工具栏)
 * - 返回: 输入框聚焦时先收起, 否则后退一页, 再按退出
 */
public class WebPlayActivity extends Activity {

    private WebView webView;
    private EditText urlBar;
    private String homeUrl = "https://anime7.top/";
    private int chromeVer = 0;                 // 系统 WebView 版本
    private TextView tipBar;                   // 兼容提示条
    private TextView statusBar;                // 加载状态条
    private ProgressBar progressBar;           // 加载进度
    private LinearLayout bar;                  // 工具栏 (供光标点击)
    private int barBottom = 0;                 // 工具栏底部 y (window 坐标)

    // GeckoView (电视老 WebView 兜底)
    private boolean useGecko = false;
    private GeckoRuntime gkRuntime;
    private GeckoSession gkSession;
    private GeckoView gkView;

    // ===== 虚拟鼠标 =====
    private MouseCursorView cursor;
    private int cursorX = -1, cursorY = -1;    // 光标位置 (window 坐标)
    private int step = 0;                      // 移动步进 (px)
    private long lastOkAt = 0;                 // 上次 OK 按下时间 (双击判定)
    private long lastDpadAt = 0;               // 上次方向键时间
    private int lastDpadKey = 0;               // 上次方向键码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String url = getIntent().getStringExtra("url");
        if (url != null && !url.isEmpty()) homeUrl = url;
        step = dp(22);

        // 检测系统 WebView 版本: <60 (电视 2016 Chromium44) 用 GeckoView
        try {
            Matcher m = Pattern.compile("Chrome/(\\d+)")
                    .matcher(new WebView(this).getSettings().getUserAgentString());
            if (m.find()) chromeVer = Integer.parseInt(m.group(1));
            if (chromeVer > 0 && chromeVer < 60) useGecko = true;
        } catch (Exception ignored) {}

        // ===== 根布局 (FrameLayout: 页面 + 光标覆盖层) =====
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#101018"));

        // ===== 页面区 (竖排: 提示条 + 工具栏 + 状态条 + 进度条 + 内容) =====
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(page);

        // 老 WebView 提示条
        if (chromeVer > 0 && chromeVer < 60) {
            tipBar = new TextView(this);
            tipBar.setText("检测到旧版浏览器, 已启用内置 Firefox 内核 (遥控器鼠标模式可用)");
            tipBar.setTextColor(Color.parseColor("#1A1A1A"));
            tipBar.setTextSize(13);
            tipBar.setBackgroundColor(Color.parseColor("#FFD54F"));
            tipBar.setPadding(dp(8), dp(6), dp(8), dp(6));
            page.addView(tipBar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        // ===== 工具栏 =====
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(4), dp(6), dp(4));
        bar.setBackgroundColor(Color.parseColor("#1A1A24"));

        Button btnBack = mkButton("◀", 48);
        Button btnFwd  = mkButton("▶", 48);
        Button btnGo   = mkButton("打开", 64);
        Button btnHome = mkButton("主页", 64);

        urlBar = new EditText(this);
        urlBar.setText(homeUrl);
        urlBar.setTextColor(Color.WHITE);
        urlBar.setTextSize(14);
        urlBar.setSingleLine(true);
        urlBar.setBackgroundColor(Color.parseColor("#232330"));
        urlBar.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams lpBar = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lpBar.setMargins(dp(4), 0, dp(4), 0);
        urlBar.setLayoutParams(lpBar);

        bar.addView(btnBack);
        bar.addView(btnFwd);
        bar.addView(urlBar);
        bar.addView(btnGo);
        bar.addView(btnHome);
        page.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        // ===== 加载状态条 + 进度条 =====
        statusBar = new TextView(this);
        statusBar.setText("就绪 · 方向键=移动光标, 上/下连按=滚动, OK双击=点击");
        statusBar.setTextColor(Color.parseColor("#9AA0B0"));
        statusBar.setTextSize(12);
        statusBar.setPadding(dp(10), dp(2), dp(10), dp(2));
        page.addView(statusBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setMinimumHeight(dp(3));
        page.addView(progressBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        // ===== 内容区 (双引擎) =====
        if (useGecko) {
            initGeckoView(page);
        } else {
            initWebView(page);
        }

        // ===== 底部操作提示条 (半透明, 不挡太多页面) =====
        TextView hint = new TextView(this);
        hint.setText("🖱 遥控器鼠标: 方向键移动 · 上/下连按滚动 · OK单击悬停 · OK双击点击 · 返回=后退");
        hint.setTextColor(Color.parseColor("#CCFFFFFF"));
        hint.setTextSize(12);
        hint.setGravity(Gravity.CENTER);
        hint.setBackgroundColor(Color.parseColor("#99000000"));
        FrameLayout.LayoutParams lpHint = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(30), Gravity.BOTTOM);
        root.addView(hint, lpHint);

        // ===== 虚拟光标 (顶层覆盖) =====
        cursor = new MouseCursorView(this);
        FrameLayout.LayoutParams lpCur = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.START);
        root.addView(cursor, lpCur);

        setContentView(root);
        root.post(() -> {
            cursorX = root.getWidth() / 2 - cursor.getWidth() / 2;
            cursorY = root.getHeight() / 2 - cursor.getHeight() / 2;
            cursor.setX(cursorX);
            cursor.setY(cursorY);
            barBottom = bar.getBottom();
        });

        // ===== 按钮事件 (鼠标模式点击工具栏也能触发) =====
        btnBack.setOnClickListener(v -> {
            if (useGecko) { if (gkSession != null) gkSession.goBack(); }
            else if (webView != null && webView.canGoBack()) webView.goBack();
        });
        btnFwd.setOnClickListener(v -> {
            if (useGecko) { if (gkSession != null) gkSession.goForward(); }
            else if (webView != null && webView.canGoForward()) webView.goForward();
        });
        btnGo.setOnClickListener(v -> {
            String u = urlBar.getText().toString().trim();
            if (u.isEmpty()) { statusBar.setText("请输入网址"); return; }
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
            statusBar.setText("加载中: " + shortUrl(u));
            load(u);
        });
        btnHome.setOnClickListener(v -> {
            statusBar.setText("回主页: " + shortUrl(homeUrl));
            load(homeUrl);
        });

        load(homeUrl);
        hideSystemUi();
    }

    /** 系统 WebView 引擎 (手机等新版 WebView) */
    private void initWebView(LinearLayout root) {
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                urlBar.setText(url);
                statusBar.setText("加载中: " + shortUrl(url));
                progressBar.setProgress(5);
            }
            @Override public void onPageFinished(WebView view, String url) {
                urlBar.setText(url);
                statusBar.setText("✓ 完成: " + shortUrl(url));
                progressBar.setProgress(100);
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                statusBar.setText("加载失败: " + description);
                Toast.makeText(WebPlayActivity.this, "网页加载失败: " + description, Toast.LENGTH_LONG).show();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    /** GeckoView 引擎 (电视老 WebView 兜底, Firefox 91 现代内核) */
    private void initGeckoView(LinearLayout root) {
        try {
            gkRuntime = GeckoRuntime.create(this);
            gkSession = new GeckoSession();
            gkSession.open(gkRuntime);
            gkView = new GeckoView(this);
            gkView.setSession(gkSession);

            gkSession.setProgressDelegate(new GeckoSession.ProgressDelegate() {
                @Override public void onProgressChange(GeckoSession session, int progress) {
                    progressBar.setProgress(progress);
                }
                @Override public void onPageStart(GeckoSession session, String url) {
                    urlBar.setText(url);
                    statusBar.setText("加载中: " + shortUrl(url));
                    progressBar.setProgress(5);
                }
                @Override public void onPageStop(GeckoSession session, boolean success) {
                    statusBar.setText(success ? "✓ 完成" : "加载失败");
                    progressBar.setProgress(100);
                }
            });
            gkSession.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
                @Override public void onLocationChange(GeckoSession session, String url) {
                    urlBar.setText(url);
                }
                @Override public org.mozilla.geckoview.GeckoResult<String> onLoadError(
                        GeckoSession session, String uri, org.mozilla.geckoview.WebRequestError err) {
                    statusBar.setText("加载失败: " + (err != null ? err.getMessage() : "未知"));
                    return null;
                }
            });

            root.addView(gkView, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        } catch (Exception e) {
            useGecko = false;
            initWebView(root);   // 降级: GeckoView 初始化失败用系统 WebView
        }
    }

    /** 统一加载 */
    private void load(String u) {
        if (useGecko) { if (gkSession != null) gkSession.loadUri(u); }
        else if (webView != null) webView.loadUrl(u);
    }

    private Button mkButton(String text, int w) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.parseColor("#2A2A3A"));
        b.setMinHeight(dp(40));
        b.setPadding(dp(8), 0, dp(8), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(w), dp(42));
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private String shortUrl(String u) {
        if (u == null) return "";
        String s = u.replace("https://", "").replace("http://", "");
        return s.length() > 40 ? s.substring(0, 40) + "..." : s;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    // ================= 虚拟鼠标 =================

    /** 当前内容视图 */
    private View content() {
        return useGecko ? gkView : webView;
    }

    private void moveCursor(int dx, int dy) {
        FrameLayout root = (FrameLayout) findViewById(android.R.id.content);
        int w = root != null ? root.getWidth() : 1280;
        int h = root != null ? root.getHeight() : 720;
        cursorX = Math.max(0, Math.min(w - cursor.getWidth(), cursorX + dx));
        cursorY = Math.max(0, Math.min(h - cursor.getHeight(), cursorY + dy));
        cursor.setX(cursorX);
        cursor.setY(cursorY);
    }

    /** OK 单击: 光标处悬停 (触发 hover 效果, 对不支持 hover 的引擎无副作用) */
    private void hoverAt(int x, int y) {
        View t = content();
        if (t == null) return;
        try {
            long now = SystemClock.uptimeMillis();
            int[] loc = new int[2];
            t.getLocationOnScreen(loc);
            MotionEvent me = MotionEvent.obtain(now, now, MotionEvent.ACTION_HOVER_MOVE,
                    x - loc[0], y - loc[1], 0);
            t.dispatchGenericMotionEvent(me);
            me.recycle();
        } catch (Exception ignored) {}
    }

    /** OK 双击: 确认点击 (模拟左键); 光标在工具栏区域时点击工具栏控件 */
    private void clickAt(int x, int y) {
        if (bar != null && y <= barBottom) {
            toolbarClick(x, y);
            return;
        }
        View t = content();
        if (t == null) return;
        long now = SystemClock.uptimeMillis();
        int[] loc = new int[2];
        t.getLocationOnScreen(loc);
        touch(t, now, MotionEvent.ACTION_DOWN, x - loc[0], y - loc[1]);
        touch(t, now + 60, MotionEvent.ACTION_UP, x - loc[0], y - loc[1]);
    }

    /** 光标点击工具栏按钮/地址栏 */
    private void toolbarClick(int x, int y) {
        long now = SystemClock.uptimeMillis();
        for (int i = 0; i < bar.getChildCount(); i++) {
            View v = bar.getChildAt(i);
            int[] loc = new int[2];
            v.getLocationOnScreen(loc);
            if (x >= loc[0] && x <= loc[0] + v.getWidth()
                    && y >= loc[1] && y <= loc[1] + v.getHeight()) {
                touch(v, now, MotionEvent.ACTION_DOWN, x - loc[0], y - loc[1]);
                touch(v, now + 60, MotionEvent.ACTION_UP, x - loc[0], y - loc[1]);
                return;
            }
        }
    }

    /** 页面滚动: 模拟手指滑动 (上/下方向键连按两下触发) */
    private void scrollPage(int dir) {
        View t = content();
        if (t == null) return;
        int w = t.getWidth(), h = t.getHeight();
        if (w <= 0 || h <= 0) return;
        long now = SystemClock.uptimeMillis();
        int dist = dp(180);
        int cx = w / 2, cy = h / 2;
        touch(t, now, MotionEvent.ACTION_DOWN, cx, cy);
        for (int i = 1; i <= 8; i++) {
            touch(t, now + 10L * i, MotionEvent.ACTION_MOVE, cx, cy + dir * dist * i / 8);
        }
        touch(t, now + 100, MotionEvent.ACTION_UP, cx, cy + dir * dist);
    }

    private void touch(View t, long when, int action, float x, float y) {
        try {
            MotionEvent me = MotionEvent.obtain(when, when, action, x, y, 0);
            t.dispatchTouchEvent(me);
            me.recycle();
        } catch (Exception ignored) {}
    }

    // ================= 遥控器按键 (虚拟鼠标模式) =================
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // 输入框聚焦时: 方向键/OK 交给输入框 (遥控器打字)
        if (urlBar.isFocused() && keyCode != KeyEvent.KEYCODE_BACK && keyCode != KeyEvent.KEYCODE_ESCAPE) {
            return super.onKeyDown(keyCode, event);
        }
        long now = SystemClock.uptimeMillis();

        // 方向键: 单击移动光标; 上/下连按两下 = 滚动
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN
                || keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            int dx = 0, dy = 0;
            if (keyCode == KeyEvent.KEYCODE_DPAD_UP) dy = -step;
            else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) dy = step;
            else if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) dx = -step;
            else dx = step;
            // 上/下连按两下 = 滚动 (下滑/上滑)
            if ((keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN)
                    && now - lastDpadAt < 450 && lastDpadKey == keyCode) {
                lastDpadAt = 0;
                lastDpadKey = 0;
                scrollPage(keyCode == KeyEvent.KEYCODE_DPAD_DOWN ? -1 : 1);
                statusBar.setText("🖱 " + (keyCode == KeyEvent.KEYCODE_DPAD_DOWN ? "下滑" : "上滑"));
                return true;
            }
            if (event.getRepeatCount() > 0) {   // 长按连续移动
                moveCursor(dx, dy);
                return true;
            }
            lastDpadAt = now;
            lastDpadKey = keyCode;
            moveCursor(dx, dy);
            return true;
        }

        // OK: 单击=悬停, 双击=确认点击
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            if (event.getRepeatCount() > 0) return true;   // 长按忽略重复
            if (now - lastOkAt < 450) {
                lastOkAt = 0;
                clickAt(cursorX, cursorY);
                statusBar.setText("🖱 点击");
            } else {
                lastOkAt = now;
                hoverAt(cursorX, cursorY);
                statusBar.setText("🖱 悬停 (再按OK=点击)");
            }
            return true;
        }

        // 返回: 输入框聚焦先收起, 否则后退一页, 再按退出
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (urlBar.isFocused()) {
                urlBar.clearFocus();
                return true;
            }
            if (useGecko) {
                if (gkSession != null) gkSession.goBack();
                else finish();
                return true;
            }
            if (webView != null && webView.canGoBack()) {
                webView.goBack();
                return true;
            }
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (gkSession != null) { gkSession.close(); gkSession = null; }
            if (gkRuntime != null) { gkRuntime.shutdown(); gkRuntime = null; }
        } catch (Exception ignored) {}
        if (webView != null) { webView.destroy(); webView = null; }
    }

    /** 虚拟光标: 半透明圆 + 白色十字 (瞄准样式), 纯 Canvas 绘制, 开销极小 */
    class MouseCursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);

        MouseCursorView(android.content.Context c) {
            super(c);
            fill.setColor(0x66000000);
            ring.setColor(0xEEFFFFFF);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(2));
            cross.setColor(0xFFFFFFFF);
            cross.setStrokeWidth(dp(2));
            setFocusable(false);
            setClickable(false);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float r = getWidth() / 2f;
            canvas.drawCircle(r, r, r, fill);
            canvas.drawCircle(r, r, r - 1, ring);
            float d = r * 0.55f;
            canvas.drawLine(r - d, r, r + d, r, cross);
            canvas.drawLine(r, r - d, r, r + d, cross);
        }
    }
}
