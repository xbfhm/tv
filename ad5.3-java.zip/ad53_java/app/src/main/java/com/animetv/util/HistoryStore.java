package com.animetv.util;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 播放历史 (SharedPreferences 持久化) */
public class HistoryStore {
    private static final String PREFS = "animetv";
    private static final String KEY = "history";

    public static class Item {
        public int aid;
        public String name = "";
        public String ep = "";
        public int epIndex;
        public String line = "";
        public long pos = 0;          // 播放进度 (毫秒), 续播用
    }

    private final SharedPreferences sp;

    public HistoryStore(Context ctx) {
        sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized List<Item> load() {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.aid = o.optInt("aid");
                it.name = o.optString("name");
                it.ep = o.optString("ep");
                it.epIndex = o.optInt("epIndex");
                it.line = o.optString("line");
                it.pos = o.optLong("pos");
                if (it.aid > 0) out.add(it);
            }
        } catch (Exception ignored) {}
        return out;
    }

    /** 从头播 (无进度) */
    public synchronized void add(int aid, String name, String ep, int epIndex, String line) {
        add(aid, name, ep, epIndex, line, 0);
    }

    /** 记录历史, 带播放进度 (毫秒) */
    public synchronized void add(int aid, String name, String ep, int epIndex, String line, long pos) {
        try {
            List<Item> list = load();
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).aid == aid) { list.remove(i); break; }
            }
            Item it = new Item();
            it.aid = aid; it.name = name; it.ep = ep; it.epIndex = epIndex; it.line = line; it.pos = pos;
            list.add(0, it);
            while (list.size() > 20) list.remove(list.size() - 1);
            save(list);
        } catch (Exception ignored) {}
    }

    /** 删除一条历史 */
    public synchronized void remove(int aid) {
        try {
            List<Item> list = load();
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).aid == aid) { list.remove(i); break; }
            }
            save(list);
        } catch (Exception ignored) {}
    }

    /** 清空全部历史 */
    public synchronized void clear() {
        save(new ArrayList<Item>());
    }

    private void save(List<Item> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Item x : list) {
                JSONObject o = new JSONObject();
                o.put("aid", x.aid); o.put("name", x.name); o.put("ep", x.ep);
                o.put("epIndex", x.epIndex); o.put("line", x.line); o.put("pos", x.pos);
                arr.put(o);
            }
            sp.edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {}
    }
}
