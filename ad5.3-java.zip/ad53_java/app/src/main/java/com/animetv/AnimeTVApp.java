package com.animetv;

import android.app.Application;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 全局崩溃捕获: 闪退时把堆栈写入文件, 便于排障 */
public class AnimeTVApp extends Application {
    private static String TAG = "AnimeTV";

    /** 启动/崩溃打点: 私有目录+外部目录双写 */
    public static void log(String msg) {
        try {
            String line = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date()) + " " + msg;
            File[] dirs = new File[2];
            try {
                if (app != null) {
                    dirs[0] = app.getFilesDir();
                    try { dirs[1] = app.getExternalFilesDir(null); } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
            if (dirs[0] == null) dirs[0] = new File("/data/data/com.animetv/files");
            for (File dir : dirs) {
                if (dir == null) continue;
                try {
                    dir.mkdirs();
                    File f = new File(dir, "startup.log");
                    try (PrintWriter pw = new PrintWriter(new FileWriter(f, true))) {
                        pw.println(line);
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    public static AnimeTVApp app;

    @Override
    public void onCreate() {
        super.onCreate();
        app = this;
        com.animetv.api.AgeApi.init(this);   // 初始化磁盘缓存
        log("APP onCreate");
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                File[] dirs = new File[]{ getFilesDir(), getExternalFilesDir(null) };
                for (File dir : dirs) {
                    if (dir == null) continue;
                    try {
                        dir.mkdirs();
                        File f = new File(dir, "crash.txt");
                        try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
                            pw.println("===== " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                                    .format(new Date()) + " =====");
                            throwable.printStackTrace(pw);
                        }
                    } catch (Exception ignored) {}
                }
                Log.e("AnimeTV", "CRASH", throwable);
                log("CRASH: " + throwable.toString());
            } catch (Exception ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        });
    }
}
