package com.animetv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import com.animetv.api.AgeApi;
import com.animetv.model.Episode;
import com.animetv.rule.AutoSource;
import com.animetv.rule.PlayUrlSniffer;
import com.animetv.util.HistoryStore;
import com.animetv.util.KeyMap;
import com.animetv.util.Motion;
import com.animetv.util.Prefs;
import com.animetv.util.UIMode;
import com.animetv.util.UrlCache;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 内置播放器 v7 —— 「遥控器优先」的交互模型
 *
 * <pre>
 *  OK / 确定       播放 / 暂停
 *  ← / → 单击      ±5 秒（秒数可在设置里改）
 *  ← / → 长按      连续拖动进度条（按住越久拖得越快，松手定位）
 *  ↑ / ↓           音量 +/-
 *  菜单键(MENU)    唤出「更多功能」：倍速 / 画质 / 线路 / 选集 / 画面比例 / 播放信息
 *  返回            关闭面板 → 收起控制条 → 退出
 * </pre>
 *
 * 所有按键都可在「设置 → 键位设置」里重新绑定（见 {@link KeyMap}）。
 */
public class PlayerActivity extends Activity {

    private static final float[] SPEEDS = {1.0f, 1.25f, 1.5f, 2.0f, 0.75f, 0.5f, 1.75f};

    // 画质预设: [名称, 最大宽, 最大高, 最大码率bps]
    private static final String[][] QUALITY = {
            {"自适应", "100000", "100000", "100000000"},
            {"1080p", "1920", "1080", "8000000"},
            {"720p", "1280", "720", "4000000"},
            {"480p", "854", "480", "1500000"},
            {"360p", "640", "360", "800000"}
    };

    private static final String[] RATIOS = {"适应", "拉伸", "裁剪"};
    private static final int[] RATIO_MODES = {
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    };

    // 防盗链 Referer 候选 (换源时轮换)
    private static final String[] REFERERS = {
            "https://www.agedm.io/",
            "https://jx.wuzhoupai.com:8443/",
            "https://m.agedm.io/"
    };

    private PlayerView playerView;
    private TextView tvFatal;
    private String lastFatal = "";
    private TextView tvNowPlaying, tvPosition, tvDuration, tvCenterPlay, hudText, tvLoading, tvMenuHint;
    private TextView btnPlay, btnPrevEp, btnNextEp, btnSpeed, btnQuality, btnRotate, btnMenu, btnExit, btnTopBack;
    private LinearLayout controlBar, loadingBox, topBar, menuPanel;
    private TextView rowSpeed, rowQuality, rowLine, rowAuto, rowEpisodes, rowRatio, rowStats;
    private TextView tvRowSpeed, tvRowQuality, tvRowLine, tvRowAuto, tvRowEpisodes, tvRowRatio, tvRowStats;
    private SeekBar seekBar;

    private ExoPlayer player;
    private DefaultTrackSelector trackSelector;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final Handler handler = new Handler(Looper.getMainLooper());

    private String url, title, animeName, line, jxZj, jxVip;
    private String source = "AGE";
    private String baseUrl = "";
    private int animeId, epIndex;
    private ArrayList<Episode> episodes;
    private AudioManager audioManager;

    private boolean controlVisible = false;
    private boolean menuOpen = false;
    private boolean seekBarTouching = false;
    private int speedIdx = 0;
    private int qualityIdx = 2;
    private int ratioIdx = 0;

    private long resumePos = 0;
    private boolean resumed = false;
    private String currentTitle = "";
    private String lineLabel = "";

    // ---- 拖动进度条 (长按 ←→) ----
    private boolean scrubbing = false;
    private boolean wasPlayingBeforeScrub = false;
    private long scrubTarget = 0;
    private long lastScrubSeek = 0;
    private long lastSeekPos = -1;      // 上一次单击快进后的目标位置 (长按拖动起点参考)
    private long lastSeekAt = 0;
    private int scrubDir = 0;

    private boolean switchingLine = false;
    // ---- 跨源自动换源 ----
    private final Set<String> autoTried = new HashSet<>();
    private boolean autoSwitching = false;
    private boolean autoTriedOnce = false;
    private int autoFails = 0;
    private String pendingLine = null;   // 指定要用哪条线路重载 (换源/手选线路)
    private boolean retriedDetail = false;

    private final Runnable hideHudRunnable = () -> Motion.fadeOut(hudText, 0);
    private final Runnable hideControlsRunnable = () -> {
        if (!scrubbing && !menuOpen) showControls(false);
    };

    private final Runnable updateProgress = new Runnable() {
        @Override
        public void run() {
            if (player != null && controlVisible && !scrubbing) {
                long durMs = player.getDuration();
                long posMs = player.getCurrentPosition();
                if (durMs > 0) {
                    tvDuration.setText(fmt(durMs / 1000));
                    tvPosition.setText(fmt(posMs / 1000));
                    if (!seekBarTouching) {
                        seekBar.setMax(1000);
                        seekBar.setProgress((int) (posMs * 1000 / durMs));
                    }
                }
            }
            handler.postDelayed(this, 500);
        }
    };

    private static String fmt(long s) {
        if (s < 0) s = 0;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }

    private static String fmtSpeed(float s) {
        if (s == Math.floor(s)) return ((int) s) + ".0x";
        return s + "x";
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            if (UIMode.isTV(this)) {
                setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            } else {
                setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }
        } catch (Exception ignored) {}

        try {
            setContentView(R.layout.activity_player);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

            readIntent();
            bindViews();
            restorePrefs();
            setupTouch();
            setupMenu();

            // 进页面先把标题/进度/按钮亮出来, 绝不出现"纯黑一片"
            showControls(true);
            handler.post(updateProgress);

            // 先让界面完成一帧, 再创建播放器 (老电视上 ExoPlayer 初始化较重)
            handler.postDelayed(this::startPlayback, 80);
            // 看门狗: 12 秒还没起播就给出可读提示, 再等 10 秒自动换源
            handler.postDelayed(watchdog, 12000);
        } catch (Throwable t) {
            fatal("播放页初始化失败\n" + android.util.Log.getStackTraceString(t));
        }
    }

    /** 真正的播放启动 (延迟到首帧之后, 避免界面没画出来就卡住) */
    private void startPlayback() {
        if (isFinishing()) return;
        try {
            initPlayer();
            if (url != null && !url.isEmpty()) {
                playUrl(url);
            } else if (episodes != null && !episodes.isEmpty()) {
                loadEp(epIndex);
            } else {
                fatal("没有收到播放地址\n请返回重新选择集数");
            }
        } catch (Throwable t) {
            fatal("播放器启动失败\n" + android.util.Log.getStackTraceString(t));
        }
    }

    /** 把错误直接画在屏幕上 (而不是只弹一个 3 秒 Toast), 并且保证能返回 */
    private void fatal(String msg) {
        try {
            lastFatal = msg;
            if (tvFatal != null) {
                tvFatal.setText(msg + "\n\n按「返回」退出 · 按「菜单」换源");
                if (tvFatal.getVisibility() != View.VISIBLE) Motion.fadeIn(tvFatal, 0);
                else tvFatal.setText(msg + "\n\n按「返回」退出 · 按「菜单」换源");
            }
            showLoading(false, null);
            showControls(true);
            Prefs.diag(this, Prefs.K_LAST_ERROR, msg);
            android.util.Log.e("AnimeTV", "PLAYER FATAL: " + msg);
        } catch (Throwable ignored) {}
    }

    private void hideFatal() {
        try {
            if (tvFatal != null && tvFatal.getVisibility() == View.VISIBLE) {
                Motion.fadeOut(tvFatal, 0);
            }
        } catch (Throwable ignored) {}
    }

    private String shortUrl() {
        if (url == null) return "-";
        return url.length() > 90 ? url.substring(0, 90) + "…" : url;
    }

    /** 12 秒看门狗: 起播太慢/失败时给提示, 再等 10 秒直接换源 */
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            try {
                if (isFinishing()) return;
                int st = player == null ? Player.STATE_IDLE : player.getPlaybackState();
                if (st == Player.STATE_READY) return;
                fatal("还没能开始播放\n状态: " + stateName(st) + "\n地址: " + shortUrl()
                        + "\n\n10 秒后自动换源, 也可按「菜单」手动换");
                handler.postDelayed(() -> {
                    try {
                        if (player != null && player.getPlaybackState() == Player.STATE_READY) return;
                        if (!autoSwitching) tryAutoSource(false);
                    } catch (Throwable ignored) {}
                }, 10000);
            } catch (Throwable ignored) {}
        }
    };

    private static String stateName(int st) {
        switch (st) {
            case Player.STATE_IDLE: return "IDLE(未开始)";
            case Player.STATE_BUFFERING: return "BUFFERING(缓冲中)";
            case Player.STATE_READY: return "READY(已就绪)";
            case Player.STATE_ENDED: return "ENDED(播完)";
            default: return String.valueOf(st);
        }
    }

    // ==================== 返回键 (最高优先级, 永远能退) ====================

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK
                || event.getKeyCode() == KeyEvent.KEYCODE_ESCAPE) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                if (menuOpen) {
                    closeMenu();
                } else {
                    exitPlayer();
                }
            }
            return true;   // 消费掉, 不让系统/其它控件再折腾
        }
        return super.dispatchKeyEvent(event);
    }

    private void exitPlayer() {
        try { saveProgress(); } catch (Throwable ignored) {}
        try {
            if (player != null) player.pause();
        } catch (Throwable ignored) {}
        finish();
    }

    @SuppressWarnings("unchecked")
    private void readIntent() {
        Intent it = getIntent();
        url = it.getStringExtra("url");
        title = it.getStringExtra("title");
        animeId = it.getIntExtra("animeId", 0);
        epIndex = it.getIntExtra("epIndex", 0);
        line = it.getStringExtra("line");
        episodes = (ArrayList<Episode>) it.getSerializableExtra("episodes");
        animeName = it.getStringExtra("animeName");
        jxZj = it.getStringExtra("jxZj");
        jxVip = it.getStringExtra("jxVip");
        lineLabel = it.getStringExtra("lineLabel");
        source = it.getStringExtra("source");
        baseUrl = it.getStringExtra("baseUrl");
        if (source == null) source = "AGE";
        if (baseUrl == null) baseUrl = "";
        if (lineLabel == null) lineLabel = "";
        resumePos = it.getLongExtra("resumePos", 0);
        if (episodes == null) episodes = new ArrayList<>();
        if (jxZj == null) jxZj = "https://jx.wuzhoupai.com:8443/m3u8/?url=";
        if (jxVip == null) jxVip = "https://jx.wuzhoupai.com:8443/vip/?url=";
        if (epIndex >= 0 && epIndex < episodes.size()) currentTitle = episodes.get(epIndex).title;
        if (currentTitle == null) currentTitle = "";
    }

    private void bindViews() {
        playerView = findViewById(R.id.playerView);
        tvNowPlaying = findViewById(R.id.tvNowPlaying);
        tvPosition = findViewById(R.id.tvPosition);
        tvDuration = findViewById(R.id.tvDuration);
        tvCenterPlay = findViewById(R.id.tvCenterPlay);
        hudText = findViewById(R.id.hudText);
        tvFatal = findViewById(R.id.tvFatal);
        tvLoading = findViewById(R.id.tvLoading);
        tvMenuHint = findViewById(R.id.tvMenuHint);
        controlBar = findViewById(R.id.controlBar);
        loadingBox = findViewById(R.id.loadingBox);
        topBar = findViewById(R.id.topBar);
        menuPanel = findViewById(R.id.menuPanel);
        seekBar = findViewById(R.id.seekBar);

        btnPlay = findViewById(R.id.btnPlay);
        btnPrevEp = findViewById(R.id.btnPrevEp);
        btnNextEp = findViewById(R.id.btnNextEp);
        btnSpeed = findViewById(R.id.btnSpeed);
        btnQuality = findViewById(R.id.btnQuality);
        btnRotate = findViewById(R.id.btnRotate);
        btnMenu = findViewById(R.id.btnMenu);
        btnExit = findViewById(R.id.btnExit);
        btnTopBack = findViewById(R.id.btnTopBack);

        rowSpeed = findViewById(R.id.rowSpeed);
        rowQuality = findViewById(R.id.rowQuality);
        rowLine = findViewById(R.id.rowLine);
        rowAuto = findViewById(R.id.rowAuto);
        rowEpisodes = findViewById(R.id.rowEpisodes);
        rowRatio = findViewById(R.id.rowRatio);
        rowStats = findViewById(R.id.rowStats);
        tvRowSpeed = findViewById(R.id.tvRowSpeed);
        tvRowQuality = findViewById(R.id.tvRowQuality);
        tvRowLine = findViewById(R.id.tvRowLine);
        tvRowAuto = findViewById(R.id.tvRowAuto);
        tvRowEpisodes = findViewById(R.id.tvRowEpisodes);
        tvRowRatio = findViewById(R.id.tvRowRatio);
        tvRowStats = findViewById(R.id.tvRowStats);

        if (title != null) tvNowPlaying.setText(title);
        else if (animeName != null) tvNowPlaying.setText(animeName);

        btnPlay.setOnClickListener(v -> togglePlay());
        btnPrevEp.setOnClickListener(v -> loadEp(epIndex - 1));
        btnNextEp.setOnClickListener(v -> loadEp(epIndex + 1));
        btnSpeed.setOnClickListener(v -> cycleSpeed());
        btnQuality.setOnClickListener(v -> cycleQuality());
        btnMenu.setOnClickListener(v -> openMenu());
        btnExit.setOnClickListener(v -> finish());
        btnTopBack.setOnClickListener(v -> finish());
        tvCenterPlay.setOnClickListener(v -> togglePlay());

        if (btnRotate != null) {
            if (UIMode.isTV(this)) {
                btnRotate.setVisibility(View.GONE);
            } else {
                btnRotate.setOnClickListener(v -> toggleRotate());
            }
        }

        // 进度条: 触屏拖动 (遥控器走 ←→ 逻辑, 不需要聚焦)
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && player != null) {
                    long dur = player.getDuration();
                    if (dur > 0) {
                        long target = dur * progress / 1000L;
                        player.seekTo(target);
                        tvPosition.setText(fmt(target / 1000));
                    }
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {
                seekBarTouching = true;
                handler.removeCallbacks(hideControlsRunnable);
            }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                seekBarTouching = false;
                scheduleHideControls();
            }
        });
    }

    private void restorePrefs() {
        qualityIdx = Math.max(0, Math.min(QUALITY.length - 1, Prefs.getInt(this, Prefs.K_QUALITY, 2)));
        speedIdx = Math.max(0, Math.min(SPEEDS.length - 1, Prefs.getInt(this, Prefs.K_SPEED, 0)));
        ratioIdx = Math.max(0, Math.min(RATIOS.length - 1, Prefs.getInt(this, Prefs.K_RATIO, 0)));
    }

    private void setupTouch() {
        playerView.setOnClickListener(v -> {
            if (menuOpen) closeMenu();
            else toggleControls();
        });
        findViewById(android.R.id.content).setOnClickListener(v -> {
            if (menuOpen) closeMenu();
            else toggleControls();
        });
    }

    // ==================== 播放器初始化 ====================

    private TrackSelectionParameters qualityParams(DefaultTrackSelector ts) {
        String[] q = QUALITY[qualityIdx];
        return ts.buildUponParameters()
                .setMaxVideoSize(Integer.parseInt(q[1]), Integer.parseInt(q[2]))
                .setMaxVideoBitrate(Integer.parseInt(q[3]))
                .build();
    }

    private void initPlayer() {
        trackSelector = new DefaultTrackSelector(this);
        trackSelector.setParameters(qualityParams(trackSelector));

        Map<String, String> headers = new HashMap<>();
        headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 7.0; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0 Mobile Safari/537.36");
        headers.put("Referer", REFERERS[0]);

        OkHttpDataSource.Factory dataSourceFactory =
                new OkHttpDataSource.Factory(AgeApi.getClient()).setDefaultRequestProperties(headers);

        // 起播缓冲可在设置里调: 默认 900ms 起播, 缓冲池 20s/60s (老电视网络抖动更稳)
        int startMs = Prefs.bufferForPlayback(this);
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(20000, 60000, startMs, Math.max(2000, startMs + 1200))
                .build();

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSourceFactory))
                .setTrackSelector(trackSelector)
                .setLoadControl(loadControl)
                .build();

        playerView.setUseController(false);
        playerView.setPlayer(player);
        applyRatio();

        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    showLoading(true, "正在缓冲…");
                } else {
                    showLoading(false, null);
                }
                updateCenterPlay();
                if (state == Player.STATE_READY) {
                    hideFatal();
                    handler.removeCallbacks(watchdog);
                    // 跨集保持倍速
                    try { player.setPlaybackSpeed(SPEEDS[speedIdx]); } catch (Exception ignored) {}
                    if (!resumed && resumePos > 0) {
                        resumed = true;
                        try { player.seekTo(resumePos); } catch (Exception ignored) {}
                    }
                }
                if (state == Player.STATE_ENDED) {
                    if (Prefs.getBool(PlayerActivity.this, Prefs.K_AUTO_NEXT, true)) {
                        Toast.makeText(PlayerActivity.this, "本集播完，自动下一集", Toast.LENGTH_SHORT).show();
                        loadEp(epIndex + 1);
                    } else {
                        showControls(true);
                    }
                }
            }

            @Override public void onPlayerError(PlaybackException e) {
                showLoading(false, null);
                android.util.Log.e("AnimeTV", "PlayError code=" + e.errorCode + " line=" + line
                        + " url=" + (url != null ? url : ""));
                fatal("播放失败\n错误: " + e.getErrorCodeName() + " (" + e.errorCode + ")\n"
                        + "线路: " + (lineLabel == null ? "-" : lineLabel) + "\n地址: " + shortUrl());
                boolean networkErr = e.errorCode >= 1000 && e.errorCode < 2000;
                if (networkErr && !switchingLine) {
                    Toast.makeText(PlayerActivity.this, "网络异常，自动切换线路…", Toast.LENGTH_SHORT).show();
                    switchLineAuto();
                } else if (!autoSwitching) {
                    // 线路都试过了还不行 → 直接换其他片源
                    Toast.makeText(PlayerActivity.this, "该片源无法播放，正在换源…", Toast.LENGTH_SHORT).show();
                    tryAutoSource(false);
                }
            }

            @Override public void onIsPlayingChanged(boolean isPlaying) {
                updateCenterPlay();
                if (controlVisible) updatePlayButtons();
            }
        });
    }

    private void applyRatio() {
        try {
            playerView.setResizeMode(RATIO_MODES[ratioIdx]);
        } catch (Exception ignored) {}
    }

    private void playUrl(String u) {
        if (u == null || u.isEmpty()) return;
        try {
            MediaItem item = MediaItem.fromUri(Uri.parse(u));
            player.setMediaItem(item);
            player.setPlaybackSpeed(SPEEDS[speedIdx]);
            player.prepare();
            player.play();
            updateCenterPlay();
        } catch (Exception e) {
            Toast.makeText(this, "播放失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ==================== 控制条 ====================

    private void toggleControls() {
        showControls(!controlVisible);
    }

    private void showControls(boolean show) {
        if (show == controlVisible) {
            if (show) scheduleHideControls();
            return;
        }
        controlVisible = show;
        handler.removeCallbacks(hideControlsRunnable);

        if (show) {
            controlBar.setVisibility(View.VISIBLE);
            controlBar.animate().cancel();
            controlBar.setTranslationY(dp(28));
            controlBar.setAlpha(0f);
            controlBar.animate().translationY(0f).alpha(1f).setDuration(200).start();

            topBar.setVisibility(View.VISIBLE);
            topBar.animate().cancel();
            topBar.setTranslationY(dp(-20));
            topBar.setAlpha(0f);
            topBar.animate().translationY(0f).alpha(1f).setDuration(200).start();

            updatePlayButtons();
            scheduleHideControls();
        } else {
            controlBar.animate().cancel();
            controlBar.animate().translationY(dp(28)).alpha(0f).setDuration(160)
                    .withEndAction(() -> controlBar.setVisibility(View.GONE)).start();
            topBar.animate().cancel();
            topBar.animate().translationY(dp(-20)).alpha(0f).setDuration(160)
                    .withEndAction(() -> topBar.setVisibility(View.GONE)).start();
        }
        updateCenterPlay();
    }

    private void scheduleHideControls() {
        handler.removeCallbacks(hideControlsRunnable);
        int sec = Prefs.getInt(this, Prefs.K_HIDE_CONTROLS, 4);
        if (sec <= 0) return;   // 0 = 不自动隐藏
        handler.postDelayed(hideControlsRunnable, sec * 1000L);
    }

    private void updatePlayButtons() {
        boolean playing = player != null && player.isPlaying();
        btnPlay.setText(playing ? "❚❚ 暂停" : "▶ 播放");
        tvCenterPlay.setText("▶");
    }

    /** 中央大按钮: 只在"已就绪且暂停"时显示, 播放中/缓冲中不挡画面 */
    private void updateCenterPlay() {
        if (tvCenterPlay == null) return;
        int state = player != null ? player.getPlaybackState() : Player.STATE_IDLE;
        boolean show = player != null && state == Player.STATE_READY && !player.isPlaying() && !menuOpen;
        if (show) {
            if (tvCenterPlay.getVisibility() != View.VISIBLE) Motion.popIn(tvCenterPlay);
        } else {
            if (tvCenterPlay.getVisibility() == View.VISIBLE) {
                tvCenterPlay.setVisibility(View.GONE);
            }
        }
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.isPlaying()) player.pause(); else {
            if (player.getPlaybackState() == Player.STATE_ENDED) player.seekTo(0);
            player.play();
        }
        updatePlayButtons();
        updateCenterPlay();
        showHud(player.isPlaying() ? "▶ 播放" : "❚❚ 暂停");
        // 只在控制条本来就显示时重置隐藏计时, 不强行弹出控制条
        if (controlVisible) scheduleHideControls();
    }

    private void showLoading(boolean show, String text) {
        if (loadingBox == null) return;
        if (show) {
            if (text != null && tvLoading != null) tvLoading.setText(text);
            if (loadingBox.getVisibility() != View.VISIBLE) Motion.fadeIn(loadingBox, 0);
        } else {
            if (loadingBox.getVisibility() == View.VISIBLE) Motion.fadeOut(loadingBox, 0);
        }
    }

    private void showHud(String text) {
        if (hudText == null || text == null) return;
        handler.removeCallbacks(hideHudRunnable);
        hudText.setText(text);
        if (hudText.getVisibility() != View.VISIBLE) Motion.popIn(hudText);
        else Motion.bump(hudText);
        handler.postDelayed(hideHudRunnable, 1200);
    }

    // ==================== 按键: 单击 5 秒 / 长按拖动 ====================

    private long safeDuration() {
        long d = 0;
        try { d = player != null ? player.getDuration() : 0; } catch (Exception ignored) {}
        return d > 0 ? d : Long.MAX_VALUE / 4;
    }

    private long clampPos(long pos) {
        if (pos < 0) return 0;
        long dur = safeDuration();
        return Math.min(pos, dur);
    }

    private void doSingleSeek(int dir) {
        if (player == null) return;
        int step = Prefs.seekStep(this);
        long cur = player.getCurrentPosition();
        long target = clampPos(cur + dir * step * 1000L);
        player.seekTo(target);
        lastSeekPos = target;
        lastSeekAt = System.currentTimeMillis();
        showHud((dir > 0 ? "⏩ 快进 " : "⏪ 快退 ") + step + " 秒\n"
                + fmt(target / 1000) + " / " + fmt(safeDuration() / 1000));
        if (!controlVisible) showControls(true);
        else {
            // 立即刷新进度条, 不等 500ms 轮询
            long dur = safeDuration();
            if (dur > 0) {
                seekBar.setProgress((int) (target * 1000 / dur));
                tvPosition.setText(fmt(target / 1000));
            }
            scheduleHideControls();
        }
    }

    private void beginScrub(int dir) {
        if (player == null) return;
        scrubbing = true;
        scrubDir = dir;
        wasPlayingBeforeScrub = player.isPlaying();
        scrubTarget = player.getCurrentPosition();
        // 刚单击过快进时 seek 可能还没生效, 以刚设置的目标为拖动起点, 避免"往回跳"
        if (lastSeekPos >= 0 && System.currentTimeMillis() - lastSeekAt < 1500) {
            scrubTarget = lastSeekPos;
        }
        lastScrubSeek = 0;
        if (wasPlayingBeforeScrub) player.pause();
        if (!controlVisible) showControls(true);
        handler.removeCallbacks(hideControlsRunnable);
        showHud((dir > 0 ? "⏩ 拖动中" : "⏪ 拖动中") + "\n" + fmt(scrubTarget / 1000));
    }

    private void stepScrub(int dir, int repeatCount) {
        if (!scrubbing) beginScrub(dir);
        // 按住越久单步越大: 1s → 最多 10s, 老电视也不会"飞过头"
        float factor = Prefs.scrubFactor(this);
        long addMs = (long) (1000 * factor * (1 + Math.min(9, repeatCount / 6)));
        scrubTarget = clampPos(scrubTarget + dir * addMs);
        updateScrubUi();
        long now = System.currentTimeMillis();
        if (now - lastScrubSeek > 220 || lastScrubSeek == 0) {
            lastScrubSeek = now;
            try { player.seekTo(scrubTarget); } catch (Exception ignored) {}
        }
    }

    private void updateScrubUi() {
        long dur = safeDuration();
        if (dur > 0) {
            seekBar.setProgress((int) (scrubTarget * 1000 / dur));
            tvPosition.setText(fmt(scrubTarget / 1000));
        }
        hudText.setText((scrubDir > 0 ? "⏩ " : "⏪ ") + fmt(scrubTarget / 1000)
                + " / " + fmt(dur / 1000));
        hudText.setVisibility(View.VISIBLE);
        hudText.setAlpha(1f);
    }

    private void endScrub() {
        if (!scrubbing) return;
        scrubbing = false;
        try {
            player.seekTo(scrubTarget);
            if (wasPlayingBeforeScrub) player.play();
        } catch (Exception ignored) {}
        handler.removeCallbacks(hideHudRunnable);
        handler.postDelayed(hideHudRunnable, 700);
        scheduleHideControls();
    }

    private void adjustVolume(int dir) {
        if (audioManager != null) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir,
                    AudioManager.FLAG_SHOW_UI);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // ---- 面板打开时: 方向键在面板内导航, 返回关闭 ----
        if (menuOpen) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                closeMenu();
                return true;
            }
            return super.onKeyDown(keyCode, event);
        }

        // ---- 返回: 直接退出 (dispatchKeyEvent 已优先处理) ----
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            exitPlayer();
            return true;
        }

        int keyPlay = KeyMap.get(this, KeyMap.A_PLAY);
        int keyMenu = KeyMap.get(this, KeyMap.A_MENU);
        int keyFwd = KeyMap.get(this, KeyMap.A_FORWARD);
        int keyRew = KeyMap.get(this, KeyMap.A_REWIND);
        int keyVolUp = KeyMap.get(this, KeyMap.A_VOL_UP);
        int keyVolDown = KeyMap.get(this, KeyMap.A_VOL_DOWN);
        int keyNext = KeyMap.get(this, KeyMap.A_NEXT_EP);
        int keyPrev = KeyMap.get(this, KeyMap.A_PREV_EP);

        // OK / 确定 / 媒体播放键 = 播放暂停; 长按 OK = 打开更多功能 (没有菜单键的遥控器也能用)
        if (keyCode == keyPlay || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY) {
            if (event.getRepeatCount() > 0) {
                if (event.getRepeatCount() >= 2) openMenu();
                return true;
            }
            togglePlay();
            return true;
        }

        // 菜单键 = 更多功能 (兼容 设置键 / 信息键, 有些电视遥控器没有 MENU)
        if (keyCode == keyMenu || keyCode == KeyEvent.KEYCODE_MENU
                || keyCode == KeyEvent.KEYCODE_SETTINGS
                || keyCode == KeyEvent.KEYCODE_INFO) {
            openMenu();
            return true;
        }

        // ← / →: 单击 ±N 秒, 长按连续拖动
        if (keyCode == keyFwd || keyCode == keyRew) {
            int dir = (keyCode == keyFwd) ? 1 : -1;
            if (event.getRepeatCount() == 0) {
                // 如果之前还在拖, 先落定
                if (scrubbing) endScrub();
                doSingleSeek(dir);
            } else {
                stepScrub(dir, event.getRepeatCount());
            }
            return true;
        }

        if (keyCode == keyVolUp) {
            adjustVolume(AudioManager.ADJUST_RAISE);
            showHud("音量 +");
            return true;
        }
        if (keyCode == keyVolDown) {
            adjustVolume(AudioManager.ADJUST_LOWER);
            showHud("音量 -");
            return true;
        }
        if (keyCode == keyNext) {
            loadEp(epIndex + 1);
            return true;
        }
        if (keyCode == keyPrev) {
            loadEp(epIndex - 1);
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) {
            if (event.getRepeatCount() == 0) doSingleSeek(1); else stepScrub(1, event.getRepeatCount());
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MEDIA_REWIND) {
            if (event.getRepeatCount() == 0) doSingleSeek(-1); else stepScrub(-1, event.getRepeatCount());
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (scrubbing) {
            int keyFwd = KeyMap.get(this, KeyMap.A_FORWARD);
            int keyRew = KeyMap.get(this, KeyMap.A_REWIND);
            if (keyCode == keyFwd || keyCode == keyRew
                    || keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
                    || keyCode == KeyEvent.KEYCODE_MEDIA_REWIND) {
                endScrub();
                return true;
            }
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    private void hideSystemUi() {
        try {
            // 只做全屏, 不使用 IMMERSIVE_STICKY/HIDE_NAVIGATION:
            // 某些 Android 5.x 电视会把第一次 BACK 吞掉用于"显示导航栏"
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } catch (Exception ignored) {}
    }

    // ==================== 「更多功能」面板 ====================

    private void setupMenu() {
        bindRow(rowSpeed, this::showSpeedDialog);
        bindRow(rowQuality, this::showQualityDialog);
        bindRow(rowLine, this::showLineDialog);
        bindRow(rowAuto, () -> tryAutoSource(true));
        bindRow(rowEpisodes, this::showEpisodeDialog);
        bindRow(rowRatio, this::showRatioDialog);
        bindRow(rowStats, this::showStatsDialog);
    }

    /** 绑定面板行: 控件缺失也不会崩 (老版本布局兼容) */
    private void bindRow(View row, Runnable action) {
        if (row == null) return;
        row.setOnClickListener(v -> {
            try { action.run(); } catch (Throwable ignored) {}
        });
        row.setOnFocusChangeListener((v, has) -> {
            com.animetv.util.FocusAnim.scale(v, has);
            v.setSelected(has);
        });
    }

    private void openMenu() {
        if (menuOpen) return;
        if (scrubbing) endScrub();
        menuOpen = true;
        handler.removeCallbacks(hideControlsRunnable);
        showControls(false);
        tvCenterPlay.setVisibility(View.GONE);
        refreshMenuValues();
        Motion.slideInRight(menuPanel, dp(280));
        if (rowSpeed != null) rowSpeed.requestFocus();
    }

    private void closeMenu() {
        if (!menuOpen) return;
        menuOpen = false;
        Motion.slideOutRight(menuPanel, dp(280));
        try {
            rowSpeed.clearFocus();
            getWindow().getDecorView().requestFocus();
        } catch (Exception ignored) {}
        updateCenterPlay();
        scheduleHideControls();
    }

    private void refreshMenuValues() {
        tvRowSpeed.setText(fmtSpeed(SPEEDS[speedIdx]));
        tvRowQuality.setText(QUALITY[qualityIdx][0]);
        tvRowLine.setText(lineLabel == null || lineLabel.isEmpty() ? "-" : lineLabel);
        if (tvRowAuto != null) tvRowAuto.setText(autoTriedOnce ? "继续找" : "其他片源");
        Episode cur = currentEpisode();
        tvRowEpisodes.setText(cur == null ? "-" : cur.title);
        tvRowRatio.setText(RATIOS[ratioIdx]);
        tvRowStats.setText("查看");
    }

    private Episode currentEpisode() {
        if (episodes == null || epIndex < 0 || epIndex >= episodes.size()) return null;
        return episodes.get(epIndex);
    }

    private void showSpeedDialog() {
        final String[] items = new String[SPEEDS.length];
        int checked = speedIdx;
        for (int i = 0; i < SPEEDS.length; i++) {
            items[i] = fmtSpeed(SPEEDS[i]) + (i == speedIdx ? "  ✓" : "");
        }
        final int cur = checked;
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("播放倍速")
                .setSingleChoiceItems(items, cur, (dialog, which) -> {
                    speedIdx = which;
                    applySpeed(true);
                    dialog.dismiss();
                })
                .setNegativeButton("取消", null)
                .create();
        d.setOnDismissListener(x -> {
            refreshMenuValues();
            if (menuOpen && rowSpeed != null) rowSpeed.requestFocus();
        });
        d.show();
    }

    private void showQualityDialog() {
        final String[] items = new String[QUALITY.length];
        for (int i = 0; i < QUALITY.length; i++) {
            items[i] = QUALITY[i][0] + (i == qualityIdx ? "  ✓" : "");
        }
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("画质")
                .setSingleChoiceItems(items, qualityIdx, (dialog, which) -> {
                    qualityIdx = which;
                    trackSelector.setParameters(qualityParams(trackSelector));
                    Prefs.setInt(this, Prefs.K_QUALITY, qualityIdx);
                    if (btnQuality != null) btnQuality.setText(QUALITY[qualityIdx][0]);
                    dialog.dismiss();
                    showHud("画质: " + QUALITY[qualityIdx][0]);
                })
                .setNegativeButton("取消", null)
                .create();
        d.setOnDismissListener(x -> {
            refreshMenuValues();
            if (menuOpen && rowQuality != null) rowQuality.requestFocus();
        });
        d.show();
    }

    private void showLineDialog() {
        if (episodes == null || episodes.isEmpty()) {
            Toast.makeText(this, "当前没有其他线路", Toast.LENGTH_SHORT).show();
            return;
        }
        final List<String> lines = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        for (Episode e : episodes) {
            if (!lines.contains(e.line)) {
                lines.add(e.line);
                labels.add(e.lineLabel);
            }
        }
        if (lines.size() <= 1) {
            Toast.makeText(this, "当前只有一条线路", Toast.LENGTH_SHORT).show();
            return;
        }
        final String[] items = labels.toArray(new String[0]);
        int cur = Math.max(0, lines.indexOf(line));
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("切换线路")
                .setSingleChoiceItems(items, cur, (dialog, which) -> {
                    pendingLine = lines.get(which);
                    lineLabel = labels.get(which);
                    dialog.dismiss();
                    loadEp(epIndex);
                })
                .setNegativeButton("取消", null)
                .create();
        d.setOnDismissListener(x -> {
            refreshMenuValues();
            if (menuOpen && rowLine != null) rowLine.requestFocus();
        });
        d.show();
    }

    private void showEpisodeDialog() {
        if (episodes == null || episodes.isEmpty()) {
            Toast.makeText(this, "没有可选的集数", Toast.LENGTH_SHORT).show();
            return;
        }
        final String[] items = new String[episodes.size()];
        for (int i = 0; i < episodes.size(); i++) {
            items[i] = episodes.get(i).title;
        }
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("选集 (" + episodes.size() + " 集)")
                .setSingleChoiceItems(items, Math.max(0, Math.min(epIndex, items.length - 1)),
                        (dialog, which) -> {
                            dialog.dismiss();
                            loadEp(which);
                        })
                .setNegativeButton("取消", null)
                .create();
        d.setOnDismissListener(x -> {
            refreshMenuValues();
            if (menuOpen && rowEpisodes != null) rowEpisodes.requestFocus();
        });
        d.show();
    }

    private void showRatioDialog() {
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("画面比例")
                .setSingleChoiceItems(RATIOS, ratioIdx, (dialog, which) -> {
                    ratioIdx = which;
                    applyRatio();
                    Prefs.setInt(this, Prefs.K_RATIO, ratioIdx);
                    dialog.dismiss();
                    showHud("画面: " + RATIOS[ratioIdx]);
                })
                .setNegativeButton("取消", null)
                .create();
        d.setOnDismissListener(x -> {
            refreshMenuValues();
            if (menuOpen && rowRatio != null) rowRatio.requestFocus();
        });
        d.show();
    }

    private void showStatsDialog() {
        StringBuilder sb = new StringBuilder();
        try {
            sb.append("来源: ").append(source).append('\n');
            sb.append("线路: ").append(lineLabel == null || lineLabel.isEmpty() ? "-" : lineLabel).append('\n');
            sb.append("集数: ").append(currentTitle).append('\n');
            if (player != null) {
                sb.append("缓冲: ").append(player.getBufferedPosition() / 1000).append(" 秒\n");
                sb.append("倍速: ").append(fmtSpeed(SPEEDS[speedIdx])).append('\n');
                sb.append("码率上限: ").append(QUALITY[qualityIdx][0]).append('\n');
                if (player instanceof ExoPlayer) {
                    Format vf = ((ExoPlayer) player).getVideoFormat();
                    if (vf != null) {
                        sb.append("视频: ").append(vf.width).append('x').append(vf.height);
                        if (vf.bitrate > 0) sb.append("  ").append(vf.bitrate / 1000).append("kbps");
                        sb.append('\n');
                        if (vf.codecs != null) sb.append("编码: ").append(vf.codecs).append('\n');
                    }
                }
            }
        } catch (Exception e) {
            sb.append("读取失败: ").append(e.getMessage());
        }
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("播放信息")
                .setMessage(sb.toString())
                .setPositiveButton("好", null)
                .create();
        d.setOnDismissListener(x -> {
            if (menuOpen && rowStats != null) rowStats.requestFocus();
        });
        d.show();
    }

    // ==================== 倍速 / 画质 / 旋转 ====================

    private void cycleSpeed() {
        speedIdx = (speedIdx + 1) % SPEEDS.length;
        applySpeed(true);
    }

    private void applySpeed(boolean toast) {
        try {
            player.setPlaybackSpeed(SPEEDS[speedIdx]);
        } catch (Exception ignored) {}
        Prefs.setInt(this, Prefs.K_SPEED, speedIdx);
        if (btnSpeed != null) btnSpeed.setText(fmtSpeed(SPEEDS[speedIdx]));
        if (toast) showHud("倍速 " + fmtSpeed(SPEEDS[speedIdx]));
        refreshMenuValues();
        if (btnSpeed != null) Motion.bump(btnSpeed);
    }

    private void cycleQuality() {
        qualityIdx = (qualityIdx + 1) % QUALITY.length;
        trackSelector.setParameters(qualityParams(trackSelector));
        Prefs.setInt(this, Prefs.K_QUALITY, qualityIdx);
        if (btnQuality != null) btnQuality.setText(QUALITY[qualityIdx][0]);
        showHud("画质: " + QUALITY[qualityIdx][0]);
        refreshMenuValues();
    }

    private void toggleRotate() {
        try {
            int cur = getRequestedOrientation();
            setRequestedOrientation(cur == android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } catch (Exception ignored) {}
    }

    // ==================== 选集 / 解析 ====================

    private void loadEp(int i) {
        if (episodes == null || episodes.isEmpty()) {
            Toast.makeText(this, "没有可播放的集数", Toast.LENGTH_SHORT).show();
            return;
        }
        if (i < 0) {
            Toast.makeText(this, "已经是第一集", Toast.LENGTH_SHORT).show();
            return;
        }
        if (i >= episodes.size()) {
            Toast.makeText(this, "已经是最后一集", Toast.LENGTH_SHORT).show();
            return;
        }
        final int idx = i;
        final Episode cur = episodes.get(idx);
        retriedDetail = false;
        epIndex = idx;
        currentTitle = cur.title;
        if (pendingLine != null) {
            // 换源/手选线路: 用指定线路, 并同步线路显示名
            line = pendingLine;
            pendingLine = null;
            for (Episode e : episodes) {
                if (line.equals(e.line)) {
                    lineLabel = e.lineLabel;
                    break;
                }
            }
        } else {
            line = cur.line;
            lineLabel = cur.lineLabel;
        }
        tvNowPlaying.setText(animeName + " " + cur.title + "  解析中…");
        showLoading(true, "正在解析 " + cur.title + " …");

        final String cachedUrl = UrlCache.get(keyOf(cur));
        if (cachedUrl != null) {
            // 命中预解析缓存: 秒开
            url = cachedUrl;
            showLoading(false, null);
            tvNowPlaying.setText(animeName + " " + cur.title + " [" + cur.lineLabel + "]");
            playUrl(cachedUrl);
            saveHistory();
            return;
        }

        pool.execute(() -> {
            List<String> lines = new ArrayList<>();
            if (line != null && !line.isEmpty()) lines.add(line);
            for (Episode e : episodes) if (!lines.contains(e.line)) lines.add(e.line);
            int curEpNum = epNumber(cur.title);

            final java.util.concurrent.atomic.AtomicBoolean done =
                    new java.util.concurrent.atomic.AtomicBoolean(false);
            final java.util.concurrent.atomic.AtomicInteger tried =
                    new java.util.concurrent.atomic.AtomicInteger(0);
            final StringBuilder triedInfo = new StringBuilder();
            final Object[] res = new Object[4];
            int nThreads = Math.min(4, Math.max(1, lines.size()));
            java.util.concurrent.ExecutorService p2 =
                    java.util.concurrent.Executors.newFixedThreadPool(nThreads);
            for (int li = 0; li < lines.size(); li++) {
                final int order = li;
                p2.execute(() -> {
                    if (done.get()) return;
                    Episode target = findSameEpisode(lines.get(order), curEpNum, idx);
                    if (target == null) return;
                    tried.incrementAndGet();
                    try {
                        String u = resolveEpisode(target);
                        if (u != null && done.compareAndSet(false, true)) {
                            synchronized (res) {
                                res[0] = u;
                                res[1] = target.line;
                                res[2] = target.lineLabel;
                                res[3] = order + 1;
                            }
                            UrlCache.put(keyOf(target), u);
                        } else if (u == null) {
                            recordFail(triedInfo, target, order);
                        }
                    } catch (Exception ignored) {
                        recordFail(triedInfo, target, order);
                    }
                });
            }
            p2.shutdown();
            try {
                p2.awaitTermination(25, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {}

            String u = null, usedLine = null, usedLabel = null;
            int usedOrder = 0;
            synchronized (res) {
                if (res[0] != null) {
                    u = (String) res[0];
                    usedLine = (String) res[1];
                    usedLabel = (String) res[2];
                    usedOrder = (Integer) res[3];
                }
            }
            final String fu = u, fl = usedLine, flabel = usedLabel;
            final int forder = usedOrder, ftried = tried.get();
            final String fTried = triedInfo.toString();

            runOnUiThread(() -> {
                showLoading(false, null);
                if (fu == null) {
                    switchingLine = false;
                    if (!"AGE".equals(source)) {
                        Toast.makeText(this, "该源解析失败，换一个搜索源重试", Toast.LENGTH_LONG).show();
                        tvNowPlaying.setText(animeName + " " + cur.title + "  解析失败");
                        return;
                    }
                    if (!retriedDetail) {
                        retriedDetail = true;
                        Toast.makeText(this, "线路异常，重新获取播放源…", Toast.LENGTH_SHORT).show();
                        reloadDetailAndRetry(idx);
                        return;
                    }
                    // 当前源所有免费线路都失效 → 去其他片源找同一集
                    if (!autoSwitching) {
                        Toast.makeText(this, "当前片源全部失效，正在其他片源查找…", Toast.LENGTH_SHORT).show();
                        tryAutoSource(false);
                        return;
                    }
                    boolean vipOnly = true;
                    for (Episode e : episodes) if (!e.vip) { vipOnly = false; break; }
                    if (vipOnly) {
                        Toast.makeText(this, "版权番仅 VIP 源（需视频会员），免费无法播放", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "全部 " + ftried + " 个源失败: " + fTried, Toast.LENGTH_LONG).show();
                    }
                    tvNowPlaying.setText(animeName + " " + cur.title + "  解析失败");
                    return;
                }
                line = fl;
                lineLabel = flabel;
                url = fu;
                switchingLine = false;
                tvNowPlaying.setText(animeName + " " + cur.title + " [" + flabel + "]");
                playUrl(fu);
                saveHistory();
                refreshMenuValues();
            });
        });
    }

    private void saveHistory() {
        try {
            if ("AGE".equals(source) && animeId > 0) {
                new HistoryStore(this).add(animeId, animeName, currentTitle, epIndex, line);
            }
        } catch (Exception ignored) {}
    }

    private static String keyOf(Episode e) {
        if (e == null) return "";
        if (e.enc != null && !e.enc.isEmpty()) return "AGE|" + e.enc;
        return (e.source == null ? "" : e.source) + "|" + (e.url == null ? "" : e.url);
    }

    private String resolveEpisode(Episode target) throws Exception {
        // 已经是可播放直链 (非凡 / 部分规则源) → 不再嗅探
        if (target.url != null && (target.url.contains(".m3u8") || target.url.contains(".mp4"))) {
            return target.url;
        }
        if (!"AGE".equals(target.source) && target.url != null && !target.url.isEmpty()) {
            PlayUrlSniffer sniffer = new PlayUrlSniffer(AgeApi.getClient(), target.baseUrl, "");
            return sniffer.sniff(target.url);
        }
        return AgeApi.resolve(target.enc, target.vip, jxZj, jxVip);
    }

    private void recordFail(StringBuilder triedInfo, Episode target, int order) {
        synchronized (triedInfo) {
            if (triedInfo.length() > 0) triedInfo.append("; ");
            triedInfo.append(target.lineLabel).append("(第").append(order + 1).append("个源)失败");
        }
    }

    private static int epNumber(String t) {
        if (t == null) return -1;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\d+").matcher(t);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    private Episode findSameEpisode(String l, int epNum, int fallbackIdx) {
        List<Episode> lineEps = new ArrayList<>();
        for (Episode e : episodes) if (l.equals(e.line)) lineEps.add(e);
        if (lineEps.isEmpty()) return null;
        if (epNum > 0) {
            for (Episode e : lineEps) if (epNumber(e.title) == epNum) return e;
        }
        return lineEps.get(Math.min(fallbackIdx, lineEps.size() - 1));
    }

    private void reloadDetailAndRetry(final int idx) {
        pool.execute(() -> {
            try {
                final com.animetv.model.AnimeDetail nd = AgeApi.detail(animeId);
                if (nd == null || nd.episodes.isEmpty()) {
                    retriedDetail = false;
                    return;
                }
                runOnUiThread(() -> {
                    episodes.clear();
                    episodes.addAll(nd.episodes);
                    if (nd.currentLine != null && !nd.currentLine.isEmpty()) line = nd.currentLine;
                    loadEp(idx);
                });
            } catch (Exception ignored) {}
        });
    }

    private void switchLineAuto() {
        if (episodes == null || episodes.isEmpty() || switchingLine) return;
        List<String> lines = new ArrayList<>();
        for (Episode e : episodes) if (!lines.contains(e.line)) lines.add(e.line);
        if (lines.size() <= 1) {
            switchingLine = false;
            return;
        }
        int i = lines.indexOf(line);
        pendingLine = lines.get((i + 1) % lines.size());
        switchingLine = true;
        Toast.makeText(this, "换源: " + pendingLine, Toast.LENGTH_SHORT).show();
        loadEp(epIndex);
    }

    // ==================== 跨源自动换源 ====================

    /**
     * 当前源全线失效时, 去其它规则源找「同一集」。
     * 手动点「自动换源」也可以随时调用。
     */
    private void tryAutoSource(final boolean manual) {
        if (autoSwitching) return;
        if (autoFails >= 3) {
            Toast.makeText(this, "已尝试多个片源仍失败，请换一部番或换个时间再试", Toast.LENGTH_LONG).show();
            return;
        }
        autoSwitching = true;
        autoTriedOnce = true;
        final int epNum = epNumber(currentTitle);
        final String name = animeName == null ? "" : animeName;
        showLoading(true, "正在其他片源中查找同一集…");
        showHud("自动换源中…");
        if (tvRowAuto != null) tvRowAuto.setText("查找中…");
        if (manual) closeMenu();

        pool.execute(() -> {
            AutoSource.Result r = null;
            try {
                r = AutoSource.find(AgeApi.getClient(), name, epNum, currentTitle, autoTried);
            } catch (Exception ignored) {}
            final AutoSource.Result fr = r;
            runOnUiThread(() -> {
                autoSwitching = false;
                showLoading(false, null);
                if (fr == null) {
                    autoFails++;
                    refreshMenuValues();
                    Toast.makeText(this, "其他片源也没找到可播放的地址", Toast.LENGTH_LONG).show();
                    showHud("换源失败");
                    return;
                }
                hideFatal();
                autoTried.add(fr.source);
                url = fr.url;
                lineLabel = fr.source;
                switchingLine = false;
                tvNowPlaying.setText(animeName + " " + currentTitle + " [" + fr.source + "]");
                Toast.makeText(this, "已换到片源: " + fr.source, Toast.LENGTH_SHORT).show();
                showHud("已换源\n" + fr.source);
                playUrl(fr.url);
                refreshMenuValues();
            });
        });
    }

    // ==================== 生命周期 ====================

    @Override
    protected void onPause() {
        super.onPause();
        saveProgress();
        if (player != null) player.pause();
        updateCenterPlay();
    }

    private void saveProgress() {
        if (player == null || animeId <= 0 || currentTitle == null || currentTitle.isEmpty()) return;
        try {
            long pos = player.getCurrentPosition();
            if (pos > 5000) {
                new HistoryStore(this).add(animeId, animeName, currentTitle, epIndex, line, pos);
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        saveProgress();
        handler.removeCallbacksAndMessages(null);
        pool.shutdownNow();
        if (player != null) {
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }
}
